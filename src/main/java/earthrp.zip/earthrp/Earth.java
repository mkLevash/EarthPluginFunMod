package earthrp;

import earthrp.commands.*;

import earthrp.files.CustomConfig;
import earthrp.listeners.*;
import earthrp.database.ServerDatabase;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.commands.MainMenuCommand;
import earthrp.placeholders.MoraExpansion;
import earthrp.tasks.CheckDayTask;
import earthrp.tasks.MeteorTask;
import org.bukkit.*;
import org.bukkit.block.Biome;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.dynmap.DynmapAPI;
import org.dynmap.markers.AreaMarker;
import org.dynmap.markers.Marker;
import org.dynmap.markers.MarkerAPI;
import org.dynmap.markers.MarkerSet;

import java.sql.SQLException;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import java.util.logging.Level;


import static earthrp.Pathfinding.isLandPathBetween;
import static earthrp.Pathfinding.waterBiomes;
import static earthrp.PolygonUtils.*;
import static earthrp.database.ServerDatabase.chaikinSmoothing;

public class Earth extends JavaPlugin {

    private ServerDatabase serverDatabase;

    private static final HashMap<Player, PlayerMenuUtility> playerMenuUtilityMap = new HashMap<>();
    @Override
    public void onEnable() {

        saveDefaultConfig();

        Crafts.enableCrafts();
        CustomConfig.setup();
        CustomConfig.get().addDefault("test.test","lol");
        CustomConfig.get().options().copyDefaults(true);
        CustomConfig.save();

        if (Objects.equals(getConfig().getString("defaultMessage"), "true")){
            Bukkit.broadcastMessage("[Earth]Проверьте файл config.yml в папке плагина");
        }


        if (Bukkit.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")){
            new MoraExpansion(this).register();
        }
        System.out.println("[Earth RP Plugins] Mora plugin was started");

        // Plugin startup logic
        try {
            if (!getDataFolder().exists()){
                getDataFolder().mkdirs();
            }
            serverDatabase = new ServerDatabase(getDataFolder().getAbsolutePath() + "/server.db");
        }catch (SQLException ex){
            ex.printStackTrace();
            System.out.println("Failed to connect to the database! " + ex.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
        }
        BukkitTask CheckDayTask = new CheckDayTask(this).runTaskTimer(this,0L,1L);


        BukkitTask MeteorTask = new MeteorTask(this).runTaskTimer(this,0L,168000L);

        getCommand("mset").setExecutor(new Mset(this));
        getCommand("mget").setExecutor(new Mget(this));
        getCommand("mora").setExecutor(new GiveMoraCommand(this));
        getCommand("income").setExecutor(new IncomeCommand(this));
        getCommand("expense").setExecutor(new ExpenseCommand(this));
        getCommand("oi").setExecutor(new OiCommand(this));
        getCommand("polit").setExecutor(new PolitCommand(this));
        getCommand("tax_mod").setExecutor(new TaxModifierCommand(this));
        getCommand("trade_mod").setExecutor(new TradeModifierCommand(this));
        getCommand("roll").setExecutor(new RollCommand(this));
        getCommand("army").setExecutor(new ArmyCommand(this));
        getCommand("war").setExecutor(new WarCommand(this));
        getCommand("peace").setExecutor(new PeaceCommand(this));
        getCommand("villager").setExecutor(new GiveVillagerCommand(this));
        getCommand("manpower").setExecutor(new GiveManpowerCommand(this));
        getCommand("menu").setExecutor(new MainMenuCommand(this));
        getCommand("cap").setExecutor(new GiveCapCommand(this));
        getCommand("earth").setExecutor(new EarthCommand());

        getServer().getPluginManager().registerEvents(new MoraCount(this), this);
        getServer().getPluginManager().registerEvents(new JoinHandler(this), this);
        getServer().getPluginManager().registerEvents(new VillagerSpawnHandler(this), this);
//        getServer().getPluginManager().registerEvents(new VillagerKillHandler(this), this);
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new BuildingsHandler(this), this);
        getServer().getPluginManager().registerEvents(new BuildingsClickHandler(this), this);
        getServer().getPluginManager().registerEvents(new TownsHandler(this), this);
        getServer().getPluginManager().registerEvents(new TownCheck(this), this);
        getServer().getPluginManager().registerEvents(new MarketsHandler(this), this);


    }

    public record ChunkPosition(int x, int z) {}
    public record EarthChunk(int x, int z, String townId) {}

    public int getBalance(EarthPlayer p){
        int income = p.getIncome();
        int taxIncome = (int) Math.floor(p.getTaxIncome()*(p.getTaxMod()*0.01+1));
        int tradeIncome = (int) Math.floor(p.getTradeIncome()*(p.getTradeMod()*0.01+1));
        int inflation = p.getInflation();
        income = (int) Math.floor( (income + taxIncome + tradeIncome) * (1 - inflation*0.01) );
        int armyExpense = (int) Math.floor(p.getArmyExpense()*(p.getArmyExpenseMod()*0.01+1));;
        int corruption = p.getCorruption();
        return (int) Math.floor((income - (p.getExpense() + armyExpense)) * (1 - corruption * 0.2));
    }

    public static int getDistance(int x1, int z1, int x2, int z2){
        int dx = x2 - x1;
        int dz = z2 - z1;
        return (int) Math.sqrt(dx * dx + dz * dz);
    }

    public static double calculateDistance(int x1, int z1, int x2, int z2){
        int dx = x2 - x1;
        int dz = z2 - z1;
        return Math.sqrt(dx * dx + dz * dz);
    }

    public ServerDatabase getServerDatabase(){
        return this.serverDatabase;
    }

    public Boolean investTech(UUID uuid, String techId, int techCost) throws SQLException {
        EarthPlayer p = getServerDatabase().getPlayer(uuid);
        int oi_balance = p.getOiBalance();
        if (oi_balance>=techCost){
            getServerDatabase().updatePlayerTech(uuid,1,techId);
            p.setOiBalance(oi_balance-techCost);
            p.setOiSpent(p.getOiSpent()+techCost);
            getServerDatabase().updatePlayer(p);
            return true;
        }else{
            return false;
        }
    }
    public void backTech(UUID uuid, String techId, int techCost) throws SQLException {
        EarthPlayer p = getServerDatabase().getPlayer(uuid);
        int oi_balance = p.getOiBalance();
        getServerDatabase().updatePlayerTech(uuid,0,techId);
        p.setOiBalance(oi_balance+techCost);
        p.setOiSpent(p.getOiSpent()-techCost);
        getServerDatabase().updatePlayer(p);
    }

    public void buyBuilding(UUID uuid, int buildingCost) throws SQLException {
        EarthPlayer p = getServerDatabase().getPlayer(uuid);
        int treasure = p.getTreasury();
        if (treasure>=buildingCost){
            p.setTreasury(treasure-buildingCost);
            getServerDatabase().updatePlayer(p);

        }
    }

    public Boolean investIdea(UUID uuid, int ideaId, int ideaCost) throws SQLException {
        EarthPlayer p = getServerDatabase().getPlayer(uuid);
        int oi_balance = p.getOiBalance();
        if (oi_balance>=ideaCost){
            int t41 = getServerDatabase().getPlayerTech(uuid,41);
            getServerDatabase().updatePlayerTech(uuid,t41+1,"41");
            getServerDatabase().updatePlayerIdea(uuid,1, String.valueOf(ideaId));
            p.setOiBalance(oi_balance-ideaCost);
            p.setOiSpent(p.getOiSpent()+ideaCost);
            getServerDatabase().updatePlayer(p);
            return true;
        }else{
            return false;
        }
    }
    public void backIdea(UUID uuid, int ideaId, int ideaCost) throws SQLException {
        EarthPlayer p = getServerDatabase().getPlayer(uuid);
        int oi_balance = p.getOiBalance();
        int t41 = getServerDatabase().getPlayerTech(uuid,41);
        getServerDatabase().updatePlayerTech(uuid,t41-1,"41");
        getServerDatabase().updatePlayerIdea(uuid,0, String.valueOf(ideaId));
        p.setOiBalance(oi_balance+ideaCost);
        p.setOiSpent(p.getOiSpent()-ideaCost);
        getServerDatabase().updatePlayer(p);
    }

    @Override
    public void onDisable() {
        System.out.println("[Earth RP Plugins] Mora plugin was shut down");
        // Plugin shutdown logic
        try {
            serverDatabase.closeConnection();
        }catch (SQLException ex){
            ex.printStackTrace();
        }
    }
            
    public static PlayerMenuUtility getPlayerMenuUtility(Player p){
        PlayerMenuUtility playerMenuUtility;
        if(playerMenuUtilityMap.containsKey(p)){
            return playerMenuUtilityMap.get(p);
        }else{
            playerMenuUtility = new PlayerMenuUtility(p);
            playerMenuUtilityMap.put(p,playerMenuUtility);
            return playerMenuUtility;
        }
    }

    public static Earth getInstance() {
        return getPlugin(Earth.class);
    }

    public ItemStack makeItem(Material material, String displayName, String... lore) {

        ItemStack item = new ItemStack(material);
        ItemMeta itemMeta = item.getItemMeta();
        itemMeta.setDisplayName(displayName);

        itemMeta.setLore(Arrays.asList(lore));
        item.setItemMeta(itemMeta);



        return item;
    }

    public static void checkLandPathAsync(int startChunkX, int startChunkZ, int endChunkX, int endChunkZ, int maxDistance, Set<ChunkPosition> chunks, String world, Consumer<Boolean> callback) {
        Bukkit.getScheduler().runTaskAsynchronously(Earth.getInstance(), () -> {
            long start = System.currentTimeMillis();
            boolean result = isLandPathBetween(startChunkX, startChunkZ, endChunkX, endChunkZ, maxDistance, chunks, world);
            long end = System.currentTimeMillis();
            Bukkit.getLogger().info("Проверка заняла " + (end - start) + " мс");
            // Возврат в основной поток
            Bukkit.getScheduler().runTask(Earth.getInstance(), () -> callback.accept(result));
        });
    }

    public void drawNationBorder(EarthPlayer nation) throws SQLException {
        ServerDatabase database = getServerDatabase();
        DynmapAPI dynmap = (DynmapAPI) Bukkit.getPluginManager().getPlugin("dynmap");
        if (dynmap == null) {
            Bukkit.getLogger().warning("Dynmap не найден!");
            return;
        }

        MarkerAPI markerAPI = dynmap.getMarkerAPI();
        if (markerAPI == null) {
            Bukkit.getLogger().warning("Dynmap MarkerAPI not found!");
            return;
        }

        MarkerSet markerSet = markerAPI.getMarkerSet("nations");
        if (markerSet == null) {
            markerSet = markerAPI.createMarkerSet("nations", "Nations", null, false);
        }

        // Удаляем старую границу на всякий случай
        String markerId = "nation_" + nation.getUniqueId();
        AreaMarker oldArea = markerSet.findAreaMarker(markerId);
        if (oldArea != null) {
            oldArea.deleteMarker();
        }

        // Получаем все чанки нации (всех городов в нации)
        Set<Earth.ChunkPosition> allChunks = new HashSet<>();
        Town[] towns = database.getPlayerTowns(nation.getUniqueId());
        String world = "world";
        Town capital = null;
        for (Town town : towns) {
            if(town.getType().equals("capital")){
                capital = town;
            }
            world = town.getWorld();
            allChunks.addAll(database.getClaimedChunksByTownId(town.getUniqueId())); // ← реализация зависит от твоей БД
        }

        if (allChunks.isEmpty()) return;


//        List<int[]> border = traceBorderSmooth(allChunks); // <-- используем сглаженный вариант
//        if (border.size() < 3) return;
//
//        double[] x = new double[border.size()];
//        double[] z = new double[border.size()];
//        for (int i = 0; i < border.size(); i++) {
//            x[i] = border.get(i)[0] * 16 + 8;
//            z[i] = border.get(i)[1] * 16 + 8;
//        }
//
//        // Создаём маркер
//        AreaMarker areaMarker = markerSet.createAreaMarker(
//                markerId,
//                nation.getDisplayName(),
//                false,
//                world,
//                x,
//                z,
//                true
//        );

        // Устанавливаем маркер на столицу
        if (capital != null) {
            int cx = capital.getChunkX();
            int cz = capital.getChunkZ();

            Marker marker = markerSet.findMarker("capital_" + nation.getDisplayName());
            if (marker != null) marker.deleteMarker();

            markerSet.createMarker("capital_" + nation.getDisplayName(), "Столица", world,
                    cx * 16 + 8, 64, cz * 16 + 8,
                    markerAPI.getMarkerIcon("capital"), false);
        }

//        // Настраиваем стиль маркера
//        areaMarker.setLineStyle(3, 1.0, 0x0000FF); // толщина, прозрачность, цвет
//        areaMarker.setFillStyle(0.2, 0x0000FF);    // прозрачность, цвет
    }

    public CompletableFuture<Void> drawTownBorderAsync(Town town) {
        return CompletableFuture.supplyAsync(() -> {
            ServerDatabase database = getServerDatabase();
            return null;
        }).thenComposeAsync(towns -> {
            DynmapAPI dynmap = (DynmapAPI) Bukkit.getPluginManager().getPlugin("dynmap");
            if (dynmap == null) {
                Bukkit.getLogger().warning("Dynmap не найден!");
                return CompletableFuture.completedFuture(null);
            }

            MarkerAPI markerAPI = dynmap.getMarkerAPI();
            if (markerAPI == null) {
                Bukkit.getLogger().warning("Dynmap MarkerAPI not found!");
                return CompletableFuture.completedFuture(null);
            }

            return processBorderAsync(markerAPI, town, (Town[]) towns);

        }).exceptionally(e -> {
            Bukkit.getLogger().log(Level.SEVERE, "Ошибка при отрисовке границ нации", e);
            return null;
        });
    }

    private CompletableFuture<Void> processBorderAsync(MarkerAPI markerAPI, Town town, Town[] towns) {
        return CompletableFuture.runAsync(() -> {
            Town capital = null;
            ServerDatabase database = getServerDatabase();
            MarkerSet markerSet = markerAPI.getMarkerSet("towns");
            if (markerSet == null) {
                markerSet = markerAPI.createMarkerSet("towns", "Towns", null, true);

            }
            String markerId = "town_" + town.getUniqueId();
            String world = town.getWorld();
            boolean townEx;
            try {
                townEx = getServerDatabase().townExists(town.getUniqueId());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            if(townEx){
                String iconId;
                if(town.getType().equals("capital")) {
                    iconId = "star";
                }else{
                    iconId = "silverstar";
                }
                AreaMarker oldArea = markerSet.findAreaMarker(markerId);
                if (oldArea != null) {
                    oldArea.deleteMarker();
                }
                Set<ChunkPosition> allChunks = new HashSet<>(database.getClaimedChunksByTownId(town.getUniqueId()));
                if (allChunks.isEmpty()) return;
                List<ChunkPosition> border = findOrderedBorderChunks(allChunks);
                if (border.size() < 3) return;

                double[] x = new double[border.size()];
                double[] z = new double[border.size()];
                for (int i = 0; i < border.size(); i++) {
                    x[i] = border.get(i).x * 16 + 8;
                    z[i] = border.get(i).z * 16 + 8;
                }

                // Сглаживание координат
                List<double[]> smoothPoints = chaikinSmoothing(x, z, 2); // 2 итерации — можно изменить

                double[] smoothX = new double[smoothPoints.size()];
                double[] smoothZ = new double[smoothPoints.size()];
                for (int i = 0; i < smoothPoints.size(); i++) {
                    smoothX[i] = smoothPoints.get(i)[0];
                    smoothZ[i] = smoothPoints.get(i)[1];
                }


                AreaMarker areaMarker = markerSet.createAreaMarker(
                        markerId,
                        town.getName(),
                        false,
                        world,
                        smoothX,
                        smoothZ,
                        true
                );
                areaMarker.setLineStyle(3, 1.0, 0xd0d4db);
                areaMarker.setFillStyle(0.2, 0xd0d4db);


                int cx = town.getChunkX();
                int cz = town.getChunkZ();

                Marker marker = markerSet.findMarker(markerId);
                if (marker != null){
                    marker.setLocation("world",cx * 16 + 8,64,cz * 16 + 8);
                    marker.setLabel(town.getName());
                }else{
                    markerSet.createMarker(markerId, town.getName(), world,
                            cx * 16 + 8, 64, cz * 16 + 8,
                            markerAPI.getMarkerIcon(iconId), true);
                }
            }else{
                AreaMarker oldArea = markerSet.findAreaMarker(markerId);
                if (oldArea != null) {
                    oldArea.deleteMarker();
                }
                Marker marker = markerSet.findMarker(markerId);
                if (marker != null){
                    marker.deleteMarker();
                }
            }


            


        });
    }

    public void markNonWaterChunksAsync(Town town, Consumer<Set<String>> callback) {
        int maxConcurrentTasks = 2; // Максимум одновременно выполняющихся задач
        Semaphore semaphore = new Semaphore(maxConcurrentTasks);
        ExecutorService executor = Executors.newFixedThreadPool(maxConcurrentTasks); // или сколько потоков ты хочешь
        Set<String> occupiedChunks = ConcurrentHashMap.newKeySet();
        List<CompletableFuture<Void>> futures = new ArrayList<>();
        int radius = Earth.getInstance().getConfig().getInt("townSize");
        Set<ChunkPosition> chunks = getServerDatabase().getAllClaimedChunks();

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                World world = Bukkit.getWorld(town.getWorld());
                if (world == null) continue;
                if (dx*dx + dz*dz > radius*radius) continue;
                int centerChunkX = town.getChunkX();
                int centerChunkZ = town.getChunkZ();
                int chunkX = centerChunkX + dx;
                int chunkZ = centerChunkZ + dz;
                if(Earth.calculateDistance(chunkX,chunkZ,centerChunkX,centerChunkZ)>radius) continue;
                int y = world.getHighestBlockAt(chunkX << 4,chunkZ << 4).getY();

                // Предфильтр: если это океан — не отправляем задачу
                Biome biome = world.getBiome(chunkX << 4, y, chunkZ << 4);
                if (waterBiomes.contains(biome)) continue;

                CompletableFuture<Void> future = CompletableFuture.runAsync(() -> {
                    try {
                        semaphore.acquire();
                        boolean isLandPath = isLandPathBetween(chunkX, chunkZ, centerChunkX, centerChunkZ, radius*3,chunks,world.getName());
                        if (isLandPath) {
                            if(getServerDatabase().markChunkAsClaimed(chunkX, chunkZ, town)){
                                occupiedChunks.add(chunkX + "," + chunkZ);
                            }
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    } finally {
                        semaphore.release(); // Освобождает слот
                    }

                }, executor);

                futures.add(future);
            }
        }

        // После завершения всех задач — вызываем callback
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenRun(() -> {
                    executor.shutdown();
                    System.out.println(occupiedChunks.size());// Освобождаем потоки
                    callback.accept(occupiedChunks);
                });
    }





}
