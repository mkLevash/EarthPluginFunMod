package earthrp.commands;

import earthrp.Earth;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;

public class GiveCapCommand implements CommandExecutor {
    private final Earth plugin;

    public GiveCapCommand(Earth plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player p){
            if (args.length == 1){
                String capitalId = String.valueOf(UUID.randomUUID());
                ItemStack capital = new ItemStack(Material.END_CRYSTAL, 1);
                ItemMeta capitalMeta = capital.getItemMeta();
                capitalMeta.setDisplayName(args[0]);
                capitalMeta.setLore(List.of("capital",capitalId,String.valueOf(p.getUniqueId()),p.getDisplayName()));
                capital.setItemMeta(capitalMeta);
                p.getInventory().addItem(capital);
                sender.sendMessage(ChatColor.GREEN + "Вы выдали себе ратушу");
            }
            return true;
        }
        return false;
    }
}
