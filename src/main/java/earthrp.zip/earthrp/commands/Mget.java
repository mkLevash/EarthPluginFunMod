package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.Calendar;

//Set time in milliseconds


public class Mget implements CommandExecutor, TabCompleter {

    private final Earth plugin;

    public Mget(Earth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        try {
            assert sender instanceof Player;
            EarthPlayer p;
            if (args.length != 2){
                sender.sendMessage(ChatColor.YELLOW + "/mget <statistic for check> <player>");
                return true;
            }
            String playerName = args[1];
            Player target = Bukkit.getServer().getPlayer(playerName);
            if(target != null){
                p = this.plugin.getServerDatabase().getPlayer(target.getUniqueId());
            }else if(this.plugin.getServerDatabase().playerOffline(playerName)){
                p = this.plugin.getServerDatabase().getPlayer(this.plugin.getServerDatabase().getPlayerUuid(playerName));
            }else{
                sender.sendMessage(ChatColor.RED + "Игрок не найден!");
                return true;
            }
            int value = 0;
            switch (args[0]) {
                case "treasury" -> {
                    value = p.getTreasury() ;
                }
                case "income" -> {
                    value = p.getIncome() ;
                }
                case "expense" -> {
                    value = p.getExpense() ;
                }
                case "oi_income" -> {
                    value = p.getOiIncome() ;
                }
                case "oi_balance" -> {
                    value = p.getOiBalance() ;
                }
                case "oi_spent" -> {
                    value = p.getOiSpent() ;
                }
                case "polit_balance" -> {
                    value = p.getPolitBalance() ;
                }
                case "polit_income" -> {
                    value = p.getPolitIncome() ;
                }
                case "polit_max" -> {
                    value = p.getPolitMax() ;
                }
                case "tax" -> {
                    value = p.getTaxIncome() ;
                }
                case "tax_mod" -> {
                    value = p.getTaxMod() ;
                }
                case "army_limit" -> {
                    int mod = p.getArmyLimitMod();
                    int baseValue = p.getTaxIncome();
                    value = (int) Math.floor(baseValue * (mod*0.01 + 1)) ;
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2"+args[0] + "&e "+ playerName + " = "+ value + "("+baseValue+"+"+mod+"%)"));
                    return true;
                }
                case "army_limit_modifier" -> {
                    value = p.getArmyLimitMod() ;
                }
                case "army_expense" -> {
                    value = p.getArmyExpense() ;
                }
                case "army_expense_mod" -> {
                    value = p.getArmyExpenseMod() ;
                }
                case "inflation" -> {
                    value = p.getInflation() ;
                }
                case "corruption" -> {
                    value = p.getCorruption() ;
                }
                case "war_support" -> {
                    value = p.getWarSup() ;
                }
                case "war_status" -> {
                    value = p.getWarStatus() ;
                }
                case "trade" -> {
                    value = p.getTradeIncome() ;
                }
                case "trade_mod" -> {
                    value = p.getTradeMod() ;
                }
                case "manpower" -> {
                    int mod = p.getManpowerMod();
                    int baseValue = p.getManpower() ;
                    value = (int) Math.floor(baseValue * (mod*0.01 + 1)) ;
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2"+args[0] + "&e "+ playerName + " = "+ value + "("+baseValue+"+"+mod+"%)"));
                    return true;
                }
                case "max_manpower_mod" -> {
                    value = p.getManpowerMod() ;
                }
                case "manpower_increase_mod" -> {
                    value = p.getManpowerIncMod() ;
                }
                case "balance" -> {
                    int income = p.getIncome();
                    int tax_income = p.getTaxIncome();
                    int tax_modifier = p.getTaxMod();
                    int trade_income = p.getTradeIncome();
                    int trade_modifier = p.getTradeMod();
                    int expense = p.getExpense();
                    int army_expense = p.getArmyExpense();
                    int army_expense_mod = p.getArmyExpenseMod();
                    army_expense = (int) Math.floor(army_expense * (army_expense_mod * 0.01 + 1));
                    int inflation = p.getInflation();
                    int corruption = p.getCorruption();
                    int tax = (int) Math.floor(tax_income * (tax_modifier * 0.01 + 1));
                    int trade = (int) Math.floor(trade_income * (trade_modifier * 0.01 + 1));
                    income = (int) Math.floor( (income + tax + trade) * (1 - inflation*0.01) );
                    int amount = (int) Math.floor((income - expense) * (1 - corruption * 0.2));
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', args[0] + " " + playerName + " = "+ amount + "(&a"+(income)+"("+income+"+"+tax+"+"+trade+") - &4 " + expense + "+" + army_expense + "&f)"));
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "inflation" + " " + playerName + " = "+ inflation + "&f%)"));
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "corruption" + " " + playerName + " = "+ corruption + "&f)"));
                    return true;
                }
            }
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2"+args[0] + "&e "+ playerName + " = "+ value));
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            sender.sendMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
            return true;
        }

    }
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 1){
            return List.of(
                    "treasury",
                    "income",
                    "tax",
                    "tax_mod",
                    "expense",
                    "oi_income",
                    "oi_balance",
                    "oi_spent",
                    "polit_balance",
                    "polit_income",
                    "polit_max",
                    "inflation",
                    "corruption",
                    "balance",
                    "army_limit",
                    "army_limit_modifier",
                    "army_expense",
                    "war_support",
                    "war_status",
                    "trade",
                    "trade_mod",
                    "manpower",
                    "max_manpower_mod",
                    "manpower_increase_mod",
                    "army_expense_mod"
            );
        }
        if (args.length == 2){
            Player[] OnlinePlayers = Bukkit.getServer().getOnlinePlayers().toArray(new Player[0]);
            String[] Players;
            Players = new String[OnlinePlayers.length];
            for (int i = 0; i < OnlinePlayers.length; i++){
                Players[i] = OnlinePlayers[i].getDisplayName();
            }

            return Arrays.asList(Players);
        }
        return null;
    }
}
