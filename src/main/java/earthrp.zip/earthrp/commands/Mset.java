package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class Mset implements CommandExecutor, TabCompleter {

    private final Earth plugin;

    public Mset(Earth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        try {
            assert sender instanceof Player;
            EarthPlayer p;
            if (args.length == 2){
                if (args[0].equals("mora")){
                    if (args[1].equals("on")){
                        this.plugin.getServerDatabase().updateStatusMora("on");
                        Bukkit.broadcastMessage(ChatColor.YELLOW + "Мора запущена");
                        return true;
                    }else if (args[1].equals("off")){
                        this.plugin.getServerDatabase().updateStatusMora("off");
                        Bukkit.broadcastMessage(ChatColor.YELLOW + "Мора выключена");
                        return true;
                    }else{
                        sender.sendMessage(ChatColor.YELLOW + "/mset <statistic for change> <player> <amount>");
                        return true;
                    }

                }else {
                    sender.sendMessage(ChatColor.YELLOW + "/mset <statistic for change> <player> <amount>");
                    return true;
                }
            }
            if (args.length != 3){
                sender.sendMessage(ChatColor.YELLOW + "/mset <statistic for change> <player> <amount>");
                return true;
            }
            String playerName = args[1];
            Player target = Bukkit.getServer().getPlayer(playerName);
            if(target != null){
                p = this.plugin.getServerDatabase().getPlayer(target.getUniqueId());
            }else if(this.plugin.getServerDatabase().playerOffline(playerName)){
                p = this.plugin.getServerDatabase().getPlayer(this.plugin.getServerDatabase().getPlayerUuid(playerName));
            }else{
                sender.sendMessage(ChatColor.RED + "Игрок не найден!");
                return true;
            }
            int amount;
            try {
                amount = Integer.parseInt(args[2]);
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                return true;
            }
            switch (args[0]) {
                case "treasury" -> {
                    p.setTreasury(amount);
                }
                case "income" -> {
                    p.setIncome(amount);
                }
                case "expense" -> {
                    p.setExpense(amount);
                }
                case "oi_income" -> {
                    p.setOiIncome(amount);
                }
                case "oi_balance" -> {
                    p.setOiBalance(amount);
                }
                case "oi_spent" -> {
                    p.setOiSpent(amount);
                }
                case "polit_balance" -> {
                    p.setPolitBalance(amount);
                }
                case "polit_income" -> {
                    p.setPolitIncome(amount);
                }
                case "polit_max" -> {
                    p.setPolitMax(amount);
                }
                case "tax" -> {
                    p.setTaxIncome(amount);
                }
                case "tax_mod" -> {
                    p.setTaxMod(amount);
                }
                case "inflation" -> {
                    p.setInflation(amount);
                }
                case "corruption" -> {
                    p.setCorruption(amount);
                }
//                case "army_limit" -> {
//                    this.plugin.getServerDatabase().updatePlayerArmyLimit(uuid, amount);
//                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&2" + args[0] + " &e" + playerName + "&a была успешно изменена на &e" + amount));
//                    return true;
//                }
                case "army_limit_mod" -> {
                    p.setArmyLimitMod(amount);
                }
                case "army_expense" -> {
                    p.setArmyExpense(amount);
                }
                case "army_expense_mod" -> {
                    p.setArmyExpenseMod(amount);
                }
                case "war_support" -> {
                    p.setWarSup(amount);
                }
                case "war_status" -> {
                    p.setWarStatus(amount);
                }
                case "trade" -> {
                    p.setTradeIncome(amount);
                }
                case "trade_mod" -> {
                    p.setTradeMod(amount);
                }
                case "max_manpower_mod" -> {
                    p.setManpowerMod(amount);
                }
                case "manpower_increase_mod" -> {
                    p.setManpowerIncMod(amount);
                }

            }
            this.plugin.getServerDatabase().updatePlayer(p);
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', args[0] + playerName + "&a была успешно изменена на &e" + amount));
        } catch (SQLException e) {
            e.printStackTrace();
            sender.sendMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
            return true;
        }

        return true;
    }
    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 1){
            return List.of(
                    "treasury",
                    "income",
                    "tax",
                    "tax_mod",
                    "expense",
                    "oi_income",
                    "oi_balance",
                    "oi_spent",
                    "polit_balance",
                    "polit_income",
                    "polit_max",
                    "inflation",
                    "mora",
                    "corruption",
                    "army_limit",
                    "army_limit_modifier",
                    "army_expense",
                    "war_support",
                    "war_status",
                    "trade",
                    "trade_mod",
                    "max_manpower_mod",
                    "manpower_increase_mod",
                    "army_expense_mod"
            );
        }
        if (args.length == 2 && args[0].equals("mora")){
            return List.of(
                    "on",
                    "off"
            );
        }
        if (args.length == 2){
            Player[] OnlinePlayers = Bukkit.getServer().getOnlinePlayers().toArray(new Player[0]);
            String[] Players;
            Players = new String[OnlinePlayers.length];
            for (int i = 0; i < OnlinePlayers.length; i++){
                Players[i] = OnlinePlayers[i].getDisplayName();
            }

            return Arrays.asList(Players);
        }
        if (args.length == 3){
            return List.of(
                    "<новое значение для статистики>"
            );
        }

        return null;
    }
}
