package earthrp.commands;

import earthrp.Earth;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;

import static java.lang.Integer.parseInt;

public class RollCommand implements CommandExecutor, TabCompleter {
    private final Earth earth;
    public RollCommand(Earth earth) {
        this.earth = earth;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 3 && sender instanceof Player p){
            int d;
            int mod;
            try {
                d = parseInt(args[1]);
                mod = parseInt(args[2]);
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели числа");
                return true;
            }
            if (args[0].equals("private")){
                p.sendMessage(ChatColor.GREEN + "Вам выпало число " + ((int) (Math.random() * d) + 1 + mod) + "(" + mod + ")");
            } else if (args[0].equals("public")) {
                Bukkit.broadcastMessage(ChatColor.GREEN + (p.getDisplayName() + " выпало число " +((int) (Math.random() * d) + 1 + mod) + "(" + mod + ")"));
            }else {
                p.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы указали приватность броска");
            }
            return true;
        }else if (args.length == 2 && sender instanceof Player p){
            int d;
            try {
                d = parseInt(args[1]);
            } catch (NumberFormatException e) {
                p.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели числа");
                return true;
            }
            if (args[0].equals("private")){
                p.sendMessage(ChatColor.GREEN + "Вам выпало число " +((int) (Math.random() * d) + 1));
            } else if (args[0].equals("public")) {
                Bukkit.broadcastMessage(ChatColor.GREEN + (p.getDisplayName() + " выпало число " +((int) (Math.random() * d) + 1)));
            }else {
                p.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы указали приватность броска");
            }
            return true;
        }else {
            sender.sendMessage(ChatColor.YELLOW + "/roll <dice> <modifier>");
            return true;
        }
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 1){
            return List.of(
                    "private",
                    "public"
            );
        }
        if (args.length == 2){
            return List.of(
                    "<количество граней кубика>"
            );
        }
        if (args.length == 3){
            return List.of(
                    "<модификатор броска>"
            );
        }
        return null;
    }
}
