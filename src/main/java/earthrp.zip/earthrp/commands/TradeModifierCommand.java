package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;

public class TradeModifierCommand implements CommandExecutor {
    private final Earth earth;
    public TradeModifierCommand(Earth earth) {
        this.earth= earth;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            try{
                EarthPlayer p = this.earth.getServerDatabase().getPlayer(player.getUniqueId());
                if (args.length != 1){
                    sender.sendMessage(ChatColor.GREEN + "Ваша эффективность торговли - " + p.getTradeMod() + "%");
                    sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /trade_mod <amount>");
                    return true;
                }
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);

                }catch (NumberFormatException e){
                    sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                    return true;
                }
                int mod = p.getTaxMod()+amount;
                p.setTaxMod(mod);
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаша эффективность торговли был успешно увеличена на &e" + amount +"%, теперь она равна" + mod));
                return true;


            } catch (SQLException e) {
                Bukkit.broadcastMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
                throw new RuntimeException(e);
            }
        }
        return false;
    }
}
