//package earthrp.commands;
//
//import earthrp.Earth;
//import org.bukkit.Bukkit;
//import org.bukkit.ChatColor;
//import org.bukkit.command.Command;
//import org.bukkit.command.CommandExecutor;
//import org.bukkit.command.CommandSender;
//import org.bukkit.entity.Player;
//
//import java.sql.SQLException;
//import java.util.UUID;
//
//public class SetTreasury implements CommandExecutor {
//
//    private final Earth moraPlugin;
//
//    public SetTreasury(Earth moraPlugin) {
//        this.moraPlugin = moraPlugin;
//    }
//
//    @Override
//    public boolean onCommand(CommandSender sender, Command command, String s, String[] args) {
//        if (args.length != 2){
//            sender.sendMessage(ChatColor.YELLOW + "Введите /settreasury <player> <amount>");
//            return true;
//        }
//
//        String playerName = args[0];
//        Player target = Bukkit.getPlayer(playerName);
//        UUID uuid = null;
//        try {
//            if (target == null && this.moraPlugin.getServerDatabase().playerOffline(playerName)){
//                uuid = this.moraPlugin.getServerDatabase().getPlayerUuid(playerName);
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//            sender.sendMessage(ChatColor.RED + "Игрок не найден");
//            return true;
//        }
//        if (target != null){
//            uuid = target.getUniqueId();
//        }
//        int amount = 0;
//        try {
//            amount = Integer.parseInt(args[1]);
//
//        }catch (NumberFormatException e){
//            sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
//            return true;
//        }
//
//        try {
//            this.moraPlugin.getServerDatabase().updatePlayerTreasury(uuid,amount);
//            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aКазна &e" + playerName + "&a была успешно изменена на &e" + amount));
//        }catch (SQLException ex){
//            ex.printStackTrace();
//            sender.sendMessage(ChatColor.RED + "Произошла ошибка во время изменения казны игрока");
//        }
//
//        return true;
//    }
//}
//
