package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class OiCommand implements CommandExecutor, TabCompleter {
    private final Earth plugin;

    public OiCommand(Earth plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            EarthPlayer p;
            try {
                p = this.plugin.getServerDatabase().getPlayer(player.getUniqueId());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            if(args.length != 2){
                sender.sendMessage(ChatColor.YELLOW + "У вас сейчас " + p.getOiBalance() + "ОИ");
                sender.sendMessage(ChatColor.YELLOW + "Введите /oi income <amount> для изменения");
                return true;

            } else{
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);

                }catch (NumberFormatException e){
                    sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                    return true;
                }
                p.setOiIncome(amount);
                try {
                    this.plugin.getServerDatabase().updatePlayer(p);
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш прирост ОИ был успешно изменена на &e" + amount));
                    return true;
                } catch (SQLException e) {
                    Bukkit.broadcastMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
                    throw new RuntimeException(e);
                }
            }
        }
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 1){
            return List.of(
                    "income"
            );
        }
        if (args.length == 2) {
            return List.of(
                    "<новое значение>"
            );

        }
        return null;

    }
}
