package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class GiveMoraCommand implements CommandExecutor {
    private final Earth plugin;

    public GiveMoraCommand(Earth plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            EarthPlayer p;
            try {
                p = this.plugin.getServerDatabase().getPlayer(player.getUniqueId());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            try{
                int treasury = p.getTreasury();
                int amount = 0;
                if (args.length != 1){
                    sender.sendMessage(ChatColor.YELLOW + "/mora <amount>");
                    ItemStack item = player.getInventory().getItemInMainHand();
                    ItemStack air = new ItemStack(Material.AIR,1);
                    List<String> lore = Objects.requireNonNull(item.getItemMeta()).getLore();
                    assert lore != null;
                    switch (lore.get(0)) {

                        case "1 мора" -> {
                            player.getInventory().setItemInMainHand(air);
                            amount = item.getAmount();
                        }
                        case "9 моры" -> {
                            player.getInventory().setItemInMainHand(air);
                            amount = item.getAmount() * 9;
                        }
                        case "81 моры" -> {
                            player.getInventory().setItemInMainHand(air);
                            amount = item.getAmount() * 81;
                        }
                    }

                } else{

                    try {
                        amount = -Integer.parseInt(args[0]);
                    } catch (NumberFormatException e) {
                        sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                        return true;
                    }

                    if (treasury + amount >= 0){
                        p.setTreasury(treasury);
                        this.plugin.getServerDatabase().updatePlayer(p);

                        ItemStack mora = new ItemStack(Material.GOLD_NUGGET, amount);
                        ItemMeta moraMeta = mora.getItemMeta();
                        assert moraMeta != null;
                       // moraMeta.getPersistentDataContainer().set(new NamespacedKey(Earth.getPlugin(), "uuid"), PersistentDataType.STRING, players.get(index).getUniqueId().toString());
                        moraMeta.setDisplayName(ChatColor.YELLOW + "Мора");
                        moraMeta.setLore(Collections.singletonList("1 мора"));
                        mora.setItemMeta(moraMeta);
                        player.getInventory().addItem(mora);
                        sender.sendMessage(ChatColor.GREEN + "Вы выдали себе " + amount + " моры");
                    }else{
                        sender.sendMessage(ChatColor.YELLOW + "В вашей казней недостаточно моры!");
                        return true;
                    }

                }
                assert amount != 0;
                p.setTreasury(treasury+amount);
                this.plugin.getServerDatabase().updatePlayer(p);
                return true;


            }catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }


        return true;
    }
}
