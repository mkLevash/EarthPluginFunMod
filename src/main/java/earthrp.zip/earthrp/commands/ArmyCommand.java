package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class ArmyCommand implements CommandExecutor, TabCompleter {
    private final Earth earthPlugin;

    public ArmyCommand(Earth earthPlugin) {
        this.earthPlugin = earthPlugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            UUID uuid = player.getUniqueId();
            EarthPlayer p;
            try {
                p = earthPlugin.getServerDatabase().getPlayer(uuid);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            if (args.length > 2 | args.length == 0){
                sender.sendMessage(ChatColor.YELLOW + "Введите /army <stats> <amount>");
            }else{
                int amount = 0;
                if (args.length == 2){
                    try {
                        amount = Integer.parseInt(args[1]);

                    }catch (NumberFormatException e){
                        sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                        return true;
                    }
                }
                try {
                    switch (args[0]){
                        case "limit_mod" -> {

                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваш модификатор лимита армии - " + p.getArmyLimitMod());
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army limit_mod <amount>");
                            }else {
                                p.setArmyLimitMod(amount);

                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш модификатор лимита армии теперь - &e" + amount));
                            }

                        }
                        case "expense" -> {
                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваш базовый расход на армию - " + p.getArmyExpense());
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army expense <amount>");
                            }else {
                                p.setArmyExpense(amount);

                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш базовый расход на армию теперь - &e" + amount));
                            }

                        }
                        case "expense_mod" -> {
                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваш модификатор расходов на армию - " + p.getArmyExpenseMod());
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army expense_mod <amount>");
                            }else {
                                p.setArmyExpenseMod(amount);

                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш одификатор расходов на армию теперь - &e" + amount));
                            }

                        }
                        case "max_manpower_mod" -> {
                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваш модификатор максимума MP - " + p.getManpowerMod() + "%");
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army max_manpower_mod <amount>");
                            }else {
                                p.setManpowerMod(amount);

                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш модификатор максимума MP теперь - &e" + amount + "%"));
                            }

                        }
                        case "manpower_increase_mod" -> {
                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваш модификатор мобилизации - " + p.getManpowerIncMod());
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army manpower_increase_mod <amount>");
                            }else {
                                p.setManpowerIncMod(amount);
                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш модификатор мобилизации теперь - &e" + amount));
                            }

                        }
                        case "war_support" -> {
                            if (args.length == 1){
                                sender.sendMessage(ChatColor.GREEN + "Ваша поддержка войны - " + p.getWarSup());
                                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /army war_support <amount>");
                            }else {
                                p.setWarSup(amount);
                                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш поддержка войны теперь - &e" + amount));
                            }

                        }

                    }
                    this.earthPlugin.getServerDatabase().updatePlayer(p);
                    return true;

                } catch (SQLException e) {
                    sender.sendMessage(ChatColor.RED + "Произошла ошибка при подключении к БД");
                    return true;
                }
            }
            return true;
        }
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (args.length == 1){
            return List.of(
                    "limit_mod",
                    "expense",
                    "expense_mod",
                    "manpower_increase_mod",
                    "max_manpower_mod",
                    "war_support"
            );
        }
        if (args.length == 2){
            return List.of(
                    "<новое значение>"
            );
        }
        return null;
    }
}
