package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

public class PeaceCommand implements CommandExecutor, TabCompleter {
    private final Earth plugin;

    public PeaceCommand(Earth plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            try{
                if (args.length == 0){
                    sender.sendMessage(ChatColor.YELLOW + "Введите /peace <player_name>");
                    return true;}
                EarthPlayer p = this.plugin.getServerDatabase().getPlayer(player.getUniqueId());
                String playerName = args[0];
                Player target = Bukkit.getServer().getPlayer(playerName);
                EarthPlayer targetPlayer;
                if(target != null){
                    targetPlayer = this.plugin.getServerDatabase().getPlayer(target.getUniqueId());
                }else if(this.plugin.getServerDatabase().playerOffline(playerName)){
                    targetPlayer = this.plugin.getServerDatabase().getPlayer(this.plugin.getServerDatabase().getPlayerUuid(playerName));
                }else{
                    sender.sendMessage(ChatColor.RED + "Игрок не найден!");
                    return true;
                }
                targetPlayer.setWarStatus(0);
                p.setWarStatus(0);
                this.plugin.getServerDatabase().updatePlayer(p);
                this.plugin.getServerDatabase().updatePlayer(targetPlayer);
                Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', "&3" + p.getDisplayName() + "&e заключил мир с &a" + args[0]));
                return true;
            }catch(SQLException e){
                sender.sendMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
                throw new RuntimeException(e);
            }

        }
        return false;
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender commandSender, @NotNull Command command, @NotNull String s, @NotNull String[] strings) {
        Player[] OnlinePlayers = Bukkit.getServer().getOnlinePlayers().toArray(new Player[0]);
        String[] Players;
        Players = new String[OnlinePlayers.length];
        for (int i = 0; i < OnlinePlayers.length; i++){
            Players[i] = OnlinePlayers[i].getDisplayName();
        }

        return Arrays.asList(Players);
    }
}
