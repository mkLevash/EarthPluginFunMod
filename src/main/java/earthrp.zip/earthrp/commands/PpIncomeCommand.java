//package earthrp.commands;
//
//import earthrp.Earth;
//import org.bukkit.Bukkit;
//import org.bukkit.ChatColor;
//import org.bukkit.command.Command;
//import org.bukkit.command.CommandExecutor;
//import org.bukkit.command.CommandSender;
//import org.bukkit.entity.Player;
//import org.jetbrains.annotations.NotNull;
//
//import java.sql.SQLException;
//import java.util.Objects;
//import java.util.UUID;
//
//public class PpIncomeCommand implements CommandExecutor {
//    private final Earth plugin;
//
//    public PpIncomeCommand(Earth plugin) {
//        this.plugin = plugin;
//    }
//    @Override
//    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
//        if (args.length != 1 && args.length != 0){
//            sender.sendMessage(ChatColor.YELLOW + "Введите /polit_income <amount>");
//            return true;
//        }else if (args.length == 0 && sender instanceof Player p){
//            try {
//                sender.sendMessage(ChatColor.GREEN + "Ваш прирост политической власти - " + plugin.getServerDatabase().getPlayerPpIncome(p.getUniqueId()));
//                sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /polit_income <amount>");
//            } catch (SQLException e) {
//                sender.sendMessage(ChatColor.RED + "Произошла ошибка при подключении к БД");
//                return true;
//            }
//            return true;
//        }
//        int amount;
//        try {
//            amount = Integer.parseInt(args[0]);
//
//        }catch (NumberFormatException e){
//            sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
//            return true;
//        }
//        UUID uuid = Objects.requireNonNull(Bukkit.getPlayer(sender.getName())).getUniqueId();
//        try {
//            this.plugin.getServerDatabase().updatePlayerPpIncome(uuid,amount);
//            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш прирост Политической Власти был успешно изменена на &e" + amount));
//        } catch (SQLException e) {
//            e.printStackTrace();
//            sender.sendMessage(ChatColor.RED + "Произошла ошибка во время изменения казны игрока");
//        }
//        return true;
//    }
//}
