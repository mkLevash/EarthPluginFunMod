package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;

public class TaxModifierCommand implements CommandExecutor {
    private final Earth plugin;
    public TaxModifierCommand(Earth plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player player){
            try{
                EarthPlayer p = this.plugin.getServerDatabase().getPlayer(player.getUniqueId());
                if (args.length != 1){
                    sender.sendMessage(ChatColor.GREEN + "Ваш модификатор налогов - " + p.getTaxMod());
                    sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /tax_mod <amount>");
                    return true;
                }
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);

                }catch (NumberFormatException e){
                    sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                    return true;
                }
                int mod = p.getTaxMod()+amount;
                p.setTaxMod(mod);
                sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш модификатор дохода от налогов был успешно увеличен на &e" + amount +"%, теперь он равен" + mod));
                return true;


            } catch (SQLException e) {
                Bukkit.broadcastMessage(ChatColor.RED + "Произошла ошибка при получении данных из базы данных");
                throw new RuntimeException(e);
            }
        }
        return false;
    }
}
