//package earthrp.commands;
//
//import earthrp.Earth;
//import org.bukkit.ChatColor;
//import org.bukkit.Material;
//import org.bukkit.command.Command;
//import org.bukkit.command.CommandExecutor;
//import org.bukkit.command.CommandSender;
//import org.bukkit.entity.Player;
//import org.bukkit.inventory.ItemStack;
//import org.bukkit.inventory.meta.ItemMeta;
//import org.jetbrains.annotations.NotNull;
//
//import java.sql.SQLException;
//import java.util.Collections;
//
//public class PpGiveCommand implements CommandExecutor {
//    private final Earth plugin;
//
//    public PpGiveCommand(Earth plugin) {
//        this.plugin = plugin;
//    }
//    @Override
//    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
//        if (sender instanceof Player p){
//            if (args.length != 1){
//                sender.sendMessage(ChatColor.YELLOW + "/polit <amount>");
//                return true;
//            } else{
//                int amount;
//                try {
//                    amount = Integer.parseInt(args[0]);
//                } catch (NumberFormatException e) {
//                    sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
//                    return true;
//                }
//                try {
//                    int PpBalance = this.plugin.getServerDatabase().getPlayerPpBalance(p.getUniqueId());
//                    if (PpBalance - amount >= 0){
//                        PpBalance -= amount;
//                        this.plugin.getServerDatabase().updatePlayerPpBalance(p.getUniqueId(),PpBalance);
//                        ItemStack pp = new ItemStack(Material.NETHERITE_UPGRADE_SMITHING_TEMPLATE, amount);
//                        ItemMeta ppMeta = pp.getItemMeta();
//                        ppMeta.setDisplayName("Politka");
//                        ppMeta.setLore(Collections.singletonList("Политическая Власть"));
//                        pp.setItemMeta(ppMeta);
//                        p.getInventory().addItem(pp);
//                        sender.sendMessage(ChatColor.GREEN + "Вы выдали себе " + amount + "£");
//                    }else{
//                        sender.sendMessage(ChatColor.YELLOW + "У вас недостаточно Политической Власти!");
//                    }
//                    return true;
//
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
//            }
//        }
//
//
//        return true;
//    }
//}
