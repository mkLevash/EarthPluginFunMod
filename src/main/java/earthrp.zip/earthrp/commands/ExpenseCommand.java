package earthrp.commands;

import earthrp.Earth;
import earthrp.EarthPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;
import java.util.Objects;
import java.util.UUID;

public class ExpenseCommand implements CommandExecutor {
    private final Earth moraPlugin;

    public ExpenseCommand(Earth moraPlugin) {
        this.moraPlugin = moraPlugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        EarthPlayer p;
        if(sender instanceof Player player){
            try {
                p = this.moraPlugin.getServerDatabase().getPlayer(player.getUniqueId());
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }else{
            return false;
        }
        if (args.length != 1 && args.length != 0){
            sender.sendMessage(ChatColor.YELLOW + "Введите /expense <amount>");
            return true;
        }else if (args.length == 0){
            sender.sendMessage(ChatColor.GREEN + "Ваш базовый расход - " + p.getExpense() + "%");
            sender.sendMessage(ChatColor.YELLOW + "Для измененния введите /expense <amount>");
            return true;
        }
        int amount;
        try {
            amount = Integer.parseInt(args[0]);

        }catch (NumberFormatException e){
            sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
            return true;
        }
        try {
            p.setExpense(amount);
            this.moraPlugin.getServerDatabase().updatePlayer(p);
            sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&aВаш базовый расход был успешно изменена на &e" + amount));
        } catch (SQLException e) {
            e.printStackTrace();
            sender.sendMessage(ChatColor.RED + "Произошла ошибка во время подключения к базе данных");
        }

        return true;
    }
}
