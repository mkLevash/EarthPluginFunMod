package earthrp.commands;

import earthrp.Earth;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;
import java.util.Collections;
import java.util.UUID;

public class GiveVillagerCommand implements CommandExecutor {
    private final Earth plugin;

    public GiveVillagerCommand(Earth plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player p){
            if (args.length != 1){
                sender.sendMessage(ChatColor.YELLOW + "/villager <amount>");
            } else{
                int amount;
                try {
                    amount = Integer.parseInt(args[0]);
                } catch (NumberFormatException e) {
                    sender.sendMessage(ChatColor.YELLOW + "Ошибка, убедитесь что вы вверно ввели <amount>");
                    return true;
                }
                ItemStack villager = new ItemStack(Material.VILLAGER_SPAWN_EGG, amount);
                ItemMeta villagerMeta = villager.getItemMeta();
                villagerMeta.setDisplayName("Villager " + p.getDisplayName());
                villagerMeta.setLore(Collections.singletonList("Житель твой ёпта"));
                villager.setItemMeta(villagerMeta);
                p.getInventory().addItem(villager);
                sender.sendMessage(ChatColor.GREEN + "Вы выдали себе " + amount + " жителей");

            }
            return true;
        }


        return true;
    }
}
