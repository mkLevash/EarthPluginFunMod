package earthrp.tasks;

import earthrp.Earth;
import earthrp.events.NewDayEvent;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Objects;

public class MeteorTask extends BukkitRunnable {
    private final Earth plugin;

    public MeteorTask(Earth plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        int r = (int) (Math.random() * 100);
        if (r==69){
            Bukkit.getServer().getPluginManager().callEvent(new NewDayEvent());

        }


    }
}
