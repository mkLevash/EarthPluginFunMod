package earthrp.tasks;

import earthrp.Earth;
import earthrp.events.NewDayEvent;
import earthrp.events.TownCheckEvent;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Objects;

public class CheckDayTask extends BukkitRunnable {
    private final Earth plugin;

    public CheckDayTask(Earth plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        long time = Objects.requireNonNull(Bukkit.getServer().getWorld("world")).getTime();
        if (time == 0){
            Bukkit.getServer().getPluginManager().callEvent(new NewDayEvent());
        }
        Bukkit.getServer().getPluginManager().callEvent(new TownCheckEvent());


    }
}
