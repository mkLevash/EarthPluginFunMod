package earthrp.placeholders;

import earthrp.Building;
import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.Town;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Objects;
import java.util.UUID;

import static earthrp.Pathfinding.isLandPathBetween;

public class MoraExpansion extends PlaceholderExpansion {

    private static @NotNull String[] getColor(int amount, int modifier, int negative) {
        String mod;
        String sum;
        String prefix_p = "+";
        String prefix_n = "";
        String postfix = "&f%)";
        int amount_n = amount;
        int modifier_n = modifier;
        String[] rs;
        rs = new String[2];
        if (negative == 1){
            amount_n = -amount;
        } else if (negative == 2) {
            modifier_n = -modifier;
            prefix_p = "";
            prefix_n = "+";

        } else if (negative == 3) {
            amount_n = -amount;
            modifier_n = -modifier;
            prefix_p = "";
            prefix_n = "+";

        } else if (negative==4) {
            postfix = "&f)";
        }

        if (amount > 0){
            sum = "&a" + amount_n + "&f";
        }else if (amount < 0){
            sum = "&c" + amount_n + "&f";
        }else{
            sum = "&f" + amount_n;
        }
        rs[0] = sum;
        if (modifier >0){
            mod = "(&2" + prefix_p + modifier_n + postfix;
        }else if(modifier <0){
            mod = "(&c" + prefix_n + modifier_n + postfix;
        }else {
            mod = "";
        }
        rs[1] = mod;
        return rs;
    }
    public static String cutString(String str, int index) {
        String s = new StringBuilder(str).reverse().toString();
        if (s.length() < 2){
            s =  s + "00";
        }
        else if (s.length() < 3){
            s = s + "0";
        }
        return new StringBuilder(s.substring(0,index)).reverse().toString();
    }
    private final Earth Plugin;

    public MoraExpansion(Earth Plugin) {
        this.Plugin = Plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "mora";
    }

    @Override
    public @NotNull String getAuthor() {
        return String.join(", ", Plugin.getDescription().getAuthors());
    }

    @Override
    public @NotNull String getVersion() {
        return Plugin.getDescription().getVersion();
    }


    @Override
    public @Nullable String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null){
            return "";
        }
        String value = "";
        try {
            EarthPlayer p = this.Plugin.getServerDatabase().getPlayer(player.getUniqueId());
            if (params.equalsIgnoreCase("treasury")){
                value = String.valueOf(p.getTreasury());
            }
            if (params.equalsIgnoreCase("income")){
                UUID uuid = player.getUniqueId();
                int income = (int) Math.floor((p.getIncome()+p.getTaxIncome()) * (p.getTaxMod()*0.01+1));
                int income_mod = p.getTaxMod();
                int trade = (int) Math.floor(p.getTradeIncome()*(1+p.getTradeMod()*0.01));
                int total = income + trade;
                String[] rs = getColor(total,income_mod+p.getTradeMod(),0);

                value = rs[0]+rs[1];
            }
            if (params.equalsIgnoreCase("tax_income")){
//                try {
//                    UUID uuid = player.getUniqueId();
//                    int tax_income = this.Plugin.getServerDatabase().getPlayerTaxIncome(uuid);
//                    int tax_mod = this.Plugin.getServerDatabase().getPlayerTaxModifier(uuid);
//                    int tax = (int) Math.floor(tax_income * (tax_mod * 0.01 + 1));
//                    String[] rs = getColor(tax,tax_mod,0);
//
//                    return rs[0]+rs[1];
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("expense")){
//                try {
//                    UUID uuid = player.getUniqueId();
//                    int expense = this.Plugin.getServerDatabase().getPlayerExpense(uuid);
//
//                    return getColor(-expense,0,1)[0];
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("army_expense")){
//                try {
//                    UUID uuid = player.getUniqueId();
//                    int army_expense = this.Plugin.getServerDatabase().getPlayerArmyExpense(uuid);
//                    int army_expense_mod = this.Plugin.getServerDatabase().getPlayerArmyExpenseModifier(uuid);
//                    int expense = (int) Math.ceil(army_expense * (army_expense_mod * 0.01 + 1));
//                    String[] rs = getColor(-expense,-army_expense_mod,3);
//
//                    return rs[0]+rs[1];
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("balance")){
//                try {
//                    UUID uuid = player.getUniqueId();
//                    int income = this.Plugin.getServerDatabase().getPlayerIncome(uuid);
//                    int tax_income = this.Plugin.getServerDatabase().getPlayerTaxIncome(uuid);
//                    int tax_modifier = this.Plugin.getServerDatabase().getPlayerTaxModifier(uuid);
//                    int inflation = this.Plugin.getServerDatabase().getPlayerInflation(uuid);
//                    int tax = (int) Math.floor(tax_income * (tax_modifier * 0.01 + 1));
//                    income = (int) Math.floor( (income + tax) * (1 - inflation*0.01) );
//                    int expense = this.Plugin.getServerDatabase().getPlayerExpense(uuid);
//                    int army_expense = this.Plugin.getServerDatabase().getPlayerArmyExpense(uuid);
//                    int army_expense_mod = this.Plugin.getServerDatabase().getPlayerArmyExpenseModifier(uuid);
//                    int corruption = this.Plugin.getServerDatabase().getPlayerCorruption(uuid);
//                    army_expense = (int) Math.ceil(army_expense * (army_expense_mod * 0.01 + 1));
//                    int balance = (int) Math.floor((income - (expense + army_expense)) * (1 - corruption * 0.2));
//
//                    if(balance > 0){
//                        return "&a" + balance + "&fव";
//                    }
//                    else if(balance < 0){
//                        return "&c" + balance + "&fश";
//                    }
//                    else {
//                        return balance + "ष";
//                    }
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("main_balance")){
                int balance = this.Plugin.getBalance(p);

                if(balance > 0){
                    return "&fव" + "&a" + balance;
                }
                else if(balance < 0){
                    return "&fश" + "&c" + balance;
                }
                else {
                    return "ष" + balance;
                }
            }
            if (params.equalsIgnoreCase("oi_balance")){
                value = String.valueOf(p.getOiBalance());

            }
            if (params.equalsIgnoreCase("oi_income")){
//                try {
//                    int amount = this.Plugin.getServerDatabase().getPlayerOiIncome(player.getUniqueId());
//
//                    return String.valueOf(amount);
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("oi_spent")){
//                try {
//                    int amount = this.Plugin.getServerDatabase().getPlayerOiSpent(player.getUniqueId());
//
//                    return String.valueOf(amount);
//                } catch (SQLException e) {
//                    throw new RuntimeException(e);
//                }
                return "";
            }
            if (params.equalsIgnoreCase("pp_bal")){
                value = String.valueOf(p.getPolitBalance());

            }
            if (params.equalsIgnoreCase("pp_inc")){
                return "";
            }
            if (params.equalsIgnoreCase("pp_max")){
                value = String.valueOf(p.getPolitMax());
            }
            if (params.equalsIgnoreCase("war_support")){

                value = String.valueOf(p.getWarSup());
            }
            if (params.equalsIgnoreCase("manpower")){

                int armyLimit = (int) Math.floor(p.getTaxIncome() * (p.getArmyLimitMod() * 0.01 + 1));
                String modifier = getColor(armyLimit,p.getArmyLimitMod(),0)[1];
                String manpowerIncrease = getColor(armyLimit,p.getManpowerIncMod()+p.getWarSup(),4)[1];

                value = "&fऴ" + p.getManpower() + manpowerIncrease + "/" + armyLimit + modifier;
            }
            if (params.equalsIgnoreCase("army_limit")){
                int limit = (int) Math.floor(p.getTaxIncome() * (p.getArmyLimitMod() * 0.01 + 1));
                String modifier = getColor(limit,p.getArmyLimitMod(),0)[1];

                return "&fह" + limit + modifier;
            }
            if (params.equalsIgnoreCase("war_status")){

                if (p.getWarStatus() == 0){
                    return "&3In peace";
                }else{
                    return "&4In war";
                }
            }
            if (params.equalsIgnoreCase("inflation")){
                return getColor(-p.getInflation(),0,1)[0] + "%";
            }
            if (params.equalsIgnoreCase("corruption")){
                return getColor(-p.getCorruption(),0,1)[0];
            }
            if (params.equalsIgnoreCase("mora")){
                boolean mora = this.Plugin.getServerDatabase().getStatusMora();

                if (mora){
                    return "&aON ";
                }else{
                    return "&cOFF ";
                }
            }
            if (params.equalsIgnoreCase("day")){
                String day = String.valueOf(this.Plugin.getServerDatabase().getStatusDay());
                long time = Objects.requireNonNull(Bukkit.getServer().getWorld("world")).getTime();
                int time_hour = (int) Math.floor((double) time /1000);
                String hour;
                String min;
                if (time_hour + 6 > 24) {
                    hour = "0" + (time_hour-18);
                }
                else if (time_hour < 4){
                    hour = "0" + (time_hour + 6);
                }
                else {
                    hour = String.valueOf(time_hour + 6);
                }
                int time_min = (int) Math.round( Integer.parseInt(cutString(String.valueOf(time),3))*0.06);

                if (time_min<10){
                    min = "0" + time_min;
                }
                else if (time_min < 60) {
                    min = String.valueOf(time_min);
                }
                else {
                    min = "00";
                }

                return day + ", " + hour + ":" + min;
            }
            if(params.equalsIgnoreCase("town")){
                Location loc = player.getLocation();
                int x = loc.getChunk().getX();
                int z = loc.getChunk().getZ();
                Town town = null;
//                Earth.EarthChunk chunk = this.Plugin.getServerDatabase().getChunk(new Earth.ChunkPosition(x,z),loc.getWorld().getName());
//                if(chunk != null){
//                    if (chunk.townId()!=null){
//                        town = this.Plugin.getServerDatabase().getTown(UUID.fromString(chunk.townId()));
//                    }
//                }
                if (town==null){
                    return " ";
                }else if(town.getOwnerId().equals(player.getUniqueId())) {
                    return "[&3"+town.getOwnerName() +"&f]&2"+town.getName();
                }else{
                    return "[&b"+town.getOwnerName() +"&f]&5"+town.getName();
                }
            }
            return value;
        } catch (SQLException e) {
            Bukkit.broadcastMessage(ChatColor.RED + "Произошла ошибка при подключении к БД");
            throw new RuntimeException(e);
        }
    }


}
