package earthrp;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;
import java.util.List;

public final class Crafts {


    public static void enableCrafts(){
        ItemStack mora = new ItemStack(Material.GOLD_NUGGET, 1);
        ItemMeta moraMeta = mora.getItemMeta();
        assert moraMeta != null;
        moraMeta.setDisplayName(ChatColor.YELLOW + "Мора");
        moraMeta.setLore(Collections.singletonList("1 мора"));
        mora.setItemMeta(moraMeta);

        ItemStack manpower = new ItemStack(Material.VILLAGER_SPAWN_EGG, 1);
        ItemMeta manpowerMeta = manpower.getItemMeta();
        assert manpowerMeta != null;
        manpowerMeta.setDisplayName("Manpower");
        manpower.setItemMeta(manpowerMeta);


        ItemStack superMora = new ItemStack(Material.GOLD_INGOT, 1);
        ItemMeta superMoraMeta = superMora.getItemMeta();
        assert superMoraMeta != null;
        superMoraMeta.setDisplayName(ChatColor.YELLOW + "Горсть Моры");
        superMoraMeta.setLore(Collections.singletonList("9 моры"));
        superMora.setItemMeta(superMoraMeta);
        ShapedRecipe superMoraRecipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "superMora"), superMora);
        superMoraRecipe.shape("XXX","XXX", "XXX");
        superMoraRecipe.setIngredient('X', new RecipeChoice.ExactChoice(mora));
        Bukkit.addRecipe(superMoraRecipe);

        ItemStack megaMora = new ItemStack(Material.GOLD_BLOCK, 1);
        ItemMeta megaMoraMeta = megaMora.getItemMeta();
        assert megaMoraMeta != null;
        superMoraMeta.setDisplayName(ChatColor.YELLOW + "Сундук Моры");
        superMoraMeta.setLore(Collections.singletonList("81 моры"));
        megaMora.setItemMeta(superMoraMeta);
        ShapedRecipe megaMoraRecipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "megaMora"), megaMora);
        megaMoraRecipe.shape("XXX","XXX", "XXX");
        megaMoraRecipe.setIngredient('X', new RecipeChoice.ExactChoice(superMora));
        Bukkit.addRecipe(megaMoraRecipe);

        ItemStack art1 = new ItemStack(Material.GUARDIAN_SPAWN_EGG, 1);
        ItemMeta art1Meta = art1.getItemMeta();
        assert art1Meta != null;
        art1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cАртиллерия &a1&f уровня"));
        art1Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 15.0"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.0")
        ));
        art1.setItemMeta(art1Meta);
        ShapedRecipe art1Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "art1"), art1);
        art1Recipe.shape("#D#","GVG", "FWF");
        art1Recipe.setIngredient('W', new RecipeChoice.ExactChoice(megaMora));
        art1Recipe.setIngredient('#', Material.IRON_BLOCK);
        art1Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        art1Recipe.setIngredient('G', Material.GUNPOWDER);
        art1Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        art1Recipe.setIngredient('F', Material.FIRE_CHARGE);
        Bukkit.addRecipe(art1Recipe);

        ItemStack art2 = new ItemStack(Material.ELDER_GUARDIAN_SPAWN_EGG, 1);
        ItemMeta art2Meta = art2.getItemMeta();
        assert art2Meta != null;
        art2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&cАртиллерия &a2&f уровня"));
        art2Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 30.0"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.35")
        ));
        art2.setItemMeta(art2Meta);
        ShapedRecipe art2Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "art2"), art2);
        art2Recipe.shape("WAD","GVG", "FZF");
        art2Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(megaMora));
        art2Recipe.setIngredient('W', Material.IRON_BLOCK);
        art2Recipe.setIngredient('A', Material.AMETHYST_BLOCK);
        art2Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        art2Recipe.setIngredient('G', Material.GUNPOWDER);
        art2Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        art2Recipe.setIngredient('F', Material.FIRE_CHARGE);
        Bukkit.addRecipe(art2Recipe);
        ShapedRecipe art2RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "art2up"), art2);
        art2RecipeUp.shape("WAD","GVG", "FZF");
        art2RecipeUp.setIngredient('Z', new RecipeChoice.ExactChoice(megaMora));
        art2RecipeUp.setIngredient('W', Material.IRON_BLOCK);
        art2RecipeUp.setIngredient('A', Material.AMETHYST_BLOCK);
        art2RecipeUp.setIngredient('D', Material.DIAMOND_BLOCK);
        art2RecipeUp.setIngredient('G', Material.GUNPOWDER);
        art2RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(art1));
        art2RecipeUp.setIngredient('F', Material.FIRE_CHARGE);
        Bukkit.addRecipe(art2RecipeUp);

        ItemStack inf1 = new ItemStack(Material.ZOMBIE_SPAWN_EGG, 1);
        ItemMeta inf1Meta = inf1.getItemMeta();
        assert inf1Meta != null;
        inf1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&fПехота &a1&f уровня"));
        inf1Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.35"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.30")
        ));
        inf1.setItemMeta(inf1Meta);
        ShapedRecipe inf1Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf1"), inf1);
        inf1Recipe.shape("LSL","HVH", "FMF");
        inf1Recipe.setIngredient('M', new RecipeChoice.ExactChoice(superMora));
        inf1Recipe.setIngredient('L', Material.LEATHER);
        inf1Recipe.setIngredient('S', Material.STONE_SWORD);
        inf1Recipe.setIngredient('H', Material.HAY_BLOCK);
        inf1Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        inf1Recipe.setIngredient('F', Material.FLINT);
        Bukkit.addRecipe(inf1Recipe);

        ItemStack inf2 = new ItemStack(Material.SKELETON_SPAWN_EGG, 1);
        ItemMeta inf2Meta = inf2.getItemMeta();
        assert inf2Meta != null;
        inf2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&fПехота &a2&f уровня"));
        inf2Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.80"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.95")
        ));
        inf2.setItemMeta(inf2Meta);
        ShapedRecipe inf2Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf2"), inf2);
        inf2Recipe.shape("ILI","AVA", "HZH");
        inf2Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        inf2Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        inf2Recipe.setIngredient('I', Material.IRON_BLOCK);
        inf2Recipe.setIngredient('L', Material.LEATHER);
        inf2Recipe.setIngredient('A', Material.ARROW);
        inf2Recipe.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(inf2Recipe);
        ShapedRecipe inf2RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf2up"), inf2);
        inf2RecipeUp.shape("ILI","AVA", "H H");
        inf2RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(inf1));
        inf2RecipeUp.setIngredient('I', Material.IRON_BLOCK);
        inf2RecipeUp.setIngredient('L', Material.LEATHER);
        inf2RecipeUp.setIngredient('A', Material.ARROW);
        inf2RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(inf2RecipeUp);

        ItemStack inf3 = new ItemStack(Material.SPIDER_SPAWN_EGG, 1);
        ItemMeta inf3Meta = inf3.getItemMeta();
        assert inf3Meta != null;
        inf3Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&fПехота &a3&f уровня"));
        inf3Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 2.5"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.5")
        ));
        inf3.setItemMeta(inf3Meta);
        ShapedRecipe inf3Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf3"), inf3);
        inf3Recipe.shape("ILI","AVD", "HZH");
        inf3Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        inf3Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        inf3Recipe.setIngredient('I', Material.COOKED_PORKCHOP);
        inf3Recipe.setIngredient('L', Material.GUNPOWDER);
        inf3Recipe.setIngredient('A', Material.IRON_BLOCK);
        inf3Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        inf3Recipe.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(inf3Recipe);
        ShapedRecipe inf3RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf3up"), inf3);
        inf3RecipeUp.shape("ILI","AVD", "H H");
        inf3RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(inf2));
        inf3RecipeUp.setIngredient('I', Material.COOKED_PORKCHOP);
        inf3RecipeUp.setIngredient('L', Material.GUNPOWDER);
        inf3RecipeUp.setIngredient('A', Material.IRON_BLOCK);
        inf3RecipeUp.setIngredient('D', Material.DIAMOND_BLOCK);
        inf3RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(inf3RecipeUp);

        ItemStack inf4 = new ItemStack(Material.CREEPER_SPAWN_EGG, 1);
        ItemMeta inf4Meta = inf4.getItemMeta();
        assert inf4Meta != null;
        inf4Meta.setDisplayName( ChatColor.translateAlternateColorCodes('&', "&fПехота &a4&f уровня"));
        inf4Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 3.5"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 2.1")
        ));
        inf4.setItemMeta(inf4Meta);
        ShapedRecipe inf4Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf4"), inf4);
        inf4Recipe.shape("AGD","GVG", "HZH");
        inf4Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        inf4Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        inf4Recipe.setIngredient('H', Material.HAY_BLOCK);
        inf4Recipe.setIngredient('A', Material.AMETHYST_BLOCK);
        inf4Recipe.setIngredient('G', Material.GUNPOWDER);
        inf4Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        Bukkit.addRecipe(inf4Recipe);
        ShapedRecipe inf4RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "inf4up"), inf4);
        inf4RecipeUp.shape("AGD","GVG", "H H");

        inf4RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(inf3));
        inf4RecipeUp.setIngredient('A', Material.AMETHYST_BLOCK);
        inf4RecipeUp.setIngredient('G', Material.GUNPOWDER);
        inf4RecipeUp.setIngredient('D', Material.DIAMOND_BLOCK);
        inf4RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(inf4RecipeUp);

        ItemStack cav1 = new ItemStack(Material.CHICKEN_SPAWN_EGG, 1);
        ItemMeta cav1Meta = cav1.getItemMeta();
        assert cav1Meta != null;
        cav1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&eКавалерия &a1&f уровня"));
        cav1Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.0"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.60")
        ));
        cav1.setItemMeta(cav1Meta);
        ShapedRecipe cav1Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav1"), cav1);
        cav1Recipe.shape("LML","FVF", "HMH");
        cav1Recipe.setIngredient('M', new RecipeChoice.ExactChoice(superMora));
        cav1Recipe.setIngredient('L', Material.LEATHER);
        cav1Recipe.setIngredient('H', Material.HAY_BLOCK);
        cav1Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        cav1Recipe.setIngredient('F', Material.FLINT);
        Bukkit.addRecipe(cav1Recipe);

        ItemStack cav2 = new ItemStack(Material.PIG_SPAWN_EGG, 1);
        ItemMeta cav2Meta = cav2.getItemMeta();
        assert cav2Meta != null;
        cav2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&eКавалерия &a2&f уровня"));
        cav2Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.1"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 2.60")
        ));
        cav2.setItemMeta(cav2Meta);
        ShapedRecipe cav2Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav2"), cav2);
        cav2Recipe.shape("AML","IVI", "HZH");
        cav2Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        cav2Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        cav2Recipe.setIngredient('I', Material.IRON_BLOCK);
        cav2Recipe.setIngredient('L', Material.LEATHER);
        cav2Recipe.setIngredient('A', Material.ARROW);
        cav2Recipe.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(cav2Recipe);
        ShapedRecipe cav2RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav2up"), cav2);
        cav2RecipeUp.shape("A L","IVI", "H H");

        cav2RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(cav1));
        cav2RecipeUp.setIngredient('I', Material.IRON_BLOCK);
        cav2RecipeUp.setIngredient('L', Material.LEATHER);
        cav2RecipeUp.setIngredient('A', Material.ARROW);
        cav2RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(cav2RecipeUp);

        ItemStack cav3 = new ItemStack(Material.SHEEP_SPAWN_EGG, 1);
        ItemMeta cav3Meta = cav3.getItemMeta();
        assert cav3Meta != null;
        cav3Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&eКавалерия &a3&f уровня"));
        cav3Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.5"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 3.2")
        ));
        cav3.setItemMeta(cav3Meta);
        ShapedRecipe cav3Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav3"), cav3);
        cav3Recipe.shape("LZC","IVD", "HZG");
        cav3Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        cav3Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        cav3Recipe.setIngredient('C', Material.COOKED_PORKCHOP);
        cav3Recipe.setIngredient('L', Material.LEATHER);
        cav3Recipe.setIngredient('I', Material.IRON_BLOCK);
        cav3Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        cav3Recipe.setIngredient('H', Material.HAY_BLOCK);
        cav3Recipe.setIngredient('G', Material.GUNPOWDER);
        Bukkit.addRecipe(cav3Recipe);
        ShapedRecipe cav3RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav3up"), cav3);
        cav3RecipeUp.shape("LZC","IVD", "HZG");

        cav3RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(cav2));
        cav3RecipeUp.setIngredient('C', Material.COOKED_PORKCHOP);
        cav3RecipeUp.setIngredient('L', Material.LEATHER);
        cav3RecipeUp.setIngredient('I', Material.IRON_BLOCK);
        cav3RecipeUp.setIngredient('D', Material.DIAMOND_BLOCK);
        cav3RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        cav3RecipeUp.setIngredient('G', Material.GUNPOWDER);
        Bukkit.addRecipe(cav3RecipeUp);

        ItemStack cav4 = new ItemStack(Material.COW_SPAWN_EGG, 1);
        ItemMeta cav4Meta = cav4.getItemMeta();
        assert cav4Meta != null;
        cav4Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&eКавалерия &a4&f уровня"));
        cav4Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 1.0"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 4.0")
        ));
        cav4.setItemMeta(cav4Meta);
        ShapedRecipe cav4Recipe = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav4"), cav4);
        cav4Recipe.shape("ALD","GVG", "ZHZ");
        cav4Recipe.setIngredient('Z', new RecipeChoice.ExactChoice(superMora));
        cav4Recipe.setIngredient('V', new RecipeChoice.ExactChoice(manpower));
        cav3Recipe.setIngredient('L', Material.LEATHER);
        cav4Recipe.setIngredient('H', Material.HAY_BLOCK);
        cav4Recipe.setIngredient('A', Material.AMETHYST_BLOCK);
        cav4Recipe.setIngredient('G', Material.GUNPOWDER);
        cav4Recipe.setIngredient('D', Material.DIAMOND_BLOCK);
        Bukkit.addRecipe(cav4Recipe);
        ShapedRecipe cav4RecipeUp = new ShapedRecipe(new NamespacedKey(Earth.getInstance(), "cav4up"), cav4);
        cav4RecipeUp.shape("ALD","GVG", " H ");

        cav4RecipeUp.setIngredient('V', new RecipeChoice.ExactChoice(cav3));
        cav4RecipeUp.setIngredient('A', Material.AMETHYST_BLOCK);
        cav4RecipeUp.setIngredient('G', Material.GUNPOWDER);
        cav4RecipeUp.setIngredient('L', Material.LEATHER);
        cav4RecipeUp.setIngredient('D', Material.DIAMOND_BLOCK);
        cav4RecipeUp.setIngredient('H', Material.HAY_BLOCK);
        Bukkit.addRecipe(cav4RecipeUp);
    }
}
