package earthrp.listeners;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.files.CustomConfig;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.sql.SQLException;

public class JoinHandler implements Listener {

    private final Earth moraPlugin;

    public JoinHandler(Earth moraPlugin) {
        this.moraPlugin = moraPlugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerJoin(PlayerJoinEvent e) throws SQLException {
        Player oldPlayer = e.getPlayer();
        EarthPlayer p = new EarthPlayer(oldPlayer.getUniqueId(), oldPlayer.getDisplayName());
        if(!this.moraPlugin.getServerDatabase().playerExists(p.getUniqueId())){
            this.moraPlugin.getServerDatabase().addPlayer(this.moraPlugin.getServerDatabase().getConnection(), p);
            String path = "trade."+p.getDisplayName()+".";
            CustomConfig.set(path+p.getDisplayName(),"true");
            EarthPlayer[] players = this.moraPlugin.getServerDatabase().getPlayers();
            for (EarthPlayer player:players){
                if(!player.getUniqueId().equals(p.getUniqueId())){
                    CustomConfig.set(path+player.getDisplayName(),"false");
                    CustomConfig.set("trade."+player.getDisplayName()+"."+p.getDisplayName(),"false");
                }
            }
        }else if(!this.moraPlugin.getServerDatabase().playerNameActual(p)){
            EarthPlayer player = this.moraPlugin.getServerDatabase().getPlayer(p.getUniqueId());
            player.setDisplayName(p.getDisplayName());
            this.moraPlugin.getServerDatabase().updatePlayer(player);
        }



    }
}
