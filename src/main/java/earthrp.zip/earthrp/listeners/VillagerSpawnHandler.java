package earthrp.listeners;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.Town;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntitySpawnEvent;

import java.sql.SQLException;
import java.util.UUID;

public class VillagerSpawnHandler implements Listener {
    private final Earth earthPlugin;

    public VillagerSpawnHandler(Earth earthPlugin) {
        this.earthPlugin = earthPlugin;
    }
    @EventHandler
    public void onVillagerSpawn(EntitySpawnEvent e) throws SQLException {
        Entity entity = e.getEntity();
        if (entity.getCustomName() != null && entity.getType().equals(EntityType.VILLAGER)){
            Villager villager = (Villager) e.getEntity();
            String name = villager.getCustomName();
            if (name.startsWith("Villager")){
                UUID id = this.earthPlugin.getServerDatabase().getPlayerUuid(name.substring(9)); // (name.substring(8));
                EarthPlayer p = this.earthPlugin.getServerDatabase().getPlayer(id);
                e.setCancelled(true);
                Location loc = e.getLocation();
                Villager customVillager = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
                customVillager.setCustomName(name.substring(9));
                customVillager.setCustomNameVisible(true);
                customVillager.setAI(false);
                customVillager.setProfession(villager.getProfession());
                customVillager.setVillagerType(villager.getVillagerType());
                int x = loc.getChunk().getX();
                int z = loc.getChunk().getZ();
                Town[] towns = this.earthPlugin.getServerDatabase().getPlayerTowns(id);
                Town town = null;
                double min = Earth.getInstance().getConfig().getInt("townSize");
                if(towns!=null){
                    for(Town t: towns){
                        int distance = Earth.getDistance(x,z,t.getChunkX(),t.getChunkZ());
                        if ((distance < min)&& t.getStatus()!=0 ){
                            town = t;
                            min = distance;
                        }
                    }
                }
                if(town != null){
                    int tax = town.getHouses();
                    town.setHouses(tax+1);
                }else{
                    p.setIncome(p.getIncome()+1);
                    this.earthPlugin.getServerDatabase().updatePlayer(p);
                }

            }
        }
    }
    @EventHandler
    public void onVillagerKilled(EntityDeathEvent e) throws SQLException {
        Entity villager = e.getEntity();
        if (villager.getCustomName() != null && villager.getType().equals(EntityType.VILLAGER)){
            String name = villager.getCustomName();
            UUID id = this.earthPlugin.getServerDatabase().getPlayerUuid(name);
            EarthPlayer p = this.earthPlugin.getServerDatabase().getPlayer(id);
            Location loc = villager.getLocation();
            int x = loc.getChunk().getX();
            int z = loc.getChunk().getZ();
            Town[] towns = this.earthPlugin.getServerDatabase().getPlayerTowns(id);
            Town town = null;
            double min = Earth.getInstance().getConfig().getInt("townSize");
            if(towns!=null){
                for(Town t: towns){
                    int distance = Earth.getDistance(x,z,t.getChunkX(),t.getChunkZ());
                    if ((distance < min)&& t.getStatus()!=0 ){
                        town = t;
                        min = distance;
                    }
                }
            }
            if(town != null){
                int tax = town.getHouses();
                town.setHouses(tax-1);
            }else{
                p.setIncome(p.getIncome()-1);
                this.earthPlugin.getServerDatabase().updatePlayer(p);
            }
        }

    }
}
