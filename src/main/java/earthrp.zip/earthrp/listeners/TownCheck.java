package earthrp.listeners;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.Town;
import earthrp.events.TownCheckEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.sql.SQLException;

public class TownCheck implements Listener {

    private final Earth earthPlugin;

    public TownCheck( Earth moraPlugin) {
        this.earthPlugin = moraPlugin;
    }

    @EventHandler
    public void townCheck(TownCheckEvent e) throws SQLException {
        EarthPlayer[] players = this.earthPlugin.getServerDatabase().getPlayers();
        for (EarthPlayer p:players){
            Town[] towns = this.earthPlugin.getServerDatabase().getPlayerTowns(p.getUniqueId());
            int tax = 0;
            if (towns != null){
                for (Town t:towns){
                    tax += t.getPeople();
                }
            }
            p.setTaxIncome(tax);
            this.earthPlugin.getServerDatabase().updatePlayer(p);
        }
    }
}
