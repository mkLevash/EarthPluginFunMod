package earthrp.listeners;

import earthrp.Building;
import earthrp.Earth;
import earthrp.Market;
import earthrp.Town;
import earthrp.database.ServerDatabase;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class MarketsHandler implements Listener {

    private final Earth earthPlugin;
    ServerDatabase db;
    public MarketsHandler(Earth moraPlugin) {

        this.earthPlugin = moraPlugin;
        this.db = this.earthPlugin.getServerDatabase();
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) throws SQLException {
        ItemStack item = e.getCurrentItem();
        boolean bool = e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY) && String.valueOf(e.getInventory().getType()).equals("CHEST") && Objects.requireNonNull(Objects.requireNonNull(item).getItemMeta()).getLore() != null;
        if (bool){
            ItemMeta itemMeta = item.getItemMeta();
            List<String> lore = Objects.requireNonNull(itemMeta.getLore());
            String itemType = lore.get(0);
            if (itemType.equals("market") ){
                UUID marketId = UUID.fromString(lore.get(1));
                String type = lore.get(2);
                Location loc = e.getInventory().getLocation();
                assert loc != null;
                String world = Objects.requireNonNull(loc.getWorld()).getName();
                int x = loc.getChunk().getX();
                int z = loc.getChunk().getZ();
                if(e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY)){
                    if (!this.earthPlugin.getServerDatabase().marketExists(marketId)){
                        Town town = null;
                        Earth.EarthChunk chunk = db.getChunk(new Earth.ChunkPosition(x,z),loc.getWorld().getName());
                        if(chunk != null){
                            if (chunk.townId()!=null){
                                town = db.getTown(UUID.fromString(chunk.townId()));
                            }
                        }
                        if (town != null && town.getBuildings()<town.getBuildSite()){

                            ArmorStand hologram0 = (ArmorStand) Bukkit.getWorld(world).spawnEntity(loc, EntityType.ARMOR_STAND);
                            hologram0.setVisible(false);
                            hologram0.setCustomNameVisible(false);
                            hologram0.setCustomName(String.valueOf(marketId));
                            hologram0.setGravity(false);
                            ArmorStand hologram = (ArmorStand) Bukkit.getWorld(world).spawnEntity(loc.add(0.5,-1,0.5), EntityType.ARMOR_STAND);
                            hologram.setVisible(false);
                            hologram.setCustomNameVisible(true);
                            hologram.setCustomName(itemMeta.getDisplayName());
                            hologram.setGravity(false);

                            String townName = town.getName();
                            UUID townId = town.getUniqueId();
                            this.earthPlugin.getServerDatabase().addMarket(town, marketId, type, loc);
                            int buildingAmount = town.getBuildings();
                            town.setBuildings(buildingAmount+1);
                            this.earthPlugin.getServerDatabase().updateTown(town);

                        }else{
                            e.setCancelled(true);
                        }



                    }else {

                        Market market = this.earthPlugin.getServerDatabase().getMarket(marketId);
                        System.out.println(market.getGoods());
                        if(market.getGoods()==0){
                            this.earthPlugin.getServerDatabase().deleteMarket(market);
                            e.getWhoClicked().getInventory().addItem(item);
                        }else{
                            e.setCancelled(true);
                        }
                    }

                }
            }
        }
    }
}
