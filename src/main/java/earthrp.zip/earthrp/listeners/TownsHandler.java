package earthrp.listeners;


import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.Town;
import earthrp.database.ServerDatabase;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.dynmap.DynmapAPI;
import org.dynmap.markers.AreaMarker;
import org.dynmap.markers.Marker;
import org.dynmap.markers.MarkerAPI;
import org.dynmap.markers.MarkerSet;

import java.sql.SQLException;
import java.util.*;

import static earthrp.Pathfinding.isLandPathBetween;


public class TownsHandler implements Listener {

    private final Earth earthPlugin;
    int townSize = Earth.getInstance().getConfig().getInt("townSize");
    public TownsHandler(Earth moraPlugin) {
        this.earthPlugin = moraPlugin;
        db = this.earthPlugin.getServerDatabase();
    }
    ServerDatabase db;



    @EventHandler
    public void onMenuClick(InventoryClickEvent e) throws SQLException {

        boolean bool = e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY) && String.valueOf(e.getInventory().getType()).equals("CHEST") && Objects.requireNonNull(Objects.requireNonNull(e.getCurrentItem()).getItemMeta()).getLore() != null;
        if (bool){
            if(e.getCurrentItem().getItemMeta().getLore() != null ){

                String type = String.valueOf(Objects.requireNonNull(e.getCurrentItem().getItemMeta().getLore()).get(0));

                if((type.equals("capital") || type.equals("townHall")) && String.valueOf(e.getInventory().getType()).equals("CHEST") ){
                    UUID townId = UUID.fromString(String.valueOf(Objects.requireNonNull(e.getCurrentItem().getItemMeta().getLore()).get(1)));
                    Location loc = e.getInventory().getLocation();
                    assert loc != null;
                    String world = Objects.requireNonNull(loc.getWorld()).getName();
                    int x = loc.getChunk().getX();
                    int z = loc.getChunk().getZ();
                    UUID ownerId = UUID.fromString(String.valueOf(Objects.requireNonNull(e.getCurrentItem().getItemMeta().getLore()).get(2)));
                    String ownerName = String.valueOf(Objects.requireNonNull(e.getCurrentItem().getItemMeta().getLore()).get(3));
                    if( e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY)){
                        String townName = e.getCurrentItem().getItemMeta().getDisplayName();

                        if (!db.townExists(townId)){
                            Town town = null;
                            Earth.EarthChunk chunk = db.getChunk(new Earth.ChunkPosition(x,z),loc.getWorld().getName());
                            if(chunk != null){
                                if (chunk.townId()!=null){
                                    town = db.getTown(UUID.fromString(chunk.townId()));
                                }
                            }
                            if(town!=null){
                                e.setCancelled(true);
                                e.getWhoClicked().sendMessage("Слишком близко к другому городу");
                            }else{
                                ArmorStand hologram = (ArmorStand) Bukkit.getWorld(world).spawnEntity(loc.add(0.5,-1,0.5), EntityType.ARMOR_STAND);
                                hologram.setVisible(false);
                                hologram.setCustomNameVisible(true);
                                hologram.setCustomName(townName);
                                hologram.setGravity(false);
                                hologram.setCollidable(false);
                                db.addTown(ownerName,townName,townId,ownerId,type,world,x,z,0);
                                town = db.getTown(townId);
                                Town finalTown = town;
                                this.earthPlugin.markNonWaterChunksAsync(town, (occupiedChunks) -> {
                                    // Здесь чанки уже помечены, можно сохранить в базу или в кэш
                                    Bukkit.broadcastMessage("Готово! Всего занято: " + occupiedChunks.size());
                                    earthPlugin.drawTownBorderAsync(finalTown)
                                            .thenRun(() -> Bukkit.broadcastMessage("Границы города " + townName+ " успешно отрисованы"))
                                            .exceptionally(ex -> {
                                                Bukkit.getLogger().warning("Ошибка при отрисовке границ");
                                                return null;
                                            });


                                });

                            }

                        }else{
                            Town town = db.getTown(townId);
                            db.deleteTown(town);
                            earthPlugin.drawTownBorderAsync(town)
                                    .thenRun(() -> Bukkit.broadcastMessage("Границы города " + townName + " успешно удалены"))
                                    .exceptionally(ex -> {
                                        Bukkit.getLogger().warning("Ошибка при отрисовке границ");
                                        return null;
                                    });

//                            if (town.getStatus() != 0){
//                                town.setStatus(0);
//                                db.updateTown(town);
//                                Entity[] tileEntities = Objects.requireNonNull(Bukkit.getWorld(world)).getChunkAt(x, z).getEntities();
//                                for(Entity en: tileEntities){
//                                    if (en instanceof ArmorStand armor){
//                                        if(Objects.equals(armor.getCustomName(), townName)){
//                                            armor.remove();
//                                        }
//
//                                    }
//                                }
//
//                            }else{
//                                town.setStatus(1);
//                                db.updateTown(town);
//                                ArmorStand hologram = (ArmorStand) Objects.requireNonNull(Bukkit.getWorld(world)).spawnEntity(loc.add(0.5,-1,0.5), EntityType.ARMOR_STAND);
//                                hologram.setVisible(false);
//                                hologram.setCustomNameVisible(true);
//                                hologram.setCustomName(townName);
//                                hologram.setGravity(false);
//                            }
                        }


                    }
                }
            }
        }


    }
}
