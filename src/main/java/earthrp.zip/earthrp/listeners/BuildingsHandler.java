package earthrp.listeners;

import earthrp.Building;
import earthrp.Earth;
import earthrp.Town;
import earthrp.database.ServerDatabase;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.logging.Level;

public class BuildingsHandler implements Listener {

    private static final String NO_BUILD_SLOTS_MSG = "Недостаточно ячеек строительства";
    private final Object dbLock = new Object();
    ServerDatabase db;

    public BuildingsHandler( Earth moraPlugin) {
        this.db = moraPlugin.getServerDatabase();
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) {
        try {
            if (!isValidBuildingTransfer(e)) {
                return;
            }

            ItemStack item = e.getCurrentItem();
            ItemMeta meta = item.getItemMeta();
            UUID buildingId = UUID.fromString(meta.getLore().get(1));

            if (db.buildingExists(buildingId)) {
                handleExistingBuilding(e, buildingId, item);
            } else {
                handleNewBuilding(e, buildingId, meta);
            }
        } catch (SQLException ex) {
            Bukkit.getLogger().severe("Database error: " + ex.getMessage());
            e.setCancelled(true);
        }
    }

    private void handleExistingBuilding(InventoryClickEvent e, UUID buildingId,  ItemStack item) throws SQLException {
        Building building = db.getBuilding(buildingId);
        if(building.getItem()==null){
            db.deleteBuilding(building);
            e.getWhoClicked().getInventory().addItem(item);
        }else{
            e.setCancelled(true);
        }
    }



    private void handleNewBuilding(InventoryClickEvent e, UUID buildingId, ItemMeta meta){

        try {
            // 1. Получаем данные чанка и города
            String type = meta.getLore().get(2);
            Location loc = e.getInventory().getLocation();
            int x = loc.getChunk().getX();
            int z = loc.getChunk().getZ();
            Town town = null;
            Town[] towns = db.getTowns();
            double min = Earth.getInstance().getConfig().getInt("townSize")*4;
            for (Town t : towns){
                double distance = Earth.calculateDistance(x,z,t.getChunkX(),t.getChunkZ());
                if(distance<min){
                    town = t;
                    min = distance;
                }
            }


            if (town == null) {
                cancelEventWithMessage(e, "Город не найден");
                return;
            }

            // 2. Проверяем лимит строительства
            if (town.getBuildings() >= town.getBuildSite()) {
                cancelEventWithMessage(e, NO_BUILD_SLOTS_MSG);
                return;
            }

            // 3. Создаем голограммы
            createBuildingHolograms(loc, buildingId, meta.getDisplayName());

            // 4. Обновляем данные в БД
            updateTownAndBuildingData(town, buildingId, type, loc);

        } catch (SQLException ex) {
            cancelEventWithMessage(e, "Ошибка базы данных");
            Bukkit.getLogger().log(Level.SEVERE, "DB error while adding building", ex);
        }

    }

    private void createBuildingHolograms(Location loc, UUID buildingId, String displayName) {

        // Голограмма для ID здания
        spawnHologram(loc.getWorld(), loc.clone(), String.valueOf(buildingId), false);

        // Голограмма для отображаемого имени
        spawnHologram(loc.getWorld(), loc.clone().add(0.5, -1, 0.5), displayName, true);
    }

    private ArmorStand spawnHologram(World world, Location loc, String text, boolean visible) {
        ArmorStand hologram = (ArmorStand) world.spawnEntity(loc, EntityType.ARMOR_STAND);
        hologram.setVisible(false);
        hologram.setCustomNameVisible(visible);
        hologram.setCustomName(text);
        hologram.setGravity(false);
        hologram.setCollidable(false);
        //hologram.setInvulnerable(true); // Защита от случайного удаления
        return hologram;
    }

    private void updateTownAndBuildingData(Town town, UUID buildingId, String type, Location loc) throws SQLException {
        // Обновляем данные в транзакции

        db.addBuilding(
                town.getName(),
                buildingId,
                town.getUniqueId(),
                type,
                loc.getWorld().getName(),
                loc.getChunk().getX(),
                loc.getChunk().getZ()
        );

        town.setBuildings(town.getBuildings() + 1);
        db.updateTown(town);
//        try (Connection conn = db.getConnection()) {
//            conn.setAutoCommit(false); // Начинаем транзакцию
//
//            try {
//
//
//                conn.commit(); // Всё прошло успешно — коммитим
//
//            } catch (SQLException e) {
//                conn.rollback(); // Откат в случае ошибки
//                throw e;
//            }
//
//        } catch (SQLException ex) {
//            System.err.println("Transaction failed: " + ex.getMessage());
//            throw ex;
//        }
    }

    private boolean isValidBuildingTransfer(InventoryClickEvent e) {
        return e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY
                && e.getInventory().getType() == InventoryType.CHEST
                && e.getCurrentItem() != null
                && e.getCurrentItem().getItemMeta() != null
                && e.getCurrentItem().getItemMeta().getLore() != null
                && e.getCurrentItem().getItemMeta().getLore().get(0).equals("building");
    }

    private void cancelEventWithMessage(InventoryClickEvent e, String message) {
        e.setCancelled(true);
        e.getWhoClicked().sendMessage(message);
    }

//    @EventHandler
//    public void onMenuClick(InventoryClickEvent e) throws SQLException {
//        Bukkit.broadcastMessage(String.valueOf(e.getAction()));
////         = e.getAction().equals(InventoryAction.PICKUP_ALL);
//        boolean b = e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY) && String.valueOf(e.getInventory().getType()).equals("CHEST") && Objects.requireNonNull(Objects.requireNonNull(e.getCurrentItem()).getItemMeta()).getLore() != null;
//        if (b){
//            //System.out.println(e.getCurrentItem().getItemMeta().getPersistentDataContainer());
//            ItemStack item = e.getCurrentItem();
//            ItemMeta itemMeta = item.getItemMeta();
//            List<String> lore = Objects.requireNonNull(itemMeta.getLore());
//            String itemType = lore.get(0);
//            if (itemType.equals("building") ){
//                UUID buildingId = UUID.fromString(lore.get(1));
//                String type = lore.get(2);
//                Location loc = e.getInventory().getLocation();
//                assert loc != null;
//                String world = Objects.requireNonNull(loc.getWorld()).getName();
//                int x = loc.getChunk().getX();
//                int z = loc.getChunk().getZ();
//                if(e.getAction().equals(InventoryAction.MOVE_TO_OTHER_INVENTORY)){
//                    if (!db.buildingExists(buildingId)){
//                        Town town = null;
//                        Earth.EarthChunk chunk = db.getChunk(new Earth.ChunkPosition(x,z),loc.getWorld().getName());
//                        if(chunk != null){
//                            if (chunk.townId()!=null){
//                                town = db.getTown(UUID.fromString(chunk.townId()));
//                            }
//                        }
//                        if (town != null && town.getBuildings()<town.getBuildSite()){
//                            ArmorStand hologram0 = (ArmorStand) Bukkit.getWorld(world).spawnEntity(loc, EntityType.ARMOR_STAND);
//                            hologram0.setVisible(false);
//                            hologram0.setCustomNameVisible(false);
//                            hologram0.setCustomName(String.valueOf(buildingId));
//                            hologram0.setGravity(false);
//                            hologram0.setCollidable(false);
//                            ArmorStand hologram = (ArmorStand) Bukkit.getWorld(world).spawnEntity(loc.add(0.5,-1,0.5), EntityType.ARMOR_STAND);
//                            hologram.setVisible(false);
//                            hologram.setCustomNameVisible(true);
//                            hologram.setCustomName(itemMeta.getDisplayName());
//                            hologram.setGravity(false);
//                            hologram.setCollidable(false);
//
//                            String townName = town.getName();
//                            UUID townId = town.getUniqueId();
//                            db.addBuilding(townName,buildingId,townId,type,loc.getWorld().getName(),loc.getChunk().getX(),loc.getChunk().getZ());
//                            int buildingAmount = town.getBuildings();
//                            town.setBuildings(buildingAmount+1);
//                            db.updateTown(town);
//                        }else{
//                            e.setCancelled(true);
//                            e.getWhoClicked().sendMessage("Недостаточно ячеек строительства");
//                        }
//
//
//
//                    }else {
//
//                        Building building = db.getBuilding(buildingId);
//                        if(building.getItem()==null){
//                            db.deleteBuilding(building);
//                            e.getWhoClicked().getInventory().addItem(item);
//                        }else{
//                            e.setCancelled(true);
//                        }
//                    }
//
//                }
//            }
//        }
//    }
    @EventHandler
    public void onBuild(BlockPlaceEvent e){
        ItemStack building = e.getItemInHand();
        ItemMeta buildingMeta = building.getItemMeta();
        if(buildingMeta.getEnchantLevel(Enchantment.INFINITY)==1){
            e.setCancelled(true);
        }
    }
    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        Block block = e.getBlock();

        // Проверяем, является ли блок сундуком
        if (!(block.getState() instanceof Chest chest)) return;

        // Получаем содержимое инвентаря сундука
        ItemStack[] contents = chest.getBlockInventory().getContents();

        if (contents == null) return;

        for (ItemStack item : contents) {
            if (item == null || !item.hasItemMeta()) continue;

            ItemMeta meta = item.getItemMeta();
            if (!meta.hasLore()) continue;

            List<String> lore = meta.getLore();
            if (lore == null || lore.isEmpty()) continue;

            String tag = lore.get(0).toLowerCase();
            if (tag.equals("building") || tag.equals("capital") || tag.equals("townhall")) {
                e.setCancelled(true);
                return; // Прерываем дальше, блокировать достаточно один раз
            }
        }
    }


}
