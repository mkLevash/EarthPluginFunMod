package earthrp.listeners;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.events.NewDayEvent;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import static java.lang.Integer.parseInt;

public class MoraCount implements Listener {

    private final Earth plugin;

    public MoraCount (Earth plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onNewDay(NewDayEvent e) throws SQLException {

        EarthPlayer[] players = this.plugin.getServerDatabase().getPlayers();
        boolean status = this.plugin.getServerDatabase().getStatusMora();
        if (status) {
            Bukkit.broadcastMessage("New day!");
            for(EarthPlayer p:players){
                int balance = this.plugin.getBalance(p);
                p.setTreasury(p.getTreasury()+balance);

                int oi_income = p.getOiIncome();
                int oi_balance = p.getOiBalance();
                p.setOiBalance(oi_balance+oi_income);

                int pp_balance = p.getPolitBalance();
                int pp_income = p.getPolitIncome();
                int politIncomeMod = p.getPolitIncomeMod();
                int politIncome = (int) Math.floor(pp_income*(politIncomeMod*0.01+1));
                int pp_max = p.getPolitMax();
                int politMaxMod = p.getPolitMaxMod();
                int politMax = (int) Math.floor(pp_max*(politMaxMod*0.01+1));
                p.setPolitBalance(Math.min(politMax, pp_balance + politIncome));

                int manpowerLimit = (int) Math.floor(p.getTaxIncome() * (p.getManpowerMod() * 0.01 + 1));
                if (p.getWarStatus() == 0){
                    p.setManpower(manpowerLimit);
                }else{
                    int manpower = p.getManpower();
                    int manpowerIncrease = p.getWarSup() + p.getManpowerIncMod();
                    p.setManpower(Math.min(manpowerLimit, manpower + manpowerIncrease));
                }
                this.plugin.getServerDatabase().updatePlayer(p);
            }
            int day = parseInt(this.plugin.getServerDatabase().getStatusDay());
            day += 1;
            this.plugin.getServerDatabase().updateStatusDay(String.valueOf(day));
        }



    }

}
