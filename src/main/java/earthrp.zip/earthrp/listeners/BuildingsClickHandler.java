package earthrp.listeners;

import earthrp.Building;
import earthrp.Earth;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.buildings.MiningBuildingMenu;
import earthrp.menusystem.menu.buildings.ScienceBuildingMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

public class BuildingsClickHandler implements Listener {

    private final Earth earthPlugin;

    public BuildingsClickHandler(Earth moraPlugin) {
        this.earthPlugin = moraPlugin;
    }

    @EventHandler
    public void onMenuClick(InventoryClickEvent e) throws SQLException {
        Bukkit.broadcastMessage(String.valueOf(e.getAction()));
        boolean bool = e.getAction().equals(InventoryAction.PICKUP_ALL) && String.valueOf(e.getInventory().getType()).equals("CHEST") && Objects.requireNonNull(Objects.requireNonNull(e.getCurrentItem()).getItemMeta()).getLore() != null;
        if (bool){
            e.setCancelled(true);
            ItemMeta itemMeta = e.getCurrentItem().getItemMeta();
            List<String> lore = Objects.requireNonNull(itemMeta.getLore());
            String itemType = lore.get(0);
            if (itemType.equals("building") ){
                UUID buildingId = UUID.fromString(lore.get(1));
                String type = lore.get(2);
                if(this.earthPlugin.getServerDatabase().buildingExists(buildingId)){
                    Building building = this.earthPlugin.getServerDatabase().getBuilding(buildingId);
                    Player p = (Player) e.getWhoClicked();
                    e.getWhoClicked().closeInventory();
                    PlayerMenuUtility playerMenuUtility = Earth.getPlayerMenuUtility(p);
                    playerMenuUtility.setBuilding(building);
                    System.out.println(type);

                    switch (type) {
                        case "mineV1":
                        case "mineV2":
                        case "career":
                        case "lumber":
                        case "pasture":
                        case "farm":
                        case "plant":
                        case "factory":
                            new MiningBuildingMenu(playerMenuUtility, this.earthPlugin).open();
                            break;
                        case "school":
                        case "university":
                            new ScienceBuildingMenu(playerMenuUtility, this.earthPlugin).open();
                            break;
                        default:
                            p.sendMessage(ChatColor.RED + "Неизвестный тип здания: " + type);
                            break;
                    }
                }

            }
        }
    }

}
