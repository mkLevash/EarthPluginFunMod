package earthrp.files;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class CustomConfig {

    private final static CustomConfig instance = new CustomConfig();

    private static File file;
    private static FileConfiguration customFile;

    //генерация файла конфига
    public static void setup(){
        file = new File(Bukkit.getServer().getPluginManager().getPlugin("Earth").getDataFolder(), "EarthConfig.yml");

        if (!file.exists()){
            try{
                file.createNewFile();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        customFile = YamlConfiguration.loadConfiguration(file);
        get().addDefault("tech.cost.tech1",15);
        get().addDefault("tech.name.tech1","Банкирство");
        get().addDefault("tech.cost.tech2",80);
        get().addDefault("tech.name.tech2","Развитая банковская система");
        get().addDefault("tech.cost.tech3",10);
        get().addDefault("tech.name.tech3","Торговля");
        get().addDefault("tech.cost.tech4",10);
        get().addDefault("tech.name.tech4","Мореплавание");
        get().addDefault("tech.cost.tech5",90);
        get().addDefault("tech.name.tech5","Железные Дороги");
        get().addDefault("tech.cost.tech6",10);
        get().addDefault("tech.name.tech6","Дипломатия");
        get().addDefault("tech.cost.tech7",10);
        get().addDefault("tech.name.tech7","Базовая канцелярия");
        get().addDefault("tech.cost.tech8",30);
        get().addDefault("tech.name.tech8","Развитая бюрократия");
        get().addDefault("tech.cost.tech9",30);
        get().addDefault("tech.name.tech9","Школы");
        get().addDefault("tech.cost.tech10",50);
        get().addDefault("tech.name.tech10","Университеты");
        get().addDefault("tech.cost.tech11",100);
        get().addDefault("tech.name.tech11","Министерства");
        get().addDefault("tech.cost.tech12",100);
        get().addDefault("tech.name.tech12","Многосторонние союзы");
        get().addDefault("tech.cost.tech13",100);
        get().addDefault("tech.name.tech13","Административная эффективность");
        get().addDefault("tech.cost.tech14",10);
        get().addDefault("tech.name.tech14","Пастбища");
        get().addDefault("tech.cost.tech15",10);
        get().addDefault("tech.name.tech15","Лесопилки");
        get().addDefault("tech.cost.tech16",15);
        get().addDefault("tech.name.tech16","Шахта");
        get().addDefault("tech.cost.tech17",40);
        get().addDefault("tech.name.tech17","Рудник");
        get().addDefault("tech.cost.tech18",75);
        get().addDefault("tech.name.tech18","Карьер");
        get().addDefault("tech.cost.tech19",15);
        get().addDefault("tech.name.tech19","Кузница");
        get().addDefault("tech.cost.tech20",15);
        get().addDefault("tech.name.tech20","Верфь");
        get().addDefault("tech.cost.tech21",50);
        get().addDefault("tech.name.tech21","Мануфактура");
        get().addDefault("tech.cost.tech22",80);
        get().addDefault("tech.name.tech22","Завод");
        get().addDefault("tech.cost.tech23",10);
        get().addDefault("tech.name.tech23","Военная канцелярия");
        get().addDefault("tech.cost.tech24",15);
        get().addDefault("tech.name.tech24","Крепость");
        get().addDefault("tech.cost.tech25",15);
        get().addDefault("tech.name.tech25","Система призыва");
        get().addDefault("tech.cost.tech26",30);
        get().addDefault("tech.name.tech26","Осадные тактики");
        get().addDefault("tech.cost.tech27",30);
        get().addDefault("tech.name.tech27","Обработка металла");
        get().addDefault("tech.cost.tech28",30);
        get().addDefault("tech.name.tech28","Стандартизация");
        get().addDefault("tech.cost.tech29",30);
        get().addDefault("tech.name.tech29","Тяжёлая кавалерия");
        get().addDefault("tech.cost.tech30",150);
        get().addDefault("tech.name.tech30","Порох");
        get().addDefault("tech.cost.tech31",30);
        get().addDefault("tech.name.tech31","Пехота 2 уровня");
        get().addDefault("tech.cost.tech32",50);
        get().addDefault("tech.name.tech32","Пехота 3 уровня");
        get().addDefault("tech.cost.tech33",75);
        get().addDefault("tech.name.tech33","Пехота 4 уровня");
        get().addDefault("tech.cost.tech34",10);
        get().addDefault("tech.name.tech34","Кавалерия 1 уровня");
        get().addDefault("tech.cost.tech35",30);
        get().addDefault("tech.name.tech35","Кавалерия 2 уровня");
        get().addDefault("tech.cost.tech36",50);
        get().addDefault("tech.name.tech36","Кавалерия 3 уровня");
        get().addDefault("tech.cost.tech37",75);
        get().addDefault("tech.name.tech37","Кавалерия 4 уровня");
        get().addDefault("tech.cost.tech38",75);
        get().addDefault("tech.name.tech38","Артиллерия 1 уровня");
        get().addDefault("tech.cost.tech39",100);
        get().addDefault("tech.name.tech39","Артиллерия 2 уровня");
        get().addDefault("tech.cost.tech40",10);
        get().addDefault("tech.name.tech40","ревизия");
        get().addDefault("tech.cost.tech41",10);
        get().addDefault("tech.name.tech41","идеи");

        get().addDefault("trade.playerName.playerName","true");


        List<String> forbiddenPatterns = Arrays.asList(
                "POTION", "LINGERING", "SPLASH",
                "ENCHANTED_BOOK", "PROPAGULE", "DEAD_BUSH", "COBWEB", "SEA_PICKLE", "SPONGE",
                "SPAWN_EGG",
                "SPAWNER",
                "SCULK",
                "COMMAND_BLOCK",
                "STRUCTURE_VOID", "BARRIER",
                "COMMAND_BLOCK_MINECART",
                "STRUCTURE_BLOCK", "JIGSAW",
                "EXPERIENCE_BOTTLE",
                "SMITHING_TEMPLATE",
                "TRIAL_KEY",
                "POTTERY_SHERD", "DECORATED_POT",
                "NETHER_STAR",
                "OMINOUS_BOTTLE",
                "TOTEM_OF_UNDYING",
                "SWORD", "AXE", "PICKAXE", "SHOVEL", "HOE",
                "HELMET", "CHESTPLATE", "LEGGINGS", "BOOTS",
                "SHIELD", "BOW", "CROSSBOW", "TRIDENT",
                "FISHING_ROD", "FLINT_AND_STEEL", "SHEARS", "BRUSH",
                "MACE", "ELYTRA",
                "MUSIC_DISC",
                "GOAT_HORN",
                "BOAT", "MINECART", "CHEST_BOAT", "CHEST_MINECART",
                "FURNACE_MINECART", "HOPPER_MINECART", "TNT_MINECART",
                "RAIL", "SADDLE", "DRAGON_EGG", "BEACON", "FARMLAND", "SNOW", "STAIRS",
                "BUNDLE", "LECTERN", "TARGET", "ROD", "DETECTOR", "HOOK", "HAY_BLOCK", "CARPET", "ANVIL",
                "PAINTING", "ON_A_STICK", "END", "REPEATER", "COMPARATOR", "PISTON", "SLAB", "OBSERVER", "HOPPER", "DISPENSER","DROPPER",
                "END_CRYSTAL", "CONDUIT",
                "SAPLING", "HEART", "TABLE", "CHEST", "LIGHT", "BOX", "TURTLE_EGG", "SNIFFER_EGG",
                "MUSHROOM", "END_TORCH",
                "FLOWER", "GRASS", "FERN", "LEAVES", "TULIP", "ORCHID", "FLOWER", "ALLIUM", "AZURE_BLUET", "BLUE_ORCHID",
                "DANDELION", "CORNFLOWER", "POPPY", "OXEYE_DAISY", "WITHER_ROSE", "LILY_OF_THE_VALLEY", "RED_TULIP",
                "ORANGE_TULIP", "WHITE_TULIP", "PINK_TULIP", "YELLOW_TULIP", "TORCHFLOWER",
                "GRASS", "TALL_GRASS", "FERN", "LARGE_FERN", "DEAD_BUSH", "SHRUB",
                "LEAVES", // Общее имя — не конкретный ID, но подходит под паттерн
                "SPORE_BLOSSOM", "PEONY", "ROSE_BUSH", "LILAC", "SUNFLOWER",
                "SMALL_DRIPLEAF", "BIG_DRIPLEAF", "AZALEA", "FLOWERING_AZALEA", "SEAGRASS", "TALL_SEAGRASS",

                "VINE", "LILY", "AZALEA", "ROOTS", "VAULT", "DRIPSTONE", "FROG", "BED", "SEEDS", "FLESH", "TEAR", "NUGGET", "STAND", "BONE", "BUCKET",
                "HANGING", "MOSS", "SEAGRASS", "KELP", "OBSIDIAN", "BEE", "AMETHYST", "COMPASS", "CLOCK", "SIGN", "WATER", "NETHERITE",
                "BAMBOO", "CACTUS", "CORAL", "DRIPLEAF", "SKULL", "BOOK", "WIND", "CAULDRON", "PATTERN", "SHULKER", "DRAGON", "CAMPFIRE",
                "SPROUTS", "WEEPING", "TWISTING", "WART", "WALL", "PLATE", "DOOR", "BUTTON", "GATE", "TRAPDOOR", "ARMOR", "GOLDEN_APPLE", "CRAFTER",
                "CRIMSON", "WARPED", "BOOKSHELF", "CHORUS", "EYEBLOSSOM", "PLANT", "PETALS", "FENCE", "LADDER", "FURNACE", "LICHEN",
                "HEAD", "ARMOUR", "ORE", "RAW", "BANNER", "TORCH", "SOUL", "FIRE", "GOLDEN_CARROT", "DISC", "DEBUG",
                "IRON_BLOCK","COPPER_BLOCK", "GOLD_BLOCK", "DIAMOND_BLOCK","COAL_BLOCK", "EMERALD_BLOCK", "DEBRIS"
        );
        get().addDefault("items.banned",forbiddenPatterns);


    }

    public static FileConfiguration get(){
        return customFile;
    }

    public static void save(){
        try {
            customFile.save(file);
        }catch (IOException e){
            System.out.println("couldn't save config file");
        }
    }


    public static void set(String path, Object value){
        customFile.set(path, value);
        save();
    }

    public static void reload(){
        customFile = YamlConfiguration.loadConfiguration(file);
    }


}
