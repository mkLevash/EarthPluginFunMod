package earthrp.database;

import earthrp.Earth;
import earthrp.Earth.EarthChunk;
import earthrp.Earth.ChunkPosition;
import earthrp.Building;
import earthrp.EarthPlayer;
import earthrp.Market;
import earthrp.Town;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.ItemStack;
import org.dynmap.DynmapAPI;
import org.dynmap.markers.AreaMarker;
import org.dynmap.markers.MarkerAPI;
import org.dynmap.markers.MarkerSet;

import java.sql.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class ServerDatabase {

    String path;
    private final Map<UUID, Building> buildingCache = new ConcurrentHashMap<>();

    Connection globalConnection;
    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:sqlite:" + path);
    }

    public ServerDatabase(String path) throws  SQLException {

        this.path = path;
        globalConnection = DriverManager.getConnection("jdbc:sqlite:" + path);
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS players (
                uuid TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                oi_balance INTEGER NOT NULL DEFAULT 0,
                oi_income INTEGER NOT NULL DEFAULT 0,
                oi_spent INTEGER NOT NULL DEFAULT 0,
                pp_balance INTEGER NOT NULL DEFAULT 0,
                pp_income INTEGER NOT NULL DEFAULT 0,
                pp_income_modifier INTEGER NOT NULL DEFAULT 0,
                pp_max INTEGER NOT NULL DEFAULT 0,
                pp_max_modifier INTEGER NOT NULL DEFAULT 0,
                army_limit_modifier INTEGER NOT NULL DEFAULT 0,
                army_expense INTEGER NOT NULL DEFAULT 0,
                army_expense_modifier INTEGER NOT NULL DEFAULT 0,
                manpower INTEGER NOT NULL DEFAULT 0,
                manpower_modifier INTEGER NOT NULL DEFAULT 0,
                manpower_increase_modifier INTEGER NOT NULL DEFAULT 0,
                income INTEGER NOT NULL DEFAULT 0,
                trade_income INTEGER NOT NULL DEFAULT 0,
                trade_modifier INTEGER NOT NULL DEFAULT 0,
                tax_income INTEGER NOT NULL DEFAULT 0,
                tax_modifier INTEGER NOT NULL DEFAULT 0,
                expense INTEGER NOT NULL DEFAULT 0,
                corruption INTEGER NOT NULL DEFAULT 0,
                inflation INTEGER NOT NULL DEFAULT 0,
                war_support INTEGER NOT NULL DEFAULT 0,
                war_status INTEGER NOT NULL DEFAULT 0,
                treasury INTEGER NOT NULL DEFAULT 0)
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS tech (
                uuid TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                tech1 INTEGER NOT NULL DEFAULT 0,
                tech2 INTEGER NOT NULL DEFAULT 0,
                tech3 INTEGER NOT NULL DEFAULT 0,
                tech4 INTEGER NOT NULL DEFAULT 0,
                tech5 INTEGER NOT NULL DEFAULT 0,
                tech6 INTEGER NOT NULL DEFAULT 0,
                tech7 INTEGER NOT NULL DEFAULT 0,
                tech8 INTEGER NOT NULL DEFAULT 0,
                tech9 INTEGER NOT NULL DEFAULT 0,
                tech10 INTEGER NOT NULL DEFAULT 0,
                tech11 INTEGER NOT NULL DEFAULT 0,
                tech12 INTEGER NOT NULL DEFAULT 0,
                tech13 INTEGER NOT NULL DEFAULT 0,
                tech14 INTEGER NOT NULL DEFAULT 0,
                tech15 INTEGER NOT NULL DEFAULT 0,
                tech16 INTEGER NOT NULL DEFAULT 0,
                tech17 INTEGER NOT NULL DEFAULT 0,
                tech18 INTEGER NOT NULL DEFAULT 0,
                tech19 INTEGER NOT NULL DEFAULT 0,
                tech20 INTEGER NOT NULL DEFAULT 0,
                tech21 INTEGER NOT NULL DEFAULT 0,
                tech22 INTEGER NOT NULL DEFAULT 0,
                tech23 INTEGER NOT NULL DEFAULT 0,
                tech24 INTEGER NOT NULL DEFAULT 0,
                tech25 INTEGER NOT NULL DEFAULT 0,
                tech26 INTEGER NOT NULL DEFAULT 0,
                tech27 INTEGER NOT NULL DEFAULT 0,
                tech28 INTEGER NOT NULL DEFAULT 0,
                tech29 INTEGER NOT NULL DEFAULT 0,
                tech30 INTEGER NOT NULL DEFAULT 0,
                tech31 INTEGER NOT NULL DEFAULT 0,
                tech32 INTEGER NOT NULL DEFAULT 0,
                tech33 INTEGER NOT NULL DEFAULT 0,
                tech34 INTEGER NOT NULL DEFAULT 0,
                tech35 INTEGER NOT NULL DEFAULT 0,
                tech36 INTEGER NOT NULL DEFAULT 0,
                tech37 INTEGER NOT NULL DEFAULT 0,
                tech38 INTEGER NOT NULL DEFAULT 0,
                tech39 INTEGER NOT NULL DEFAULT 0,
                tech40 INTEGER NOT NULL DEFAULT 0,
                tech41 INTEGER NOT NULL DEFAULT 0,
                tech42 INTEGER NOT NULL DEFAULT 0,
                idea1 INTEGER NOT NULL DEFAULT 0,
                idea2 INTEGER NOT NULL DEFAULT 0,
                idea3 INTEGER NOT NULL DEFAULT 0,
                idea4 INTEGER NOT NULL DEFAULT 0,
                idea5 INTEGER NOT NULL DEFAULT 0,
                idea6 INTEGER NOT NULL DEFAULT 0,
                idea7 INTEGER NOT NULL DEFAULT 0,
                idea8 INTEGER NOT NULL DEFAULT 0,
                idea9 INTEGER NOT NULL DEFAULT 0,
                idea10 INTEGER NOT NULL DEFAULT 0,
                idea11 INTEGER NOT NULL DEFAULT 0,
                idea12 INTEGER NOT NULL DEFAULT 0,
                idea13 INTEGER NOT NULL DEFAULT 0,
                idea14 INTEGER NOT NULL DEFAULT 0,
                idea15 INTEGER NOT NULL DEFAULT 0,
                idea16 INTEGER NOT NULL DEFAULT 0,
                idea17 INTEGER NOT NULL DEFAULT 0,
                idea18 INTEGER NOT NULL DEFAULT 0,
                idea19 INTEGER NOT NULL DEFAULT 0,
                idea20 INTEGER NOT NULL DEFAULT 0,
                idea21 INTEGER NOT NULL DEFAULT 0,
                idea22 INTEGER NOT NULL DEFAULT 0,
                idea23 INTEGER NOT NULL DEFAULT 0,
                idea24 INTEGER NOT NULL DEFAULT 0,
                idea25 INTEGER NOT NULL DEFAULT 0,
                idea26 INTEGER NOT NULL DEFAULT 0,
                idea27 INTEGER NOT NULL DEFAULT 0,
                idea28 INTEGER NOT NULL DEFAULT 0,
                idea29 INTEGER NOT NULL DEFAULT 0,
                idea30 INTEGER NOT NULL DEFAULT 0,
                idea31 INTEGER NOT NULL DEFAULT 0,
                idea32 INTEGER NOT NULL DEFAULT 0,
                idea33 INTEGER NOT NULL DEFAULT 0,
                idea34 INTEGER NOT NULL DEFAULT 0,
                idea35 INTEGER NOT NULL DEFAULT 0,
                idea36 INTEGER NOT NULL DEFAULT 0,
                idea37 INTEGER NOT NULL DEFAULT 0,
                idea38 INTEGER NOT NULL DEFAULT 0,
                idea39 INTEGER NOT NULL DEFAULT 0,
                idea40 INTEGER NOT NULL DEFAULT 0,
                idea41 INTEGER NOT NULL DEFAULT 0,
                idea42 INTEGER NOT NULL DEFAULT 0,
                idea43 INTEGER NOT NULL DEFAULT 0,
                idea44 INTEGER NOT NULL DEFAULT 0,
                idea45 INTEGER NOT NULL DEFAULT 0,
                idea46 INTEGER NOT NULL DEFAULT 0,
                idea47 INTEGER NOT NULL DEFAULT 0,
                idea48 INTEGER NOT NULL DEFAULT 0,
                idea49 INTEGER NOT NULL DEFAULT 0,
                idea50 INTEGER NOT NULL DEFAULT 0)
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS status (
                mora TEXT PRIMARY KEY,
                day TEXT NOT NULL DEFAULT '01',
                month TEXT NOT NULL DEFAULT '01')
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS buildings (
                town_name TEXT NOT NULL,
                uuid TEXT PRIMARY KEY,
                town_id TEXT NOT NULL,
                market_id TEXT NULL,
                type TEXT NOT NULL,
                status INTEGER NOT NULL DEFAULT 1,
                world TEXT NOT NULL,
                chunk_x INTEGER NOT NULL,
                chunk_z INTEGER NOT NULL,
                item TEXT NULL)
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS towns (
                owner_name TEXT NOT NULL,
                town_name TEXT NOT NULL,
                uuid TEXT PRIMARY KEY,
                owner_id TEXT NOT NULL,
                type TEXT NOT NULL,
                blockade_status INTEGER NOT NULL DEFAULT 0,
                status INTEGER NOT NULL DEFAULT 1,
                buildings INTEGER NOT NULL DEFAULT 0,
                bonusBuildSites INTEGER NOT NULL DEFAULT 0,
                houses INTEGER NOT NULL,
                world TEXT NOT NULL,
                chunk_x INTEGER NOT NULL,
                chunk_z INTEGER NOT NULL,
                port_id TEXT NULL,
                landHub_id TEXT NULL)
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS markets (
                town_name TEXT NOT NULL,
                uuid TEXT PRIMARY KEY,
                town_id TEXT NOT NULL,
                type TEXT NOT NULL,
                status INTEGER NOT NULL DEFAULT 1,
                goods INTEGER NOT NULL DEFAULT 0,
                market_modifier INTEGER NOT NULL DEFAULT 0,
                world TEXT NOT NULL,
                chunk_x INTEGER NOT NULL,
                chunk_z INTEGER NOT NULL)
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            statement.execute("""
                CREATE TABLE IF NOT EXISTS claimed_chunks (
                x INTEGER NOT NULL,
                z INTEGER NOT NULL,
                world TEXT NOT NULL,
                town_id TEXT,
                UNIQUE(x, z, world))
                """);
        }
        try (Statement statement = globalConnection.createStatement()){
            ResultSet resultSet = statement.executeQuery("SELECT * FROM status");
            if (!resultSet.next()){
                statement.executeUpdate("""
                    INSERT INTO status (mora) VALUES ('off')
                    """);
            }
        }

    }

    //CREATE TABLE IF NOT EXISTS players (
    //uuid TEXT PRIMARY KEY,
    //username TEXT NOT NULL,
    //mora INTEGER NOT NULL DEFAULT 0



    public void closeConnection() throws SQLException {
        if (globalConnection != null && !globalConnection.isClosed()){
            globalConnection.close();
        }
    }



    public void addPlayer(Connection con, EarthPlayer p) throws SQLException {
        try (PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO players (uuid, username) VALUES (?, ?)")){
            preparedStatement.setString(1, p.getUniqueId().toString());
            preparedStatement.setString(2, p.getDisplayName());
            preparedStatement.executeUpdate();
        }
        try (PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO tech (uuid, username) VALUES (?, ?)")){
            preparedStatement.setString(1, p.getUniqueId().toString());
            preparedStatement.setString(2, p.getDisplayName());
            preparedStatement.executeUpdate();
        }
    }

//    public void updatePlayer(EarthPlayer p) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET username = ? WHERE uuid = ?")){
//            preparedStatement.setString(1,p.getDisplayName());
//            preparedStatement.setString(2,p.getUniqueId().toString());
//            preparedStatement.executeUpdate();
//        }
//    }

    public boolean playerExists(UUID id) throws SQLException {
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT * FROM players WHERE uuid = ?")){
            preparedStatement.setString(1, id.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }

    public boolean playerNameActual(EarthPlayer p) throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT username FROM players WHERE uuid = ?")){
            preparedStatement.setString(1,p.getUniqueId().toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return resultSet.getString("username").equals(p.getDisplayName());
            }
        }
        return false;
    }

    public boolean playerOffline(String playerName) throws SQLException {
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT * FROM players WHERE username = ?")){
            preparedStatement.setString(1, playerName);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }

    public UUID getPlayerUuid(String playerName) throws SQLException {
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT uuid FROM players WHERE username = ?")){
            preparedStatement.setString(1, playerName);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                String id = resultSet.getString("uuid");
                OfflinePlayer[] players = Bukkit.getServer().getOfflinePlayers();
                for(OfflinePlayer player : players){
                    if (player.getUniqueId().toString().equals(id)){
                        return player.getUniqueId();
                    }
                }
            }else{
                return null;
            }
        }
        return null;
    }



    public EarthPlayer getPlayer(UUID uuid) throws SQLException{
        EarthPlayer[] players = getPlayers();
        for (EarthPlayer p:players){
            if (p.getUniqueId().equals(uuid)){
                return p;
            }
        }
        return null;
    }

    public EarthPlayer[] getPlayers() throws SQLException {

        Statement statement1 = getConnection().createStatement();
        ResultSet rs1 = statement1.executeQuery("SELECT * FROM players");
        int amount = 0;
        while (rs1.next()){
            amount ++;
        }
        EarthPlayer[] players = new EarthPlayer[amount];
        Statement st = getConnection().createStatement();
        ResultSet rs = st.executeQuery("SELECT * FROM players");
        int i = 0;
        while (rs.next()){
            UUID uniqueId = UUID.fromString(rs.getString("uuid"));
            String displayName = rs.getString("username");
            EarthPlayer player = new EarthPlayer(uniqueId,displayName);

            player.setOiBalance(rs.getInt("oi_balance"));
            player.setOiIncome(rs.getInt("oi_income"));
            player.setOiSpent(rs.getInt("oi_spent"));
            player.setPolitBalance(rs.getInt("pp_balance"));
            player.setPolitIncome(rs.getInt("pp_income"));
            player.setPolitIncomeMod(rs.getInt("pp_income_modifier"));
            player.setPolitMax(rs.getInt("pp_max"));
            player.setPolitMaxMod(rs.getInt("pp_max_modifier"));
            player.setArmyLimitMod(rs.getInt("army_limit_modifier"));
            player.setArmyExpense(rs.getInt("army_expense"));
            player.setArmyExpenseMod(rs.getInt("army_expense_modifier"));
            player.setManpower(rs.getInt("manpower"));
            player.setManpowerMod(rs.getInt("manpower_modifier"));
            player.setManpowerIncMod(rs.getInt("manpower_increase_modifier"));
            player.setIncome(rs.getInt("income"));
            player.setTradeIncome(rs.getInt("trade_income"));
            player.setTradeMod(rs.getInt("trade_modifier"));
            player.setTaxIncome(rs.getInt("tax_income"));
            player.setTaxMod(rs.getInt("tax_modifier"));
            player.setExpense(rs.getInt("expense"));
            player.setCorruption(rs.getInt("corruption"));
            player.setInflation(rs.getInt("inflation"));
            player.setWarSup(rs.getInt("war_support"));
            player.setWarStatus(rs.getInt("war_status"));
            player.setTreasury(rs.getInt("treasury"));

            players[i] = player;
            i++;
        }
        return players;
    }

    public void updatePlayer(EarthPlayer p)throws SQLException{

        String uuid = p.getUniqueId().toString();
        String displayName = p.getDisplayName();
        int oiBalance = p.getOiBalance();
        int oiIncome = p.getOiIncome();
        int oiSpent = p.getOiSpent();
        int politBalance = p.getPolitBalance();
        int politIncome = p.getPolitIncome();
        int politIncomeMod = p.getPolitIncomeMod();
        int politMax = p.getPolitMax();//politMax;}
        int politMaxMod = p.getPolitMaxMod();//politMax;}
        int armyLimitMod = p.getArmyLimitMod();//armyLimitMod;}
        int armyExpense = p.getArmyExpense();//armyExpense;}
        int armyExpenseMod = p.getArmyExpenseMod();//armyExpenseMod;}
        int manpower = p.getManpower();//manpower;}
        int manpowerMod = p.getManpowerMod();//manpowerMod;}
        int manpowerIncMod = p.getManpowerIncMod();//manpowerIncMod;}
        int income = p.getIncome();//income;}
        int tradeIncome = p.getTradeIncome();//tradeIncome;}
        int tradeMod = p.getTradeMod();//tradeMod;}
        int taxIncome = p.getTaxIncome();//taxIncome;}
        int taxMod = p.getTaxMod();//taxMod;}
        int expense = p.getExpense();//expense;}
        int corruption = p.getCorruption();//corruption;}
        int inflation = p.getInflation();//inflation;}
        int warSup = p.getWarSup();//warSup;}
        int warStatus = p.getWarStatus();//warStatus;}
        int treasury = p.getTreasury();//treasury;}



        String sql = "UPDATE players SET " +
                "username = ? , " +
                "oi_balance = ? , " +
                "oi_income = ? , " +
                "oi_spent = ? , " +
                "pp_balance = ? , " +
                "pp_income = ? , " +
                "pp_income_modifier = ? , " +
                "pp_max = ? , " +
                "pp_max_modifier = ? , " +
                "army_limit_modifier = ? , " +
                "army_expense = ? , " +
                "army_expense_modifier = ? , " +
                "manpower = ? , " +
                "manpower_modifier = ? , " +
                "manpower_increase_modifier = ? , " +
                "income = ? , " +
                "trade_income = ? , " +
                "trade_modifier = ? , " +
                "tax_income = ? , " +
                "tax_modifier = ? , " +
                "expense = ? , " +
                "corruption = ? , " +
                "inflation = ? , " +
                "war_support = ? , " +
                "war_status = ? , " +
                "treasury = ? " +
                "WHERE uuid = ?";
        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {
            pstmt.setString(1,displayName);
            pstmt.setInt(2,oiBalance);
            pstmt.setInt(3,oiIncome);
            pstmt.setInt(4,oiSpent);
            pstmt.setInt(5,politBalance);
            pstmt.setInt(6,politIncome);
            pstmt.setInt(7,politIncomeMod);
            pstmt.setInt(8,politMax);
            pstmt.setInt(9,politMaxMod);
            pstmt.setInt(10,armyLimitMod);
            pstmt.setInt(11,armyExpense);
            pstmt.setInt(12,armyExpenseMod);
            pstmt.setInt(13,manpower);
            pstmt.setInt(14,manpowerMod);
            pstmt.setInt(15,manpowerIncMod);
            pstmt.setInt(16,income);
            pstmt.setInt(17,tradeIncome);
            pstmt.setInt(18,tradeMod);
            pstmt.setInt(19,taxIncome);
            pstmt.setInt(20,taxMod);
            pstmt.setInt(21,expense);
            pstmt.setInt(22,corruption);
            pstmt.setInt(23,inflation);
            pstmt.setInt(24,warSup);
            pstmt.setInt(25,warStatus);
            pstmt.setInt(26,treasury);
            pstmt.setString(27,uuid);

            pstmt.executeUpdate();

        }
    }




    public boolean marketExists(UUID uuid) throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT * FROM markets WHERE uuid = ?")){
            preparedStatement.setString(1, uuid.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }

    public void addMarket(Town town, UUID marketId, String type, Location loc)throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("INSERT INTO markets (town_name, uuid, town_id, type, world, chunk_x, chunk_z) VALUES (?, ?, ?, ?, ?, ?, ?)")){
//            preparedStatement.setString(1, townName);
//            preparedStatement.setString(2, marketUniqueId.toString());
//            preparedStatement.setString(3, townUniqueId.toString());
//            preparedStatement.setString(4, type);
//            preparedStatement.setString(5, world);
//            preparedStatement.setInt(6, x);
//            preparedStatement.setInt(7, z);
            preparedStatement.executeUpdate();
        }
    }

    public void deleteMarket(Market market) throws SQLException {

        Town town = getTown(market.getTownId());
        town.setBuildings(town.getBuildings()-1);
        updateTown(town);
        Location loc0 = null;
        Location loc1 = null;
        Entity[] entities = Objects.requireNonNull(Bukkit.getWorld(market.getWorld())).getChunkAt(market.getX(),market.getZ()).getEntities();

        for(Entity en:entities){
            if (en instanceof ArmorStand armor && (Objects.equals(armor.getCustomName(),market.getUniqueId().toString()))){
                loc0 = armor.getLocation();
                loc1 = armor.getLocation().add(0.5,-1,0.5);
            }
        }
        assert loc0 != null;
        BlockState[] tileEntities = Objects.requireNonNull(Bukkit.getWorld(market.getWorld())).getChunkAt(loc0).getTileEntities();
        Chest chest = null;
        if(tileEntities!=null){
            for(BlockState block:tileEntities){
                if(block instanceof Chest ch && Objects.equals(ch.getLocation(),loc0)){
                    chest = ch;
                }
            }
        }
        assert chest != null;
        ItemStack[] contents = chest.getBlockInventory().getContents();

        if (contents!=null){
            System.out.println(Arrays.toString(contents));
            for (ItemStack item:contents){
                if (item != null){
                    List<String> lore = Objects.requireNonNull(item.getItemMeta()).getLore();
                    if(lore != null){
                        if (lore.get(0).equals("market")){
                            chest.getBlockInventory().remove(item);
                        }
                    }

                }
            }
        }
        for(Entity en: entities){
            if (en instanceof ArmorStand armor){
                if(Objects.equals(armor.getLocation(),loc0)|Objects.equals(armor.getLocation(),loc1)){
                    armor.remove();
                }

            }
        }
        Building[] buildings = getBuildings(getConnection());
        if(buildings!=null){
            for (Building b : buildings){
                if (b.getMarketId().equals(market.getUniqueId())){
                    b.setMarketId(null);
                    updateBuilding(b);
                }
            }
        }
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("DELETE FROM markets WHERE uuid = ?")){
            preparedStatement.setString(1, market.getUniqueId().toString());
            preparedStatement.executeUpdate();
        }
    }



    public void updateMarket(Market market)throws SQLException{
        String town_name = getTown(market.getTownId()).getName();
        String townId = market.getTownId().toString();
        String type = market.getType();
        int status = market.getStatus();
        int goods = market.getGoods();
        UUID marketUniqueId = market.getUniqueId();
        String world = market.getWorld();
        int x = market.getX();
        int z = market.getZ();
        int marketMod = market.getMarketModifier();


        String sql = "UPDATE markets SET " +
                "town_name = ? , " +
                "town_id = ? , " +
                "type = ? , " +
                "status = ? , " +
                "goods = ? , " +
                "world = ? , " +
                "chunk_x = ? , " +
                "chunk_z = ? , " +
                "market_modifier = ? " +
                "WHERE uuid = ?";
        try (PreparedStatement pstmt = getConnection().prepareStatement(sql)) {
            pstmt.setString(1,town_name);
            pstmt.setString(2,townId);
            pstmt.setString(3,type);
            pstmt.setInt(4,status);
            pstmt.setInt(5,goods);
            pstmt.setString(6,world);
            pstmt.setInt(7,x);
            pstmt.setInt(8,z);
            pstmt.setInt(9,marketMod);
            pstmt.setString(10,marketUniqueId.toString());

            pstmt.executeUpdate();

        }
    }

    public Market getMarket(UUID marketId)throws SQLException {
        List<Market> markets = getMarkets();
        if (markets!=null){
            for(Market m : markets){
                if (m.getUniqueId().equals(marketId)){
                    return m;
                }
            }
        }
        return null;
    }

    public ArrayList<Market> getMarkets()throws SQLException {

        Statement statement = getConnection().createStatement();
        String query = "SELECT * FROM markets";
        ResultSet rs = statement.executeQuery(query);

        ArrayList<Market> markets = new ArrayList<>();

        while (rs.next()){
            int status = rs.getInt("status");
            UUID marketId = UUID.fromString(rs.getString("uuid"));
            UUID townId = UUID.fromString(rs.getString("town_id"));
            Town town = getTown(townId);
            String type = rs.getString("type");
            int goods = rs.getInt("goods");
            int marketMod = rs.getInt("market_modifier");
            String world = rs.getString("world");
            int x = rs.getInt("chunk_x");
            int z = rs.getInt("chunk_z");

            markets.add(new Market(marketId,townId,type,status,goods,town.getPeople(), marketMod, world, x, z));
            //int people = getTown(townId).getHouses();
            //markets[i] = new Market(marketId,townId,type,status,goods,people);
        }
        return markets;
    }

    public ArrayList<Market> getPlayerMarkets(UUID playerId)throws SQLException{

        ArrayList<Market> result = new ArrayList<>();
        Town[] towns = getPlayerTowns(playerId);
        List<Market> markets = getMarkets();
        if (markets!=null){
            for(Market m : markets){
                for(Town t : towns){
                    if(m.getTownId().equals(t.getUniqueId())){
                        result.add(m);
                    }
                }
            }
        }
        return result;
    }

    public boolean townExists(UUID uuid) throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT * FROM towns WHERE uuid = ?")){
            preparedStatement.setString(1, uuid.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }

    public void addTown(String ownerName, String townName,UUID town_id, UUID ownerUuid, String type, String world, int chunk_x, int chunk_z, int houses)throws SQLException{
        String sql = "INSERT INTO towns (owner_name, town_name, uuid, owner_id, type, world, chunk_x, chunk_z, houses) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            int paramIndex = 1;
            preparedStatement.setString(paramIndex++, ownerName);
            preparedStatement.setString(paramIndex++, townName);
            preparedStatement.setString(paramIndex++, town_id.toString());
            preparedStatement.setString(paramIndex++, ownerUuid.toString());
            preparedStatement.setString(paramIndex++, type);
            preparedStatement.setString(paramIndex++, world);
            preparedStatement.setInt(paramIndex++, chunk_x);
            preparedStatement.setInt(paramIndex++, chunk_z);
            preparedStatement.setInt(paramIndex++, houses);
            preparedStatement.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public void deleteTown(Town town) throws SQLException {
        Building[] buildings = getBuildings(getConnection());
        if (buildings!=null){
            for (Building b:buildings){
                if (b.getTownId().equals(town.getUniqueId())){
                    deleteBuilding(b);
                }
            }
        }
        List<Market> markets = getMarkets();
        if(markets!=null){
            for (Market m:markets){
                if(m.getTownId().equals(town.getUniqueId())){
                    deleteMarket(m);
                }
            }
        }

        Entity[] tileEntities = Objects.requireNonNull(Bukkit.getWorld(town.getWorld())).getChunkAt(town.getChunkX(), town.getChunkZ()).getEntities();
        for(Entity en: tileEntities){
            if (en instanceof ArmorStand armor){
                if(Objects.equals(armor.getCustomName(), town.getName())){
                    armor.remove();
                }

            }
        }
        unclaimAllTownChunk(town);
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM towns WHERE uuid = ?");
            preparedStatement.setString(1, town.getUniqueId().toString());
            preparedStatement.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateTown(Town town) throws SQLException {
        if (town.getUniqueId() == null) {
            throw new IllegalArgumentException("Town UUID cannot be null");
        }

        String sql = "UPDATE towns SET " +
                "owner_name = ?, " +
                "town_name = ?, " +
                "owner_id = ?, " +
                "type = ?, " +
                "blockade_status = ?, " +
                "status = ?, " +
                "buildings = ?, " +
                "bonusBuildSites = ?, " +
                "houses = ?, " +
                "port_id = ?, " +       // заменили market_id на port
                "landHub_id = ?, " +    // добавили landHub
                "world = ?, " +
                "chunk_x = ?, " +
                "chunk_z = ? " +
                "WHERE uuid = ?";
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement pstmt = conn.prepareStatement(sql);

            int paramIndex = 1;
            pstmt.setString(paramIndex++, town.getOwnerName());
            pstmt.setString(paramIndex++, town.getName());
            pstmt.setString(paramIndex++, town.getOwnerId().toString());
            pstmt.setString(paramIndex++, town.getType());
            pstmt.setInt(paramIndex++, town.getBlockadeStatus());
            pstmt.setInt(paramIndex++, town.getStatus());
            pstmt.setInt(paramIndex++, town.getBuildings());
            pstmt.setInt(paramIndex++, town.getBonusBuildSite());
            pstmt.setInt(paramIndex++, town.getHouses());

            // Устанавливаем port
            UUID port = town.getPortId();
            if (port != null) {
                pstmt.setString(paramIndex++, port.toString());
            } else {
                pstmt.setNull(paramIndex++, Types.VARCHAR);
            }

            // Устанавливаем landHub
            UUID landHub = town.getLandHubId();
            if (landHub != null) {
                pstmt.setString(paramIndex++, landHub.toString());
            } else {
                pstmt.setNull(paramIndex++, Types.VARCHAR);
            }

            pstmt.setString(paramIndex++, town.getWorld());
            pstmt.setInt(paramIndex++, town.getChunkX());
            pstmt.setInt(paramIndex++, town.getChunkZ());

            pstmt.setString(paramIndex, town.getUniqueId().toString());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Updating town failed, no rows affected.");
            }

            conn.commit();
        } catch (SQLException e) {
            System.err.println("Error updating town " + town.getUniqueId() + ": " + e.getMessage());
            throw e;
        }
    }


    public Town[] getPlayerTowns(UUID playerId) throws SQLException {
        // Используем список для динамического накопления результатов
        List<Town> result = new ArrayList<>();

        String query = "SELECT * FROM towns WHERE owner_id = ?";

        try (PreparedStatement statement = getConnection().prepareStatement(query)) {
            statement.setString(1, playerId.toString());

            try (ResultSet rs = statement.executeQuery()) {
                while (rs.next()) {
                    try {
                        result.add(createTownFromResultSet(rs));
                    } catch (SQLException e) {
                        System.err.println("Error creating town from record: " + e.getMessage());
                        // Можно добавить логирование ошибки
                    }
                }
            }
        }

        // Возвращаем массив (не null)
        return result.toArray(new Town[0]);
    }

    public Town[] getTowns() throws SQLException {
        // Используем список для динамического добавления городов
        List<Town> townsList = new ArrayList<>();

        try (Statement statement = getConnection().createStatement();
             ResultSet rs = statement.executeQuery("SELECT * FROM towns")) {

            while (rs.next()) {
                try {
                    Town town = createTownFromResultSet(rs);
                    townsList.add(town);
                } catch (SQLException e) {
                    System.err.println("Error creating town from record: " + e.getMessage());
                    // Можно добавить более детальное логирование ошибки
                }
            }
        }

        // Конвертируем список в массив перед возвратом
        return townsList.toArray(new Town[0]);
    }

    private Town createTownFromResultSet(ResultSet rs) throws SQLException {
        UUID townId = UUID.fromString(rs.getString("uuid"));
        UUID playerId = UUID.fromString(rs.getString("owner_id"));

        // Обрабатываем port и landHub как nullable UUID
        UUID portId = null;
        String portIdStr = rs.getString("port_id");
        if (portIdStr != null && !portIdStr.isEmpty()) {
            portId = UUID.fromString(portIdStr);
        }

        UUID landHubId = null;
        String landHubIdStr = rs.getString("landHub_id");
        if (landHubIdStr != null && !landHubIdStr.isEmpty()) {
            landHubId = UUID.fromString(landHubIdStr);
        }

        return new Town(
                townId,
                playerId,
                rs.getString("type"),
                rs.getString("town_name"),
                rs.getString("owner_name"),
                rs.getInt("status"),
                rs.getInt("blockade_status"),
                rs.getInt("buildings"),
                rs.getInt("houses"),
                rs.getInt("bonusBuildSites"),
                rs.getString("world"),
                rs.getInt("chunk_x"),
                rs.getInt("chunk_z"),
                portId,
                landHubId
        );
    }


    public Town getTown(UUID townId) throws SQLException {
        String query = "SELECT * FROM towns WHERE uuid = ?";

        try (PreparedStatement statement = getConnection().prepareStatement(query)) {
            statement.setString(1, townId.toString());

            try (ResultSet rs = statement.executeQuery()) {
                if (rs.next()) {
                    return createTownFromResultSet(rs);
                }
            }
        }
        return null; // Город не найден
    }

    public boolean markChunkAsClaimed(int chunkX, int chunkZ, Town town)throws SQLException{
        String world = town.getWorld();

        // Попробуем сразу обновить, если чанк существует и не принадлежит другому городу
        String updateSql = "UPDATE claimed_chunks SET town_id = ? " +
                "WHERE x = ? AND z = ? AND world = ? AND town_id IS NULL";
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            PreparedStatement ps = conn.prepareStatement(updateSql);
            ps.setString(1, town.getUniqueId().toString());
            ps.setInt(2, chunkX);
            ps.setInt(3, chunkZ);
            ps.setString(4, world);
            int updated = ps.executeUpdate();
            if (updated > 0) {
                conn.commit();
                return true;
            }

        } catch (SQLException e) {
            System.err.println("Ошибка при обновлении чанка: " + e.getMessage());
            e.printStackTrace();
        }




        if(getChunk(new ChunkPosition(chunkX,chunkZ), town.getWorld())==null){
            // Если не получилось обновить, пробуем вставить новый
            String insertSql = "INSERT INTO claimed_chunks (x, z, town_id, world) " +
                    "VALUES (?, ?, ?, ?)";

            try (Connection conn = getConnection()) {
                conn.setAutoCommit(false);
                PreparedStatement ps = conn.prepareStatement(insertSql);
                ps.setInt(1, chunkX);
                ps.setInt(2, chunkZ);
                ps.setString(3, town.getUniqueId().toString());
                ps.setString(4, world);
                ps.executeUpdate();
                conn.commit();
                return true;


            } catch (SQLException e) {
                System.err.println("Ошибка при обновлении чанка: " + e.getMessage());
                return false;
            }
        }
        return false;


    }
    // Метод для сглаживания координат
    public static List<double[]> chaikinSmoothing(double[] x, double[] z, int iterations) {
        List<double[]> points = new ArrayList<>();
        for (int i = 0; i < x.length; i++) {
            points.add(new double[]{x[i], z[i]});
        }

        for (int it = 0; it < iterations; it++) {
            List<double[]> newPoints = new ArrayList<>();
            for (int i = 0; i < points.size(); i++) {
                double[] p0 = points.get(i);
                double[] p1 = points.get((i + 1) % points.size()); // циклический замкнутый контур

                double[] q = {
                        0.75 * p0[0] + 0.25 * p1[0],
                        0.75 * p0[1] + 0.25 * p1[1]
                };
                double[] r = {
                        0.25 * p0[0] + 0.75 * p1[0],
                        0.25 * p0[1] + 0.75 * p1[1]
                };

                newPoints.add(q);
                newPoints.add(r);
            }
            points = newPoints;
        }

        return points;
    }

    public EarthChunk getChunk(ChunkPosition chunk, String world) {
        String sql0 = "SELECT * FROM claimed_chunks WHERE x = ? AND z = ? AND world = ?";
        try (PreparedStatement ps0 = getConnection().prepareStatement(sql0)) {
            ps0.setInt(1, chunk.x());
            ps0.setInt(2, chunk.z());
            ps0.setString(3, world);

            try (ResultSet rs = ps0.executeQuery()) {
                if (rs.next()) {
                    return new EarthChunk(rs.getInt("x"), rs.getInt("z"), rs.getString("town_id"));
                }
                return null; // или throw new ChunkNotFoundException();
            }
        } catch (SQLException e) {
            throw new RuntimeException("Database error while fetching chunk", e);
        }

    }

    public void unclaimAllTownChunk(Town town) {
        String sql = "UPDATE claimed_chunks SET town_id = ? WHERE town_id = ?";


        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, null);  // или setNull(1, Types.VARCHAR)
            statement.setString(2, town.getUniqueId().toString());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                System.out.println("Чанки не найдены для города: " + town.getName());
            } else {
                System.out.println("Обновлено чанков: " + affectedRows);
            }

            conn.commit();
        } catch (SQLException e) {
            System.err.println("Ошибка при обновлении чанков для города " + town.getName());
            e.printStackTrace();
        }
    }

    public void unclaimChunk(int chunkX, int chunkZ, String worldName) {
        String sql = "SET town_id = ? FROM claimed_chunks WHERE x = ? AND z = ? AND world = ?";
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, chunkX);
            statement.setInt(2, chunkZ);
            statement.setString(3, worldName);

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                System.out.println("Чанк не найден: " + chunkX + ", " + chunkZ + " в мире " + worldName);
            }

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Set<ChunkPosition> getClaimedChunksByTownId(UUID townId) {
        Set<ChunkPosition> claimedChunks = new HashSet<>();
        String sql = "SELECT x, z FROM claimed_chunks WHERE town_id = ?";

        try (PreparedStatement statement = getConnection().prepareStatement(sql)) {
            statement.setString(1, townId.toString());

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    int x = resultSet.getInt("x");
                    int z = resultSet.getInt("z");
                    claimedChunks.add(new ChunkPosition(x, z));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return claimedChunks;
    }
    public Set<ChunkPosition> getAllClaimedChunks() {
        Set<ChunkPosition> claimedChunks = new HashSet<>();
        String sql = "SELECT x, z FROM claimed_chunks WHERE town_id IS NOT NULL";

        try (PreparedStatement statement = getConnection().prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                int x = resultSet.getInt("x");
                int z = resultSet.getInt("z");
                claimedChunks.add(new ChunkPosition(x, z));
            }
        } catch (SQLException e) {
            System.err.println("Ошибка при получении всех занятых чанков: " + e.getMessage());
            e.printStackTrace();
        }

        return claimedChunks;
    }


//    public void drawTownBorder(Town town) {
//        DynmapAPI dynmap = (DynmapAPI) Bukkit.getPluginManager().getPlugin("dynmap");
//        if (dynmap == null) {
//            Bukkit.getLogger().warning("Dynmap не найден!");
//            return;
//        }
//
//        MarkerAPI markerAPI = dynmap.getMarkerAPI();
//        if (markerAPI == null) {
//            Bukkit.getLogger().warning("Dynmap MarkerAPI не найден!");
//            return;
//        }
//
//        String markerSetId = "towns";
//        MarkerSet markerSet = markerAPI.getMarkerSet(markerSetId);
//        if (markerSet == null) {
//            markerSet = markerAPI.createMarkerSet(markerSetId, "Города", null, false);
//            if (markerSet == null) {
//                Bukkit.getLogger().warning("Не удалось создать MarkerSet для городов");
//                return;
//            }
//        }
//
//        // Удалим предыдущую границу города (если есть)
//        String areaId = "town-border-" + town.getUniqueId().toString();
//        AreaMarker existing = markerSet.findAreaMarker(areaId);
//        if (existing != null) {
//            existing.deleteMarker();
//        }
//
//        // Получаем все занятые чанки
//        Set<String> claimedChunks = getClaimedChunksByTownId(town.getId());
//        if (claimedChunks.isEmpty()) return;
//
//        // Преобразуем в координаты чанков и блоков
//        Map<String, List<int[]>> worldChunks = new HashMap<>();
//
//        for (String chunk : claimedChunks) {
//            String[] parts = chunk.split(":");
//            String worldName = parts[0];
//            String[] coords = parts[1].split(",");
//            int x = Integer.parseInt(coords[0]);
//            int z = Integer.parseInt(coords[1]);
//
//            worldChunks.computeIfAbsent(worldName, k -> new ArrayList<>()).add(new int[]{x, z});
//        }
//
//        for (Map.Entry<String, List<int[]>> entry : worldChunks.entrySet()) {
//            String worldName = entry.getKey();
//            List<int[]> chunks = entry.getValue();
//
//            // Преобразуем в список углов чанков для построения полигона
//            List<Double> xCoords = new ArrayList<>();
//            List<Double> zCoords = new ArrayList<>();
//
//            for (int[] chunk : chunks) {
//                int bx = chunk[0] << 4;
//                int bz = chunk[1] << 4;
//
//                xCoords.add((double) bx);
//                zCoords.add((double) bz);
//            }
//
//            // Преобразуем в массивы
//            double[] xArray = xCoords.stream().mapToDouble(Double::doubleValue).toArray();
//            double[] zArray = zCoords.stream().mapToDouble(Double::doubleValue).toArray();
//
//            // Создаем маркер
//            AreaMarker marker = markerSet.createAreaMarker(areaId, town.getName(), false, worldName, xArray, zArray, false);
//            if (marker != null) {
//                marker.setLineStyle(2, 1.0, 0x00FF00); // Толщина 2, непрозрачность 1.0, зеленая линия
//                marker.setFillStyle(0.2, 0x00FF00);    // Прозрачность заливки и цвет
//                marker.setDescription("<div><strong>" + town.getName() + "</strong></div>");
//            }
//        }
//    }


    public boolean buildingExists(UUID buildingId) throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("SELECT * FROM buildings WHERE uuid = ?")){
            preparedStatement.setString(1, buildingId.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        }
    }


    public void addBuilding(String townName,UUID buildingId,UUID townId,String type, String world, int x, int z)throws SQLException{
        try (PreparedStatement preparedStatement = getConnection().prepareStatement("INSERT INTO buildings (town_name, uuid, town_id, type, world, chunk_x, chunk_z) VALUES (?, ?, ?, ?, ?, ?, ?)")){
            preparedStatement.setString(1, townName);
            preparedStatement.setString(2, buildingId.toString());
            preparedStatement.setString(3, townId.toString());
            preparedStatement.setString(4, type);
            preparedStatement.setString(5, world);
            preparedStatement.setInt(6, x);
            preparedStatement.setInt(7, z);
            preparedStatement.executeUpdate();
        }
    }


    public void deleteBuilding(Building building) throws SQLException {

        Town town = getTown(building.getTownId());
        town.setBuildings(town.getBuildings()-1);
        Location loc0 = null;
        Location loc1 = null;
        Entity[] entities = Objects.requireNonNull(Bukkit.getWorld(building.getWorld())).getChunkAt(building.getX(),building.getZ()).getEntities();

        for(Entity en:entities){
            if (en instanceof ArmorStand armor && (Objects.equals(armor.getCustomName(),building.getUniqueId().toString()))){
                loc0 = armor.getLocation();
                loc1 = armor.getLocation().add(0.5,-1,0.5);
            }
        }

//        System.out.println(loc);
//        System.out.println("0");
        assert loc0 != null;
        BlockState[] tileEntities = Objects.requireNonNull(Bukkit.getWorld(building.getWorld())).getChunkAt(loc0).getTileEntities();
        Chest chest = null;
        if(tileEntities!=null){
            for(BlockState block:tileEntities){
                if(block instanceof Chest ch && Objects.equals(ch.getLocation(),loc0)){
                    chest = ch;
                }
            }
        }
        assert chest != null;
        ItemStack[] contents = chest.getBlockInventory().getContents();

        if (contents!=null){
            System.out.println(Arrays.toString(contents));
            for (ItemStack item:contents){
                if (item != null){
                    List<String> lore = Objects.requireNonNull(item.getItemMeta()).getLore();
                    if(lore != null){
                        if (lore.get(0).equals("building")){
                            chest.getBlockInventory().remove(item);
                        }
                    }

                }
            }
        }
        for(Entity en: entities){
            if (en instanceof ArmorStand armor){
                if(Objects.equals(armor.getLocation(),loc0)|Objects.equals(armor.getLocation(),loc1)){
                    armor.remove();
                }

            }
        }


        updateTown(town);
        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM buildings WHERE uuid = ?");
            preparedStatement.setString(1, building.getUniqueId().toString());
            preparedStatement.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public Building[] getPlayerBuildings(Connection conn, UUID playerId) throws SQLException {
        Building[] buildings = getBuildings(conn);
        Town[] towns = getPlayerTowns(playerId);

        if (buildings == null || towns == null) return null;

        // Собираем ID всех городов игрока в Set для быстрого поиска
        Set<UUID> playerTownIds = Arrays.stream(towns)
                .map(Town::getUniqueId)
                .collect(Collectors.toSet());

        List<Building> result = new ArrayList<>();

        for (Building b : buildings) {
            if (b.getStatus() != 0 && playerTownIds.contains(b.getTownId())) {
                result.add(b);
            }
        }

        return result.isEmpty() ? null : result.toArray(new Building[0]);
    }


    public Building getBuilding(UUID buildingId) throws SQLException {
        // Проверяем кеш
        Building cached = buildingCache.get(buildingId);
        if (cached != null) {
            return cached;
        }

        // Загружаем из БД

        Building building = getBuildingFromDb(getConnection(), buildingId);
        if (building != null) {
            buildingCache.put(buildingId, building);
        }

        return building;
    }


    public Building getBuildingFromDb(Connection conn, UUID buildingId) throws SQLException {
        // Оптимизация: запрашиваем только нужное здание
        String sql = "SELECT * FROM buildings WHERE uuid = ?";

        try (
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, buildingId.toString());

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return createBuildingFromResultSet(rs);
                }
            }
        }
        return null;
    }
    public Building[] getBuildings(Connection conn)throws SQLException {

        String query = "SELECT * FROM buildings";
        List<Building> buildings = new ArrayList<>();

        try (PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {


            while (rs.next()) {
                String marketIdStr = rs.getString("market_id");
                UUID marketId = marketIdStr != null ? UUID.fromString(marketIdStr) : null;
                int status = rs.getInt("status");
                UUID buildingId = UUID.fromString(rs.getString("uuid"));
                UUID townId = UUID.fromString(rs.getString("town_id"));
                String townName = rs.getString("town_name");
                String type = rs.getString("type");
                String item = rs.getString("item");
                String world = rs.getString("world");
                int x = rs.getInt("chunk_x");
                int z = rs.getInt("chunk_z");

                Building building = new Building(
                        buildingId, townId, townName, marketId, type, status, item, world, x, z
                );
                buildings.add(building);
            }
        }

        return buildings.toArray(new Building[0]);
    }

    private Building createBuildingFromResultSet(ResultSet rs) throws SQLException {
        String marketIdStr = rs.getString("market_id");
        UUID marketId = marketIdStr != null ? UUID.fromString(marketIdStr) : null;
        return new Building(
                UUID.fromString(rs.getString("uuid")),
                UUID.fromString(rs.getString("town_id")),
                rs.getString("town_name"),
                marketId,
                rs.getString("type"),
                rs.getInt("status"),
                rs.getString("item"),
                rs.getString("world"),
                rs.getInt("chunk_x"),
                rs.getInt("chunk_z")
        );
    }

    private void updateBuildingInCache(Building updated) {
        buildingCache.put(updated.getUniqueId(), updated);
    }

    private void invalidateCache(UUID buildingId) {
        buildingCache.remove(buildingId);
    }



    public void updateBuilding(Building building) throws SQLException {
        updateBuildingInCache(building);
        String sql = "UPDATE buildings SET " +
                "town_name = ?, " +
                "town_id = ?, " +
                "type = ?, " +
                "item = ?, " +
                "status = ?, " +
                "world = ?, " +
                "chunk_x = ?, " +
                "chunk_z = ?, " +
                "market_id = ? " +
                "WHERE uuid = ?";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false);

            PreparedStatement pstmt = conn.prepareStatement(sql);
            int paramIndex = 1;
            pstmt.setString(paramIndex++, building.getTownName());
            pstmt.setString(paramIndex++, building.getTownId().toString());
            pstmt.setString(paramIndex++, building.getType());
            pstmt.setString(paramIndex++, building.getItem() != null ? building.getItem().toString() : null);
            pstmt.setInt(paramIndex++, building.getStatus());
            pstmt.setString(paramIndex++, building.getWorld());
            pstmt.setInt(paramIndex++, building.getX());
            pstmt.setInt(paramIndex++, building.getZ());
            pstmt.setString(paramIndex++, building.getMarketId() != null ? building.getMarketId().toString() : null);
            pstmt.setString(paramIndex, building.getUniqueId().toString());

            pstmt.executeUpdate();

            conn.commit();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



//    public void updatePlayerTreasury(UUID id, int treasury) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET treasury = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, treasury);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerIncome(UUID id, int income) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET income = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, income);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerExpense(UUID id, int expense) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET expense = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, expense);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerOiIncome(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET oi_income = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }

    public void updatePlayerOiBalance(UUID id, int amount) throws SQLException {

        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("UPDATE players SET oi_balance = ? WHERE uuid = ?")){
            preparedStatement.setInt(1, amount);
            preparedStatement.setString(2, id.toString());
            preparedStatement.executeUpdate();
        }
    }

//    public void updatePlayerOiSpent(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET oi_spent = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerPpBalance(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET pp_balance = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerPpIncome(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET pp_income = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerPpMax(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET pp_max = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerArmyLimit(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET army_limit = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerArmyLimitModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET army_limit_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerArmyExpense(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET army_expense = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerArmyExpenseModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET army_expense_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerManpower(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET manpower = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerManpowerModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET manpower_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerManpowerIncreaseModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET manpower_increase_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerTaxIncome(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET tax_income = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerTaxModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET tax_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerTradeIncome(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET trade_income = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerTradeModifier(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET trade_modifier = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerInflation(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET inflation = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerCorruption(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET corruption = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerWarSupport(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET war_support = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//
//    public void updatePlayerWarStatus(UUID id, int amount) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET war_status = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, id.toString());
//            preparedStatement.executeUpdate();
//        }
//    }







//    public int getPlayerIncome(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT income FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("income");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerExpense(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT expense FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("expense");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerOiIncome(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT oi_income FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("oi_income");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerOiBalance(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT oi_balance FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("oi_balance");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerOiSpent(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT oi_spent FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("oi_spent");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerPpBalance(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT pp_balance FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("pp_balance");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerPpMax(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT pp_max FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("pp_max");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerPpIncome(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT pp_income FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("pp_income");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerArmyLimit(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT army_limit FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("army_limit");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerArmyLimitModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT army_limit_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("army_limit_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerArmyExpense(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT army_expense FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("army_expense");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerArmyExpenseModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT army_expense_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("army_expense_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerManpower(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT manpower FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("manpower");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerManpowerModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT manpower_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("manpower_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerManpowerIncreaseModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT manpower_increase_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("manpower_increase_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerTaxIncome(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT tax_income FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("tax_income");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerTaxModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT tax_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("tax_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerTradeIncome(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT trade_income FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("trade_income");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerTradeModifier(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT trade_modifier FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("trade_modifier");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerInflation(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT inflation FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("inflation");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerCorruption(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT corruption FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("corruption");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerWarSupport(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT war_support FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("war_support");
//            }else{
//                return 0;
//            }
//        }
//    }
//
//    public int getPlayerWarStatus(UUID id) throws SQLException{
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT war_status FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, id.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt("war_status");
//            }else{
//                return 0;
//            }
//        }
//    }
//



    public void updateStatusMora(String value) throws SQLException {
        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("UPDATE status SET mora = ?")) {
            preparedStatement.setString(1,value);
            preparedStatement.executeUpdate();
        }
    }

    public void updateStatusDay(String value) throws SQLException {
        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("UPDATE status SET day = ?")) {
            preparedStatement.setString(1,value);
            preparedStatement.executeUpdate();
        }
    }

    public boolean getStatusMora() throws SQLException {
        try (Statement statement = globalConnection.createStatement())
        {
            String query = "SELECT mora FROM status";
            ResultSet rs = statement.executeQuery(query);
            while (rs.next()){
                String status = rs.getString("mora");
                if (status.equals("off")){
                    return false;
                }else if (status.equals("on")){
                    return true;
                }
            }
        }
        return false;
    }

    public String getStatusDay() throws SQLException {
        try (Statement statement = globalConnection.createStatement())
        {
            String query = "SELECT day FROM status";
            ResultSet rs = statement.executeQuery(query);
            return rs.getString("day");
        }
    }

//    public void updatePlayers(UUID uuid,int amount,String value) throws SQLException {
//
//        try (PreparedStatement preparedStatement = connection.prepareStatement("UPDATE players SET "+value+" = ? WHERE uuid = ?")){
//            preparedStatement.setInt(1, amount);
//            preparedStatement.setString(2, uuid.toString());
//            preparedStatement.executeUpdate();
//        }
//    }
//    public int getPlayers(UUID uuid, String value) throws SQLException {
//        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM players WHERE uuid = ?")){
//            preparedStatement.setString(1, uuid.toString());
//            ResultSet resultSet = preparedStatement.executeQuery();
//            if (resultSet.next()){
//                return resultSet.getInt(value);
//            }else{
//                return 0;
//            }
//        }
//    }


    public void updatePlayerTech(UUID uuid,int amount,String techId) throws SQLException {

        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("UPDATE tech SET tech"+techId+" = ? WHERE uuid = ?")){
            preparedStatement.setInt(1, amount);
            preparedStatement.setString(2, uuid.toString());
            preparedStatement.executeUpdate();
        }
    }
    public void updatePlayerIdea(UUID uuid,int amount,String ideaId) throws SQLException {

        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("UPDATE tech SET idea"+ideaId+" = ? WHERE uuid = ?")){
            preparedStatement.setInt(1, amount);
            preparedStatement.setString(2, uuid.toString());
            preparedStatement.executeUpdate();
        }
    }


    public int getPlayerTech(UUID uuid, int techid) throws SQLException {
        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("SELECT * FROM tech WHERE uuid = ?")){
            preparedStatement.setString(1, uuid.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return resultSet.getInt("tech"+ techid);
            }else{
                return 0;
            }
        }
    }
    public int getPlayerIdea(UUID uuid, int ideaId) throws SQLException {
        try (PreparedStatement preparedStatement = globalConnection.prepareStatement("SELECT * FROM tech WHERE uuid = ?")){
            preparedStatement.setString(1, uuid.toString());
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()){
                return resultSet.getInt("idea"+ ideaId);
            }else{
                return 0;
            }
        }
    }



}
