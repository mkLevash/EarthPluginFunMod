package earthrp;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;

import java.util.Objects;
import java.util.UUID;

public class Town {

    private final UUID uuid;
    private UUID ownerId;



    private UUID portId;



    private UUID landHubId;
    private String type;
    private String name;
    private String ownerName;
    private int status;
    private int bStatus;
    private int buildings;
    private int houses;
    private int bonusBuildSite;
    private final String world;
    private final int x;
    private final int z;

    public Town(UUID townUniqueId, UUID playerUniqueId, String townType, String townName, String playerName, int townStatus, int blockadeStatus, int buildingsAmount, int townHouses, int bonusBuildingsSites, String worldName, int chunkX, int chunkZ, UUID portId, UUID landHubId){
        this.uuid = townUniqueId;
        this.ownerId = playerUniqueId;
        this.type = townType;
        this.name = townName;
        this.ownerName = playerName;
        this.status = townStatus;
        this.bStatus = blockadeStatus;
        this.buildings = buildingsAmount;
        this.houses = townHouses;
        this.bonusBuildSite = bonusBuildingsSites;
        this.world = worldName;
        this.x = chunkX;
        this.z = chunkZ;
        this.portId = portId;
        this.landHubId = landHubId;
    }

    public UUID getUniqueId(){return this.uuid;}
    public UUID getOwnerId(){return this.ownerId;}
    public String getType(){return this.type;}
    public String getName(){return this.name;}
    public String getOwnerName(){return this.ownerName;}
    public int getBlockadeStatus(){return this.bStatus;}
    public int getStatus(){return this.status;}
    public int getBuildings(){return this.buildings;}
    public int getPeople(){
        if (this.type.equals("capital")){
            return this.houses+5;
        }else{
            return this.houses+3;
        }
    }
    public int getHouses(){
        return this.houses;
    }
    public int getBonusBuildSite(){return this.bonusBuildSite;}
    public int getBuildSite(){
        if (this.houses < 5){return 1 + this.bonusBuildSite;}
        else if (this.houses < 8) {return 2 + this.bonusBuildSite;}
        else {return 3 + this.bonusBuildSite;}
    }
    public String getWorld(){return this.world;}
    public int getChunkX(){return this.x;}
    public int getChunkZ(){return this.z;}
    public Location getLocation(){
        Entity[] tileEntities = Bukkit.getWorld(this.world).getChunkAt(x,z).getEntities();
        for(Entity en: tileEntities){
            if (en instanceof ArmorStand armor){
                if(Objects.equals(armor.getCustomName(), this.name)){
                    return armor.getLocation();
                }

            }
        }
        return null;
    }

    public UUID getPortId() {
        return portId;
    }

    public UUID getLandHubId() {
        return landHubId;
    }

    public void setLandHubId(UUID landHubId) {
        this.landHubId = landHubId;
    }

    public void setPortId(UUID marketId) {
        this.portId = marketId;
    }

    public void setOwnerId(UUID newOwnerId){this.ownerId = newOwnerId;}
    public void setType(String newType){this.type = newType;}
    public void setName(String newName){this.name = newName;}
    public void setOwnerName(String newOwnerName){this.ownerName = newOwnerName;}
    public void setBlockadeStatus(int newStatus){this.bStatus = newStatus;}
    public void setStatus(int newStatus){this.status = newStatus;}
    public void setBuildings(int newAmount){this.buildings = newAmount;}
    public void setHouses(int newAmount){this.houses = newAmount;}
    public void setBonusBuildSite(int newAmount){this.bonusBuildSite = newAmount;}


}
