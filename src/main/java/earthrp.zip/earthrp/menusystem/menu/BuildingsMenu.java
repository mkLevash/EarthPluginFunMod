package earthrp.menusystem.menu;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.buildings.StandartBuildingsMenu;
import earthrp.menusystem.menu.buildings.WarBuildingsMenu;
import earthrp.menusystem.menu.tech.*;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;

public class BuildingsMenu extends Menu {
    private final Earth earthPlugin;
    public BuildingsMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
    }

    @Override
    public String getMenuName() {
        return "Строения";
    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        switch (e.getCurrentItem().getType()){

            case CRAFTING_TABLE -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new StandartBuildingsMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case VILLAGER_SPAWN_EGG -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new WarBuildingsMenu(Earth.getPlayerMenuUtility(p),this.earthPlugin).open();

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new MainMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() {

        ItemStack economy = new ItemStack(Material.CRAFTING_TABLE, 1);
        ItemMeta economyMeta = economy.getItemMeta();
        economyMeta.setDisplayName(ChatColor.YELLOW + "Основные");
        economy.setItemMeta(economyMeta);

        ItemStack reusable = new ItemStack(Material.VILLAGER_SPAWN_EGG, 1);
        ItemMeta reusableMeta = reusable.getItemMeta();
        reusableMeta.setDisplayName(ChatColor.RED + "Военные");
        reusable.setItemMeta(reusableMeta);

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.RED + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(3, economy);

        inventory.setItem(4, reusable);
//
//        inventory.setItem(6, tech7);
//
//        inventory.setItem(7, tech8);

        inventory.setItem(8, next);

    }
}
