package earthrp.menusystem.menu;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.Objects;

public class MainMenu extends Menu {
    private final Earth earthPlugin;
    public MainMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
    }

    @Override
    public String getMenuName() {
        return "Главное меню";
    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        Player p = (Player) e.getWhoClicked();
        switch (Objects.requireNonNull(e.getCurrentItem()).getType()){

            case HEART_OF_THE_SEA -> {

                e.getWhoClicked().closeInventory();

                new TechnologyMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BARREL -> {

                e.getWhoClicked().closeInventory();
                new BuildingsMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
            case LIGHT -> {

                e.getWhoClicked().closeInventory();
                new IdeasMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();

            }

        }

    }

    @Override
    public void setMenuItems() {

        ItemStack tech = new ItemStack(Material.HEART_OF_THE_SEA, 1);
        ItemMeta techMeta = tech.getItemMeta();
        techMeta.setDisplayName(ChatColor.AQUA + "Технологии");
        tech.setItemMeta(techMeta);

        ItemStack build = new ItemStack(Material.BARREL, 1);
        ItemMeta buildMeta = build.getItemMeta();
        buildMeta.setDisplayName(ChatColor.GOLD + "Здания");
        build.setItemMeta(buildMeta);

        ItemStack idea = new ItemStack(Material.LIGHT, 1);
        ItemMeta ideaMeta = idea.getItemMeta();
        ideaMeta.setDisplayName(ChatColor.YELLOW + "Идеи");
        idea.setItemMeta(ideaMeta);

        ItemStack close = new ItemStack(Material.BARRIER, 1);
        ItemMeta closeMeta = close.getItemMeta();
        closeMeta.setDisplayName(ChatColor.RED + "Закрыть");
        close.setItemMeta(closeMeta);

        inventory.setItem(3, tech);
        inventory.setItem(4, build);
        inventory.setItem(5, idea);
        inventory.setItem(8, close);

    }
}
