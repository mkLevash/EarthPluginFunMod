package earthrp.menusystem.menu;

import earthrp.Building;
import earthrp.Earth;
import earthrp.Town;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.ArrayList;

public class DeleteConfirmMenu extends Menu {
    private final Earth earthPlugin;
    Town town = playerMenuUtility.getTown();
    Building building = playerMenuUtility.getBuilding();
    public DeleteConfirmMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
    }

    @Override
    public String getMenuName() {
//        if(town==null){
//            return "Вы уверены что хотите безвозвратно удалить строение?";
//        }else{
//            return "Вы уверены что хотите безвозвратно удалить город?";
//        }
        return "Вы уверены?";

    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        switch (e.getCurrentItem().getType()){
            case EMERALD:
                //they pressed yes, kill yourself
                e.getWhoClicked().closeInventory();
                if(town==null){
                    this.earthPlugin.getServerDatabase().deleteBuilding(building);
                }else{
                    this.earthPlugin.getServerDatabase().deleteTown(town);
                }
                break;
            case BARRIER:
                e.getWhoClicked().closeInventory();
                break;
        }

    }

    @Override
    public void setMenuItems() throws SQLException {

        ItemStack yes = new ItemStack(Material.EMERALD, 1);
        ItemMeta yes_meta = yes.getItemMeta();
        yes_meta.setDisplayName(ChatColor.GREEN + "Да");
        ArrayList<String> yes_lore = new ArrayList<>();
        if(town==null){
            yes_lore.add(ChatColor.AQUA + "Вы безвозвратно удалите это строение");;
        }else{
            yes_lore.add(ChatColor.AQUA + "Вы безвозвратно удалите этот город");;
        }

        yes_meta.setLore(yes_lore);
        yes.setItemMeta(yes_meta);
        ItemStack no = new ItemStack(Material.BARRIER, 1);
        ItemMeta no_meta = no.getItemMeta();
        no_meta.setDisplayName(ChatColor.DARK_RED + "Нет");
        no.setItemMeta(no_meta);

        inventory.setItem(3, yes);
        inventory.setItem(5, no);

    }
}
