package earthrp.menusystem.menu.markets;

import earthrp.Building;
import earthrp.Earth;
import earthrp.Town;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.buildings.MiningBuildingMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;

import static earthrp.Pathfinding.findClosestMarketTownsByDirection;

public class LoadingMenu extends Menu {
    private final Earth earthPlugin;
    Building building;

    public LoadingMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        this.building = playerMenuUtility.getBuilding();
    }

    @Override
    public String getMenuName() {
        return "Поиск ближайших городов...";
    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) {
        // Блокируем любые клики во время загрузки
        e.setCancelled(true);
    }

    @Override
    public void setMenuItems() {
        // Анимация загрузки
        ItemStack loadingItem = new ItemStack(Material.COMPASS);
        ItemMeta meta = loadingItem.getItemMeta();
        meta.setDisplayName(ChatColor.YELLOW + "Идет поиск городов...");
        meta.setLore(List.of(
                ChatColor.GRAY + "Пожалуйста, подождите",
                ChatColor.GRAY + "Это может занять несколько секунд"
        ));
        loadingItem.setItemMeta(meta);

        for (int i = 0; i < getSlots(); i++) {
            inventory.setItem(i, loadingItem);
        }

        // Запускаем асинхронный поиск городов
        findTownsAsync();
    }

    private void findTownsAsync() {
        CompletableFuture.supplyAsync(() -> {
            try {
                Town[] allTowns = earthPlugin.getServerDatabase().getTowns();
                Town currentTown = earthPlugin.getServerDatabase().getTown(building.getTownId());
                return findClosestMarketTownsByDirection(currentTown, allTowns);
            } catch (SQLException e) {
                throw new CompletionException(e);
            }
        }).thenAcceptAsync(result -> {
            // Возвращаемся в главный поток для открытия меню
            Bukkit.getScheduler().runTask(earthPlugin, () -> {
                playerMenuUtility.setNearbyTowns(result);
                try {
                    new NearbyTradeTownsMenu(playerMenuUtility, earthPlugin).open();
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            });
        }).exceptionally(e -> {
            Bukkit.getScheduler().runTask(earthPlugin, () -> {
                Player player = playerMenuUtility.getOwner();
                player.sendMessage(ChatColor.RED + "Ошибка при поиске городов: " + e.getMessage());
                try {
                    new MiningBuildingMenu(playerMenuUtility, earthPlugin).open();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            });
            return null;
        });
    }
}