package earthrp.menusystem.menu.tech;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.TechnologyMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class ReusTechMenu extends Menu {

    public String CostCheck(){
        return "";
    }
    private final Earth earthPlugin;
    int ideas;
    double techMod;
    double tacGain = Earth.getInstance().getConfig().getDouble("tacGain");;
    double tacBase = Earth.getInstance().getConfig().getDouble("tacBase");
    int tacCostBase = Earth.getInstance().getConfig().getInt("tacCostBase");
    double tacIncMod = Earth.getInstance().getConfig().getDouble("tacIncMod");
    int ideaCost;
    int fullIdeas;
    int ideaIncMod = Earth.getInstance().getConfig().getInt("ideaIncMod");
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = p.getUniqueId();
    EarthPlayer player;
    int t42;
    int cost42;
    public ReusTechMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        this.ideas = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,41);
        this.t42 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,42);
        cost42 = (int) (tacCostBase *(Math.pow(tacIncMod,t42)));//
        fullIdeas = (int) ( Math.floor((double) ideas / 5));
        techMod = 1;
        ideaCost = (int)Math.floor(techMod*(fullIdeas*ideaIncMod + 10));
        player = this.earthPlugin.getServerDatabase().getPlayer(uuid);
    }

    @Override
    public String getMenuName() {
        return "Социальные технологии";
    }


    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {

        int oi_balance = player.getOiBalance();

        if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Ревизия")){
            int t2 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,2);
            int cost40 = t2*10 + 10;
            if (oi_balance>=cost40){
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-10);
                e.getWhoClicked().closeInventory();
                ItemStack debt = new ItemStack(Material.PAPER, 1);
                ItemMeta debtMeta = debt.getItemMeta();
                assert debtMeta != null;
                debtMeta.setDisplayName("Возможность простить 1 долг");
                debtMeta.addEnchant(Enchantment.INFINITY,1,true);
                debt.setItemMeta(debtMeta);
                p.getInventory().addItem(debt);
                new ReusTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Идея")) {
            int t41 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,41);
            if (oi_balance>=ideaCost){
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,t41+1,"41");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-ideaCost);
                e.getWhoClicked().closeInventory();
                ItemStack idea = new ItemStack(Material.SOUL_LANTERN, 1);
                ItemMeta ideaMeta = idea.getItemMeta();
                assert ideaMeta != null;
                ideaMeta.setDisplayName("Идея");
                ideaMeta.addEnchant(Enchantment.INFINITY,1,true);
                idea.setItemMeta(ideaMeta);
                p.getInventory().addItem(idea);
                new ReusTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }

        } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Тактика")) {
            if (oi_balance>=cost42){
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,t42+1,"42");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-cost42);
                e.getWhoClicked().closeInventory();
                new ReusTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }

        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");

            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();
                new TechnologyMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {
        UUID uuid = this.playerMenuUtility.getOwner().getUniqueId();
        int t2 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,2);
        String cost40 = String.valueOf(t2*10 + 10);
        ItemStack tech40 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech40Meta = tech40.getItemMeta();
        tech40Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bРевизия &e" + cost40 + "&fૹ"));
        tech40Meta.setLore(List.of(ChatColor.DARK_AQUA +"Даёт возможность простить долг ",
                ChatColor.GREEN + "Многоразовое",
                ChatColor.DARK_RED + "ОИ НЕ ВОЗВРАЩАЮТСЯ"));
        tech40.setItemMeta(tech40Meta);

        ItemStack tech41 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech41Meta = tech41.getItemMeta();
        tech41Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bИдея &e" + ideaCost + "&fૹ"));
        tech41Meta.setLore(List.of(ChatColor.DARK_AQUA +"Даёт 1 идею. ",
                ChatColor.translateAlternateColorCodes('&',"&eКаждый полный шалкер даёт +" + ideaIncMod + "&fૹ&e к стоимости"),
                ChatColor.GREEN + "Многоразовое",
                ChatColor.DARK_RED + "ОИ НЕ ВОЗВРАЩАЮТСЯ"));
        tech41.setItemMeta(tech41Meta);


        ItemStack tech42 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech42Meta = tech42.getItemMeta();
        tech42Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bТактика &e" + cost42 + "&fૹ"));
        tech42Meta.setLore(List.of(ChatColor.DARK_AQUA +"Даёт "+tacGain+" тактики",
                ChatColor.translateAlternateColorCodes('&',"&3Текущее значение тактики - &2" + String.format("%.2f",tacBase+tacGain*t42)),
                ChatColor.GREEN + "Многоразовое",
                ChatColor.DARK_RED + "ОИ НЕ ВОЗВРАЩАЮТСЯ"));
        tech42.setItemMeta(tech42Meta);

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.DARK_GREEN + "BACK");
        next.setItemMeta(nextMeta);




        inventory.setItem(3, tech40);

        inventory.setItem(4, tech41);

        inventory.setItem(5, tech42);



        inventory.setItem(8, next);

    }
}
