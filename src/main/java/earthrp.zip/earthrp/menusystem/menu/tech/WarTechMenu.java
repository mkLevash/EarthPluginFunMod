package earthrp.menusystem.menu.tech;

import earthrp.Earth;
import earthrp.files.CustomConfig;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.TechnologyMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class WarTechMenu extends Menu {
    private final Earth earthPlugin;
    public WarTechMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        cost_mod = 1;
        this.tech23Cost = (int) Math.floor(tech23Cost * cost_mod);
        this.tech24Cost = (int) Math.floor(tech24Cost * cost_mod);
        this.tech25Cost = (int) Math.floor(tech25Cost * cost_mod);
        this.tech26Cost = (int) Math.floor(tech26Cost * cost_mod);
        this.tech27Cost = (int) Math.floor(tech27Cost * cost_mod);
        this.tech28Cost = (int) Math.floor(tech28Cost * cost_mod);
        this.tech29Cost = (int) Math.floor(tech29Cost * cost_mod);
        this.tech30Cost = (int) Math.floor(tech30Cost * cost_mod);
        this.tech31Cost = (int) Math.floor(tech31Cost * cost_mod);
        this.tech32Cost = (int) Math.floor(tech32Cost * cost_mod);
        this.tech33Cost = (int) Math.floor(tech33Cost * cost_mod);
        this.tech34Cost = (int) Math.floor(tech34Cost * cost_mod);
        this.tech35Cost = (int) Math.floor(tech35Cost * cost_mod);
        this.tech36Cost = (int) Math.floor(tech36Cost * cost_mod);
        this.tech37Cost = (int) Math.floor(tech37Cost * cost_mod);
        this.tech38Cost = (int) Math.floor(tech38Cost * cost_mod);
        this.tech39Cost = (int) Math.floor(tech39Cost * cost_mod);
    }
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = this.playerMenuUtility.getOwner().getUniqueId();
    double cost_mod;
    int tech23Cost = CustomConfig.get().getInt("tech.cost.tech23");
    String tech23Name = CustomConfig.get().getString("tech.name.tech23");

    int tech24Cost = CustomConfig.get().getInt("tech.cost.tech24");
    String tech24Name = CustomConfig.get().getString("tech.name.tech24");

    int tech25Cost = CustomConfig.get().getInt("tech.cost.tech25");
    String tech25Name = CustomConfig.get().getString("tech.name.tech25");

    int tech26Cost = CustomConfig.get().getInt("tech.cost.tech26");
    String tech26Name = CustomConfig.get().getString("tech.name.tech26");

    int tech27Cost = CustomConfig.get().getInt("tech.cost.tech27");
    String tech27Name = CustomConfig.get().getString("tech.name.tech27");

    int tech28Cost = CustomConfig.get().getInt("tech.cost.tech28");
    String tech28Name = CustomConfig.get().getString("tech.name.tech28");

    int tech29Cost = CustomConfig.get().getInt("tech.cost.tech29");
    String tech29Name = CustomConfig.get().getString("tech.name.tech29");

    int tech30Cost = CustomConfig.get().getInt("tech.cost.tech30");
    String tech30Name = CustomConfig.get().getString("tech.name.tech30");

    int tech31Cost = CustomConfig.get().getInt("tech.cost.tech31");
    String tech31Name = CustomConfig.get().getString("tech.name.tech31");

    int tech32Cost = CustomConfig.get().getInt("tech.cost.tech32");
    String tech32Name = CustomConfig.get().getString("tech.name.tech32");

    int tech33Cost = CustomConfig.get().getInt("tech.cost.tech33");
    String tech33Name = CustomConfig.get().getString("tech.name.tech33");

    int tech34Cost = CustomConfig.get().getInt("tech.cost.tech34");
    String tech34Name = CustomConfig.get().getString("tech.name.tech34");

    int tech35Cost = CustomConfig.get().getInt("tech.cost.tech35");
    String tech35Name = CustomConfig.get().getString("tech.name.tech35");

    int tech36Cost = CustomConfig.get().getInt("tech.cost.tech36");
    String tech36Name = CustomConfig.get().getString("tech.name.tech36");

    int tech37Cost = CustomConfig.get().getInt("tech.cost.tech37");
    String tech37Name = CustomConfig.get().getString("tech.name.tech37");

    int tech38Cost = CustomConfig.get().getInt("tech.cost.tech38");
    String tech38Name = CustomConfig.get().getString("tech.name.tech38");

    int tech39Cost = CustomConfig.get().getInt("tech.cost.tech39");
    String tech39Name = CustomConfig.get().getString("tech.name.tech39");

    @Override
    public String getMenuName() {
        return "Социальные технологии";
    }

    @Override
    public int getSlots() {
        return 36;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {

        if(e.getCurrentItem().getItemMeta().getDisplayName().contains("ૹ")){

            int t7 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,7);
            int t32Check = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,31)*this.earthPlugin.getServerDatabase().getPlayerTech(uuid,30);
            int t32 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,32);
            int t34 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,34);
            int t35 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,35);
            int t36 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,36);
            int t38 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,38);
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech23Name)&& t7 != 0 && this.earthPlugin.investTech(uuid,"23",tech23Cost)){
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech24Name)&& this.earthPlugin.investTech(uuid,"24",tech24Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech25Name)&& this.earthPlugin.investTech(uuid,"25",tech25Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech26Name)&& this.earthPlugin.investTech(uuid,"26",tech26Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech27Name) && this.earthPlugin.investTech(uuid,"27",tech27Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech28Name)&& this.earthPlugin.investTech(uuid,"28",tech28Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech29Name) && this.earthPlugin.investTech(uuid,"29",tech29Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech30Name)&& this.earthPlugin.investTech(uuid,"30",tech30Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech31Name)&& this.earthPlugin.investTech(uuid,"31",tech31Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech32Name)&& t32Check != 0 && this.earthPlugin.investTech(uuid,"32",tech32Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech33Name)&& t32!= 0 && this.earthPlugin.investTech(uuid,"33",tech33Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech34Name) && this.earthPlugin.investTech(uuid,"34",tech34Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech35Name)&& t34 != 0 && this.earthPlugin.investTech(uuid,"35",tech35Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech36Name)&& t35 != 0 && this.earthPlugin.investTech(uuid,"36",tech36Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech37Name)&& t36 != 0 && this.earthPlugin.investTech(uuid,"37",tech37Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech38Name)&& t32 != 0 && this.earthPlugin.investTech(uuid,"38",tech38Cost) ) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech39Name)&& t38 != 0 && this.earthPlugin.investTech(uuid,"39",tech39Cost)) {
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }else{
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech23Name)){
                this.earthPlugin.backTech(uuid,"23",tech23Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech24Name)) {
                this.earthPlugin.backTech(uuid,"24",tech24Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech25Name)) {
                this.earthPlugin.backTech(uuid,"25",tech25Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech26Name)) {
                this.earthPlugin.backTech(uuid,"26",tech26Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech27Name)) {
                this.earthPlugin.backTech(uuid,"27",tech27Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech28Name)) {
                this.earthPlugin.backTech(uuid,"28",tech28Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech29Name)) {
                this.earthPlugin.backTech(uuid,"29",tech29Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech30Name)) {
                this.earthPlugin.backTech(uuid,"30",tech30Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech31Name)) {
                this.earthPlugin.backTech(uuid,"31",tech31Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech32Name)) {
                this.earthPlugin.backTech(uuid,"32",tech32Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech33Name)) {
                this.earthPlugin.backTech(uuid,"33",tech33Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech34Name)) {
                this.earthPlugin.backTech(uuid,"34",tech34Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech35Name)) {
                this.earthPlugin.backTech(uuid,"35",tech35Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech36Name)) {
                this.earthPlugin.backTech(uuid,"36",tech36Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech37Name)) {
                this.earthPlugin.backTech(uuid,"37",tech37Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech38Name)) {
                this.earthPlugin.backTech(uuid,"38",tech38Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech39Name)) {
                this.earthPlugin.backTech(uuid,"39",tech39Cost);
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }

        switch (e.getCurrentItem().getType()){



            case GOLD_INGOT -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new TechnologyMenu(Earth.getPlayerMenuUtility(p),this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {

        //военнная канцелярия
        ItemStack tech23 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech23Meta = tech23.getItemMeta();
        int t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,23);
        if (t==0){
            tech23Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech23Name+" &b"+tech23Cost+"&fૹ"));
            tech23Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bбазовая канцелярия"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет делать &dвоенные указы.")));
            tech23.setItemMeta(tech23Meta);
        }else{
            tech23Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech23Name));
            tech23Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&2Позволяет делать &dвоенные указы.")));
            tech23Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech23.setItemMeta(tech23Meta);
        }

        //*и
        ItemStack tech24 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech24Meta = tech24.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,24);
        if (t==0){
            tech24Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech24Name+" &b"+tech24Cost+"&fૹ"));
            tech24Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить &dкрепости.")));
            tech24.setItemMeta(tech24Meta);
        }else{
            tech24Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech24Name));
            tech24Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&2Позволяет строить &dкрепости.")));
            tech24Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech24.setItemMeta(tech24Meta);
        }

        //военнная канцелярия
        ItemStack tech25 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech25Meta = tech25.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,25);
        if (t==0){
            tech25Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech25Name+" &b"+tech25Cost+"&fૹ"));
            tech25Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+1 &7к восстановлению &dMP&7 во время войны.")));
            tech25.setItemMeta(tech25Meta);
        }else{
            tech25Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech25Name));
            tech25Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+1 &2к восстановлению &dMP&2 во время войны.")));
            tech25Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech25.setItemMeta(tech25Meta);
        }

        ItemStack tech26 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech26Meta = tech26.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,26);
        if (t==0){
            tech26Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech26Name+" &b"+tech26Cost+"&fૹ"));
            tech26Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&7Позволяет производить &dштурм крепости"),
                    ChatColor.translateAlternateColorCodes('&', "&dСтартовая осада &a+10%" )));
            tech26.setItemMeta(tech26Meta);
        }else{
            tech26Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech26Name));
            tech26Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&2Позволяет производить &dштурм крепости"),
                    ChatColor.translateAlternateColorCodes('&', "&dСтартовая осада &a+10%" )));
            tech26Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech26.setItemMeta(tech26Meta);
        }

        ItemStack tech27 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech27Meta = tech27.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,27);
        if (t==0){
            tech27Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech27Name+" &b"+tech27Cost+"&fૹ"));
            tech27Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+5% &dСопротивления урону в фазу &6Шока.")));
            tech27.setItemMeta(tech27Meta);
        }else{
            tech27Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech27Name));
            tech27Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&e+5% &dСопротивлени урону в фазу &6Шока.")));
            tech27Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech27.setItemMeta(tech27Meta);
        }

        ItemStack tech28 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech28Meta = tech28.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,28);
        if (t==0){
            tech28Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech28Name+" &b"+tech28Cost+"&fૹ"));
            tech28Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+10% &dурона в фазе &4Огня.")));
            tech28.setItemMeta(tech28Meta);
        }else{
            tech28Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech28Name));
            tech28Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+10% &dурона в фазе &4Огня.")));
            tech28Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech28.setItemMeta(tech28Meta);
        }

        ItemStack tech29 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech29Meta = tech29.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,29);
        if (t==0){
            tech29Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech29Name+" &b"+tech29Cost+"&fૹ"));
            tech29Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+25% &dКомбат Абилити &eКавалерии.")));
            tech29.setItemMeta(tech29Meta);
        }else{
            tech29Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech29Name));
            tech29Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&', "&a+25% &dКомбат Абилити &eКавалерии.")));
            tech29Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech29.setItemMeta(tech29Meta);
        }

        ItemStack tech30 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech30Meta = tech30.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,30);
        if (t==0){
            tech30Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech30Name+" &b"+tech30Cost+"&fૹ"));
            tech30Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет производить &5порох&7 на мануфактурах"),
                    ChatColor.translateAlternateColorCodes('&', "&7и &5файрболы&7 на заводах."),
                    ChatColor.translateAlternateColorCodes('&', "&6Каждая пороховое предприятие потребляет &5уголь")
                    ));
            tech30.setItemMeta(tech30Meta);
        }else{
            tech30Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech30Name));
            tech30Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Позволяет производить &5порох&2 на мануфактурах"),
                    ChatColor.translateAlternateColorCodes('&', "&2и &5файрболы&2 на заводах."),
                    ChatColor.translateAlternateColorCodes('&', "&6Каждая пороховое предприятие потребляет &5уголь")
                    ));
            tech30Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech30.setItemMeta(tech30Meta);
        }

        ItemStack tech311 = new ItemStack(Material.ZOMBIE_SPAWN_EGG, 1);
        ItemMeta tech311Meta = tech311.getItemMeta();
        tech311Meta.setDisplayName(ChatColor.LIGHT_PURPLE + "Пехота 1 уровня");
        tech311Meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.35"),
                ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.30"),
                ChatColor.GREEN + "Уже исследовано"));
        tech311Meta.addEnchant(Enchantment.INFINITY,1,true);
        tech311.setItemMeta(tech311Meta);

        //Пехота 2 уровня
        ItemStack tech31 = new ItemStack(Material.SKELETON_SPAWN_EGG, 1);
        ItemMeta tech31Meta = tech31.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,31);
        if (t==0){
            tech31Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech31Name+" &b"+tech31Cost+"&fૹ"));
            tech31Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.8"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.95")
                    ));
            tech31.setItemMeta(tech31Meta);
        }else{
            tech31Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech31Name));
            tech31Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.8"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.95")
            ));
            tech31Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech31.setItemMeta(tech31Meta);
        }

        //Пехота 3 уровня
        ItemStack tech32 = new ItemStack(Material.SPIDER_SPAWN_EGG, 1);
        ItemMeta tech32Meta = tech32.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,32);
        if (t==0){
            tech32Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech32Name+" &b"+tech32Cost+"&fૹ"));
            tech32Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 2.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.5"),
                    ChatColor.translateAlternateColorCodes('&', "&eДолжен быть исследован &bпорох")
            ));
            tech32.setItemMeta(tech32Meta);
        }else{
            tech32Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech32Name));
            tech32Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 2.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.5")
            ));
            tech32Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech32.setItemMeta(tech32Meta);
        }
        
        //пехота 4 уровня
        ItemStack tech33 = new ItemStack(Material.CREEPER_SPAWN_EGG, 1);
        ItemMeta tech33Meta = tech33.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,33);
        if (t==0){
            tech33Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech33Name+" &b"+tech33Cost+"&fૹ"));
            tech33Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 3.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 2.1")
            ));
            tech33.setItemMeta(tech33Meta);
        }else{
            tech33Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech33Name));
            tech33Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 3.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 2.1")
            ));
            tech33Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech33.setItemMeta(tech33Meta);
        }
        
        //кавалерия 1 уровня
        ItemStack tech34 = new ItemStack(Material.CHICKEN_SPAWN_EGG, 1);
        ItemMeta tech34Meta = tech34.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,34);
        if (t==0){
            tech34Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech34Name+" &b"+tech34Cost+"&fૹ"));
            tech34Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.6")
            ));
            tech34.setItemMeta(tech34Meta);
        }else{
            tech34Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech34Name));
            tech34Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 1.6")
            ));
            tech34Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech34.setItemMeta(tech34Meta);
        }

        //кавалерия 2 уровня
        ItemStack tech35 = new ItemStack(Material.PIG_SPAWN_EGG, 1);
        ItemMeta tech35Meta = tech35.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,35);
        if (t==0){
            tech35Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech35Name+" &b"+tech35Cost+"&fૹ"));
            tech35Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.1"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 3.6")
            ));
            tech35.setItemMeta(tech35Meta);
        }else{
            tech35Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech35Name));
            tech35Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.1"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 3.6")
            ));
            tech35Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech35.setItemMeta(tech35Meta);
        }
        
        //кавалерия 3
        ItemStack tech36 = new ItemStack(Material.SHEEP_SPAWN_EGG, 1);
        ItemMeta tech36Meta = tech36.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,36);
        if (t==0){
            tech36Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech36Name+" &b"+tech36Cost+"&fૹ"));
            tech36Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 4.2")
            ));
            tech36.setItemMeta(tech36Meta);
        }else{
            tech36Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech36Name));
            tech36Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 0.5"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 4.2")
            ));
            tech36Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech36.setItemMeta(tech36Meta);
        }
        
        //кавалерияя 4 уровня
        ItemStack tech37 = new ItemStack(Material.COW_SPAWN_EGG, 1);
        ItemMeta tech37Meta = tech37.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,37);
        if (t==0){
            tech37Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech37Name+" &b"+tech37Cost+"&fૹ"));
            tech37Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 1"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 5")
            ));
            tech37.setItemMeta(tech37Meta);
        }else{
            tech37Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech37Name));
            tech37Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 1"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 5")
            ));
            tech37Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech37.setItemMeta(tech37Meta);
        }

        //артиллерия 1 уровня
        ItemStack tech38 = new ItemStack(Material.GUARDIAN_SPAWN_EGG, 1);
        ItemMeta tech38Meta = tech38.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,38);
        if (t==0){
            tech38Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech38Name+" &b"+tech38Cost+"&fૹ"));
            tech38Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 15"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0"),
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bпехота &33&b уровня")
            ));
            tech38.setItemMeta(tech38Meta);
        }else{
            tech38Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech38Name));
            tech38Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 15"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0")
                    
            ));
            tech38Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech38.setItemMeta(tech38Meta);
        }

        //артиллерия 2 уровня
        ItemStack tech39 = new ItemStack(Material.ELDER_GUARDIAN_SPAWN_EGG, 1);
        ItemMeta tech39Meta = tech39.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,39);
        if (t==0){
            tech39Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech39Name+" &b"+tech39Cost+"&fૹ"));
            tech39Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 30"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.35")
            ));
            tech39.setItemMeta(tech39Meta);
        }else{
            tech39Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&f"+tech39Name));
            tech39Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&4Огонь &f-&2 30"),
                    ChatColor.translateAlternateColorCodes('&', "&6Шок &f-&2 0.35")

            ));
            tech39Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech39.setItemMeta(tech39Meta);
        }


        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.DARK_GREEN + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(0, tech29);
        inventory.setItem(1, tech30);
        inventory.setItem(9, tech28);
        inventory.setItem(10, tech27);
        inventory.setItem(18, tech26);
        inventory.setItem(19, tech25);
        inventory.setItem(27, tech24);
        inventory.setItem(28, tech23);

        inventory.setItem(3, tech33);
        inventory.setItem(12, tech32);
        inventory.setItem(21, tech31);
        inventory.setItem(30, tech311);

        inventory.setItem(5, tech37);
        inventory.setItem(14, tech36);
        inventory.setItem(23, tech35);
        inventory.setItem(32, tech34);

        inventory.setItem(7, tech39);
        inventory.setItem(16, tech38);





        inventory.setItem(8, next);

    }
}
