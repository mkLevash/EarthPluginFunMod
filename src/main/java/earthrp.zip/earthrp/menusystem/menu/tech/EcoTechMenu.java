package earthrp.menusystem.menu.tech;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.files.CustomConfig;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.TechnologyMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class EcoTechMenu extends Menu {
    private final Earth earthPlugin;
    public EcoTechMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        player = this.earthPlugin.getServerDatabase().getPlayer(uuid);
        cost_mod = 1;
        this.tech1Cost = (int) Math.floor(tech1Cost * cost_mod);
        this.tech2Cost = (int) Math.floor(tech2Cost * cost_mod);
        this.tech3Cost = (int) Math.floor(tech3Cost * cost_mod);
        this.tech4Cost = (int) Math.floor(tech4Cost * cost_mod);
        this.tech5Cost = (int) Math.floor(tech5Cost * cost_mod);
    }
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = p.getUniqueId();
    EarthPlayer player;
    double cost_mod;

    int tech1Cost = CustomConfig.get().getInt("tech.cost.tech1");
    String tech1Name = CustomConfig.get().getString("tech.name.tech1");

    int tech2Cost = CustomConfig.get().getInt("tech.cost.tech2");
    String tech2Name = CustomConfig.get().getString("tech.name.tech2");

    int tech3Cost = CustomConfig.get().getInt("tech.cost.tech3");
    String tech3Name = CustomConfig.get().getString("tech.name.tech3");

    int tech4Cost = CustomConfig.get().getInt("tech.cost.tech4");
    String tech4Name = CustomConfig.get().getString("tech.name.tech4");

    int tech5Cost = CustomConfig.get().getInt("tech.cost.tech5");
    String tech5Name = CustomConfig.get().getString("tech.name.tech5");


    @Override
    public String getMenuName() {
        return "Экономические технологии";
    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        int oi_balance = player.getOiBalance();

        if (e.getCurrentItem().getItemMeta().getDisplayName().contains("ૹ")){
            int t1 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,1);
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Торговля") && oi_balance >= tech3Cost){
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"3");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech3Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Банк") && oi_balance >= tech1Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"1");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech1Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Развитая") && oi_balance >= tech2Cost && t1 != 0) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"2");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech2Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Мореплавание") && oi_balance >= tech4Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"4");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech4Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Железные дороги") && oi_balance >= tech5Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"5");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech5Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }else{
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Банк")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"1");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech1Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("банковсая")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"2");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech2Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Торговля")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"3");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech3Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Мореплавание")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"4");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech4Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Железные дороги")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"5");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech5Cost);
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }



        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");
//                new EcoTechMenu(Earth.getPlayerMenuUtility(p)).open();

            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();
                new TechnologyMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {
// Tech 1 - Банкирство
        ItemStack tech1 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech1Meta = tech1.getItemMeta();
        int t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 1);
        if (t == 0) {
            tech1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech1Name + " &b" + tech1Cost + "&fૹ"));
            tech1Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Добавляет возможность строить банки")
            ));
            tech1.setItemMeta(tech1Meta);
        } else {
            tech1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech1Name));
            tech1Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Добавляет возможность строить банки")
            ));
            tech1Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech1.setItemMeta(tech1Meta);
        }

// Tech 2 - Развитая банковская система
        ItemStack tech2 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech2Meta = tech2.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 2);
        if (t == 0) {
            tech2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech2Name + " &b" + tech2Cost + "&fૹ"));
            tech2Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжен быть построен банк"),
                    ChatColor.translateAlternateColorCodes('&', "&aСнижает процентную ставку до 4%"),
                    ChatColor.translateAlternateColorCodes('&', "&aЕдиничный долг - 25 моры"),
                    ChatColor.translateAlternateColorCodes('&', "&eУвеличивает стоимость ревизии в 2 раза")
            ));
            tech2.setItemMeta(tech2Meta);
        } else {
            tech2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech2Name));
            tech2Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&aСнижает процентную ставку до 4%"),
                    ChatColor.translateAlternateColorCodes('&', "&aЕдиничный долг - 25 моры"),
                    ChatColor.translateAlternateColorCodes('&', "&eУвеличивает стоимость ревизии в 2 раза")
            ));
            tech2Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech2.setItemMeta(tech2Meta);
        }

// Tech 3 - Торговля
        ItemStack tech3 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech3Meta = tech3.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 3);
        if (t == 0) {
            tech3Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech3Name + " &b" + tech3Cost + "&fૹ"));
            tech3Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет собирать доходы с торговли"),
                    ChatColor.translateAlternateColorCodes('&', "&7и открывает возможность экономических"),
                    ChatColor.translateAlternateColorCodes('&', "&7отношений с другими государствами"),
                    ChatColor.translateAlternateColorCodes('&', "&eПодробнее в правилах Глава 7")
            ));
            tech3.setItemMeta(tech3Meta);
        } else {
            tech3Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech3Name));
            tech3Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет собирать доходы с торговли"),
                    ChatColor.translateAlternateColorCodes('&', "&7и открывает возможность экономических"),
                    ChatColor.translateAlternateColorCodes('&', "&7отношений с другими государствами"),
                    ChatColor.translateAlternateColorCodes('&', "&eПодробнее в правилах Глава 7")
            ));
            tech3Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech3.setItemMeta(tech3Meta);
        }

// Tech 4 - Мореплавание
        ItemStack tech4 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech4Meta = tech4.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 4);
        if (t == 0) {
            tech4Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech4Name + " &b" + tech4Cost + "&fૹ"));
            tech4Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить порты и транспортные корабли")
            ));
            tech4.setItemMeta(tech4Meta);
        } else {
            tech4Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech4Name));
            tech4Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить порты и транспортные корабли")
            ));
            tech4Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech4.setItemMeta(tech4Meta);
        }

// Tech 5 - Железные дороги
        ItemStack tech5 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech5Meta = tech5.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 5);
        if (t == 0) {
            tech5Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech5Name + " &b" + tech5Cost + "&fૹ"));
            tech5Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Даёт возможность строить железные дороги")
            ));
            tech5.setItemMeta(tech5Meta);
        } else {
            tech5Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech5Name));
            tech5Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Даёт возможность строить железные дороги")
            ));
            tech5Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech5.setItemMeta(tech5Meta);
        }


        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.DARK_GREEN + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(2, tech3);

        inventory.setItem(3, tech4);

        inventory.setItem(4, tech1);

        inventory.setItem(5, tech2);

        inventory.setItem(6, tech5);

        inventory.setItem(8, next);

    }
}
