package earthrp.menusystem.menu.tech;

import earthrp.Earth;
import earthrp.files.CustomConfig;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.TechnologyMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class CraftTechMenu extends Menu {

    private final Earth earthPlugin;
    public CraftTechMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        cost_mod = 1;
        this.tech14Cost = (int) Math.floor(tech14Cost * cost_mod);
        this.tech15Cost = (int) Math.floor(tech15Cost * cost_mod);
        this.tech16Cost = (int) Math.floor(tech16Cost * cost_mod);
        this.tech17Cost = (int) Math.floor(tech17Cost * cost_mod);
        this.tech18Cost = (int) Math.floor(tech18Cost * cost_mod);
        this.tech19Cost = (int) Math.floor(tech19Cost * cost_mod);
        this.tech20Cost = (int) Math.floor(tech20Cost * cost_mod);
        this.tech21Cost = (int) Math.floor(tech21Cost * cost_mod);
        this.tech22Cost = (int) Math.floor(tech22Cost * cost_mod);
    }
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = this.playerMenuUtility.getOwner().getUniqueId();
    double cost_mod;
    int tech14Cost = CustomConfig.get().getInt("tech.cost.tech14");
    String tech14Name = CustomConfig.get().getString("tech.name.tech14");

    int tech15Cost = CustomConfig.get().getInt("tech.cost.tech15");
    String tech15Name = CustomConfig.get().getString("tech.name.tech15");

    int tech16Cost = CustomConfig.get().getInt("tech.cost.tech16");
    String tech16Name = CustomConfig.get().getString("tech.name.tech16");

    int tech17Cost = CustomConfig.get().getInt("tech.cost.tech17");
    String tech17Name = CustomConfig.get().getString("tech.name.tech17");

    int tech18Cost = CustomConfig.get().getInt("tech.cost.tech18");
    String tech18Name = CustomConfig.get().getString("tech.name.tech18");

    int tech19Cost = CustomConfig.get().getInt("tech.cost.tech19");
    String tech19Name = CustomConfig.get().getString("tech.name.tech19");

    int tech20Cost = CustomConfig.get().getInt("tech.cost.tech20");
    String tech20Name = CustomConfig.get().getString("tech.name.tech20");

    int tech21Cost = CustomConfig.get().getInt("tech.cost.tech21");
    String tech21Name = CustomConfig.get().getString("tech.name.tech21");

    int tech22Cost = CustomConfig.get().getInt("tech.cost.tech22");
    String tech22Name = CustomConfig.get().getString("tech.name.tech22");


    @Override
    public String getMenuName() {
        return "Социальные технологии";
    }

    @Override
    public int getSlots() {
        return 18;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        
        if(e.getCurrentItem().getItemMeta().getDisplayName().contains("ૹ")){
            int t4 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,4);
            int t16 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,16);
            int t17 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,17);
            int t22Check = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,20)*this.earthPlugin.getServerDatabase().getPlayerTech(uuid,30);
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech14Name) && this.earthPlugin.investTech(uuid,"14",tech14Cost)){
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech15Name)&& this.earthPlugin.investTech(uuid,"15",tech15Cost)) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech16Name)&& this.earthPlugin.investTech(uuid,"16",tech16Cost)) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech17Name)&& t16 != 0 && this.earthPlugin.investTech(uuid,"17",tech17Cost) ) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech18Name) && t17 != 0 && this.earthPlugin.investTech(uuid,"18",tech18Cost)) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech19Name)&& this.earthPlugin.investTech(uuid,"19",tech19Cost)) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech20Name)&& t4 != 0 && this.earthPlugin.investTech(uuid,"20",tech20Cost) ) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech21Name)&& this.earthPlugin.investTech(uuid,"21",tech21Cost)) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech22Name)&& t22Check != 0 && this.earthPlugin.investTech(uuid,"22",tech22Cost) ) {
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }else{
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech14Name)){
                this.earthPlugin.backTech(uuid,"14",tech14Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech15Name)) {
                this.earthPlugin.backTech(uuid,"15",tech15Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech16Name)) {
                this.earthPlugin.backTech(uuid,"16",tech16Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech17Name)) {
                this.earthPlugin.backTech(uuid,"17",tech17Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech18Name)) {
                this.earthPlugin.backTech(uuid,"18",tech18Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech19Name)) {
                this.earthPlugin.backTech(uuid,"19",tech19Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech20Name)) {
                this.earthPlugin.backTech(uuid,"20",tech20Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech21Name)) {
                this.earthPlugin.backTech(uuid,"21",tech21Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(tech22Name)) {
                this.earthPlugin.backTech(uuid,"22",tech22Cost);
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }

        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new TechnologyMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {

        int t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,14);
        ItemStack tech14 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech14Meta = tech14.getItemMeta();
        if (t==0){
            tech14Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&b"+tech14Name+" &e"+tech14Cost+"&fૹ"));
            tech14Meta.setLore(List.of(ChatColor.DARK_AQUA +"Позволяет разводить скот."));
            tech14.setItemMeta(tech14Meta);
        }else {
            tech14Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&d"+tech14Name));
            tech14Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет разводить скот."));
            tech14Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech14.setItemMeta(tech14Meta);
        }
        
        ItemStack tech15 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech15Meta = tech15.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,15);
        if (t == 0){
            tech15Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bЛесопилка &e"+tech15Cost+"&fૹ"));
            tech15Meta.setLore(List.of(
                    ChatColor.DARK_AQUA +"Позволяет строить лесопилка."));
            tech15.setItemMeta(tech15Meta);
        }else {
            tech15Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dЛесопилка"));
            tech15Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить лесопилку."));
            tech15Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech15.setItemMeta(tech15Meta);
        }

        
        ItemStack tech16 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech16Meta = tech16.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,16);
        if (t == 0){
            tech16Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bШахта &e"+tech16Cost+"&fૹ"));
            tech16Meta.setLore(List.of(
                    ChatColor.DARK_AQUA +"Позволяет строить шахту."));
            tech16.setItemMeta(tech16Meta);
        }else {
            tech16Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dШахта"));
            tech16Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить шахту."));
            tech16Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech16.setItemMeta(tech16Meta);
        }
        

        ItemStack tech17 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech17Meta = tech17.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,17);
        if (t == 0){
            tech17Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bРудник &e"+tech17Cost+"&fૹ"));
            tech17Meta.setLore(List.of(
                    ChatColor.YELLOW + "Должна быть исследована шахта",
                    ChatColor.DARK_AQUA +"Позволяет строить рудник."));
            tech17.setItemMeta(tech17Meta);
        }else {
            tech17Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dРудник"));
            tech17Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить рудник."));
            tech17Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech17.setItemMeta(tech17Meta);
        }

        ItemStack tech18 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech18Meta = tech18.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,18);
        if (t == 0){
            tech18Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bКарьер &e"+tech18Cost+"&fૹ"));
            tech18Meta.setLore(List.of(
                    ChatColor.YELLOW + "Должны быть исследованы рудник и порох",
                    ChatColor.DARK_AQUA +"Позволяет строить карьер."));
            tech18.setItemMeta(tech18Meta);
        }else {
            tech18Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dКарьер"));
            tech18Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить карьер."));
            tech18Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech18.setItemMeta(tech18Meta);
        }

        ItemStack tech19 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech19Meta = tech19.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,19);
        if (t == 0){
            tech19Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bКузница &e"+tech19Cost+"&fૹ"));
            tech19Meta.setLore(List.of(
                    ChatColor.DARK_AQUA +"Позволяет строить кузницу."));
            tech19.setItemMeta(tech19Meta);
        }else {
            tech19Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dКузница"));
            tech19Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить кузницу."));
            tech19Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech19.setItemMeta(tech19Meta);
        }

        ItemStack tech20 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech20Meta = tech20.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,20);
        if (t == 0){
            tech20Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bВерфь &e"+tech20Cost+"&fૹ"));
            tech20Meta.setLore(List.of(
                    ChatColor.YELLOW + "Должно быть исследовано мореплавание",
                    ChatColor.DARK_AQUA +"Позволяет строить верфь."));
            tech20.setItemMeta(tech20Meta);
        }else {
            tech20Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dВерфь"));
            tech20Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить верфь."));
            tech20Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech20.setItemMeta(tech20Meta);
        }

        ItemStack tech21 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech21Meta = tech21.getItemMeta();
        tech21Meta.setDisplayName("Мануфактура 50ૹ");
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,21);
        if (t == 0){
            tech21Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bМануфактура &e"+tech21Cost+"&fૹ"));
            tech21Meta.setLore(List.of(
                    ChatColor.DARK_AQUA +"Позволяет строить Мануфактуры."));
            tech21.setItemMeta(tech21Meta);
        }else {
            tech21Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dМануфактура"));
            tech21Meta.setLore(List.of(
                    ChatColor.DARK_GREEN +"Позволяет строить Мануфактуры."));
            tech21Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech21.setItemMeta(tech21Meta);
        }


        ItemStack tech22 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech22Meta = tech22.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,22);
        if (t == 0){
            tech22Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&bЗавод &e"+tech22Cost+"&fૹ"));
            tech22Meta.setLore(List.of(
                    ChatColor.DARK_AQUA +"Позволяет строить Заводы."));
            tech22.setItemMeta(tech22Meta);
        }else {
            tech22Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&dЗавод"));
            tech22Meta.setLore(List.of(
                    ChatColor.YELLOW + "Должны быть исследованы мануфактуры и порох",
                    ChatColor.DARK_GREEN +"Позволяет строить Заводы."));
            tech22Meta.addEnchant(Enchantment.INFINITY,1,true);
            tech22.setItemMeta(tech22Meta);
        }

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.DARK_GREEN + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(0, tech15);

        inventory.setItem(1, tech20);

        inventory.setItem(9, tech14);

        inventory.setItem(10, tech19);

        inventory.setItem(12, tech16);
        inventory.setItem(13, tech17);
        inventory.setItem(14, tech18);

        inventory.setItem(16, tech21);
        inventory.setItem(17, tech22);

        inventory.setItem(8, next);

    }
}
