package earthrp.menusystem.menu.tech;

import earthrp.Earth;
import earthrp.EarthPlayer;
import earthrp.files.CustomConfig;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.TechnologyMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class SocTechMenu extends Menu {
    private final Earth earthPlugin;
    public SocTechMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        player = this.earthPlugin.getServerDatabase().getPlayer(uuid);
        cost_mod = 1;
        this.tech6Cost = (int) Math.floor(tech6Cost * cost_mod);
        this.tech7Cost = (int) Math.floor(tech7Cost * cost_mod);
        this.tech8Cost = (int) Math.floor(tech8Cost * cost_mod);
        this.tech9Cost = (int) Math.floor(tech9Cost * cost_mod);
        this.tech10Cost = (int) Math.floor(tech10Cost * cost_mod);
        this.tech11Cost = (int) Math.floor(tech11Cost * cost_mod);
        this.tech12Cost = (int) Math.floor(tech12Cost * cost_mod);
        this.tech13Cost = (int) Math.floor(tech13Cost * cost_mod);
    }
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = p.getUniqueId();
    EarthPlayer player;
    double cost_mod;
    int tech6Cost = CustomConfig.get().getInt("tech.cost.tech6");
    String tech6Name = CustomConfig.get().getString("tech.name.tech6");

    int tech7Cost = CustomConfig.get().getInt("tech.cost.tech7");
    String tech7Name = CustomConfig.get().getString("tech.name.tech7");

    int tech8Cost = CustomConfig.get().getInt("tech.cost.tech8");
    String tech8Name = CustomConfig.get().getString("tech.name.tech8");

    int tech9Cost = CustomConfig.get().getInt("tech.cost.tech9");
    String tech9Name = CustomConfig.get().getString("tech.name.tech9");

    int tech10Cost = CustomConfig.get().getInt("tech.cost.tech10");
    String tech10Name = CustomConfig.get().getString("tech.name.tech10");

    int tech11Cost = CustomConfig.get().getInt("tech.cost.tech11");
    String tech11Name = CustomConfig.get().getString("tech.name.tech11");

    int tech12Cost = CustomConfig.get().getInt("tech.cost.tech12");
    String tech12Name = CustomConfig.get().getString("tech.name.tech12");

    int tech13Cost = CustomConfig.get().getInt("tech.cost.tech13");
    String tech13Name = CustomConfig.get().getString("tech.name.tech13");

    @Override
    public String getMenuName() {
        return "Социальные технологии";
    }

    @Override
    public int getSlots() {
        return 18;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        int oi_balance = player.getOiBalance();
        if (e.getCurrentItem().getItemMeta().getDisplayName().contains("ૹ")){
            int t7 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,7);
            int t8 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,8);
            int t9 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,9);
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Дипломатия") && oi_balance >= tech6Cost){
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"6");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech6Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Базовая") && oi_balance >= tech7Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"7");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech7Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Развитая") && oi_balance >= tech8Cost && t7 != 0) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"8");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech8Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Школы") && oi_balance >= tech9Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"9");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech9Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Университеты") && oi_balance >= tech10Cost && t9 != 0) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"10");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech10Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Министерства") && oi_balance >= tech11Cost) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"11");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech11Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Многосторонние") && oi_balance >= tech12Cost && t7 != 0) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"12");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech12Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Административная") && oi_balance >= tech13Cost && t8 != 0) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,1,"13");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance-tech13Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }else{
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Дипломатия")){
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"6");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech6Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Базовая")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"7");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech7Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Развитая")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"8");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech8Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Школы")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"9");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech9Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Университеты")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"10");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech10Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Министерства")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"11");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech11Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Многосторонние")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"12");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech12Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Административная")) {
                this.earthPlugin.getServerDatabase().updatePlayerTech(uuid,0,"13");
                this.earthPlugin.getServerDatabase().updatePlayerOiBalance(uuid,oi_balance+tech13Cost);
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();
            }
        }
        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new TechnologyMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {

        // Tech 6 - Дипломатия
        ItemStack tech6 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech6Meta = tech6.getItemMeta();
        int t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 6);
        if (t == 0) {
            tech6Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech6Name + " &b" + tech6Cost + "&fૹ"));
            tech6Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет совершать дипломатические действия с другими государствами")
            ));
            tech6.setItemMeta(tech6Meta);
        } else {
            tech6Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech6Name));
            tech6Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет совершать дипломатические действия с другими государствами")
            ));
            tech6Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech6.setItemMeta(tech6Meta);
        }

// Tech 7 - Базовая канцелярия
        ItemStack tech7 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech7Meta = tech7.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 7);
        if (t == 0) {
            tech7Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech7Name + " &b" + tech7Cost + "&fૹ"));
            tech7Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bдипломатия"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет издавать базовые указы стоимостью до 10 полит. власти")
            ));
            tech7.setItemMeta(tech7Meta);
        } else {
            tech7Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech7Name));
            tech7Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет издавать базовые указы стоимостью до 10 полит. власти")
            ));
            tech7Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech7.setItemMeta(tech7Meta);
        }

// Tech 8 - Развитая Бюрократия
        ItemStack tech8 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech8Meta = tech8.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 8);
        if (t == 0) {
            tech8Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech8Name + " &b" + tech8Cost + "&fૹ"));
            tech8Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bбазовая канцелярия"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет издавать сложные законы"),
                    ChatColor.translateAlternateColorCodes('&', "&7или указы, влияющие на ветви власти в стране"),
                    ChatColor.translateAlternateColorCodes('&', "&7без ограничения по политической власти")
            ));
            tech8.setItemMeta(tech8Meta);
        } else {
            tech8Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech8Name));
            tech8Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет издавать сложные законы"),
                    ChatColor.translateAlternateColorCodes('&', "&7или указы, влияющие на ветви власти в стране"),
                    ChatColor.translateAlternateColorCodes('&', "&7без ограничения по политической власти")
            ));
            tech8Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech8.setItemMeta(tech8Meta);
        }

// Tech 9 - Школы
        ItemStack tech9 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech9Meta = tech9.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 9);
        if (t == 0) {
            tech9Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech9Name + " &b" + tech9Cost + "&fૹ"));
            tech9Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить школы"),
                    ChatColor.translateAlternateColorCodes('&', "&aТакже получаете 1 идею")
            ));
            tech9.setItemMeta(tech9Meta);
        } else {
            tech9Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech9Name));
            tech9Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить школы")
            ));
            tech9Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech9.setItemMeta(tech9Meta);
        }

// Tech 10 - Университеты
        ItemStack tech10 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech10Meta = tech10.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 10);
        if (t == 0) {
            tech10Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech10Name + " &b" + tech10Cost + "&fૹ"));
            tech10Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bшкола"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить университеты"),
                    ChatColor.translateAlternateColorCodes('&', "&aТакже получаете 2 идеи")
            ));
            tech10.setItemMeta(tech10Meta);
        } else {
            tech10Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech10Name));
            tech10Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить университеты")
            ));
            tech10Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech10.setItemMeta(tech10Meta);
        }

// Tech 11 - Министерства
        ItemStack tech11 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech11Meta = tech11.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 11);
        if (t == 0) {
            tech11Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech11Name + " &b" + tech11Cost + "&fૹ"));
            tech11Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить министерства")
            ));
            tech11.setItemMeta(tech11Meta);
        } else {
            tech11Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech11Name));
            tech11Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет строить министерства")
            ));
            tech11Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech11.setItemMeta(tech11Meta);
        }

// Tech 12 - Многосторонние союзы
        ItemStack tech12 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech12Meta = tech12.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 12);
        if (t == 0) {
            tech12Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech12Name + " &b" + tech12Cost + "&fૹ"));
            tech12Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bбазовая канцелярия"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет заключать военные союзы"),
                    ChatColor.translateAlternateColorCodes('&', "&7в которых будет больше 2 стран")
            ));
            tech12.setItemMeta(tech12Meta);
        } else {
            tech12Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech12Name));
            tech12Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Позволяет заключать военные союзы"),
                    ChatColor.translateAlternateColorCodes('&', "&7в которых будет больше 2 стран")
            ));
            tech12Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech12.setItemMeta(tech12Meta);
        }

// Tech 13 - Административная эффективность
        ItemStack tech13 = new ItemStack(Material.PRISMARINE_CRYSTALS, 1);
        ItemMeta tech13Meta = tech13.getItemMeta();
        t = this.earthPlugin.getServerDatabase().getPlayerTech(uuid, 13);
        if (t == 0) {
            tech13Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech13Name + " &b" + tech13Cost + "&fૹ"));
            tech13Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&eДолжна быть исследована &bразвитая бюрократия"),
                    ChatColor.translateAlternateColorCodes('&', "&7Увеличивает административную эффективность на 4")
            ));
            tech13.setItemMeta(tech13Meta);
        } else {
            tech13Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&f" + tech13Name));
            tech13Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&2Уже исследовано"),
                    ChatColor.translateAlternateColorCodes('&', "&7Увеличивает административную эффективность на 4")
            ));
            tech13Meta.addEnchant(Enchantment.INFINITY, 1, true);
            tech13.setItemMeta(tech13Meta);
        }


        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.DARK_GREEN + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(9, tech6);

        inventory.setItem(11, tech7);

        inventory.setItem(12, tech8);

        inventory.setItem(14, tech9);

        inventory.setItem(15, tech10);

        inventory.setItem(3, tech11);

        inventory.setItem(4, tech12);

        inventory.setItem(5, tech13);

        inventory.setItem(17, next);

    }
}
