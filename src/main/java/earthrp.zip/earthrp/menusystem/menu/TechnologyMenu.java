package earthrp.menusystem.menu;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.tech.*;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;

public class TechnologyMenu extends Menu {
    private final Earth earthPlugin;
    public TechnologyMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
    }

    @Override
    public String getMenuName() {
        return "Технологии";
    }

    @Override
    public int getSlots() {
        return 9;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new EcoTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BONE_MEAL -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new ReusTechMenu(Earth.getPlayerMenuUtility(p),this.earthPlugin).open();

            }
            case BOOK -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new SocTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case CRAFTING_TABLE -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new CraftTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case FIRE_CHARGE -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new WarTechMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new MainMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() {

        ItemStack economy = new ItemStack(Material.GOLD_INGOT, 1);
        ItemMeta economyMeta = economy.getItemMeta();
        economyMeta.setDisplayName(ChatColor.YELLOW + "Экономические");
        economy.setItemMeta(economyMeta);

        ItemStack reusable = new ItemStack(Material.BONE_MEAL, 1);
        ItemMeta reusableMeta = reusable.getItemMeta();
        reusableMeta.setDisplayName(ChatColor.GREEN + "Многоразовые");
        reusable.setItemMeta(reusableMeta);

        ItemStack social = new ItemStack(Material.BOOK, 1);
        ItemMeta socialMeta = social.getItemMeta();
        socialMeta.setDisplayName(ChatColor.BLUE + "Социальные");
        social.setItemMeta(socialMeta);

        ItemStack craft = new ItemStack(Material.CRAFTING_TABLE, 1);
        ItemMeta craftMeta = craft.getItemMeta();
        craftMeta.setDisplayName(ChatColor.LIGHT_PURPLE + "Ремесленные");
        craft.setItemMeta(craftMeta);

        ItemStack war = new ItemStack(Material.FIRE_CHARGE, 1);
        ItemMeta warMeta = war.getItemMeta();
        warMeta.setDisplayName(ChatColor.DARK_RED + "Военные");
        war.setItemMeta(warMeta);

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.RED + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(2, economy);

        inventory.setItem(3, reusable);

        inventory.setItem(4, social);

        inventory.setItem(5, craft);

        inventory.setItem(6, war);
//
//        inventory.setItem(6, tech7);
//
//        inventory.setItem(7, tech8);

        inventory.setItem(8, next);

    }
}
