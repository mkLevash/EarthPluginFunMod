package earthrp.menusystem.menu.buildings;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.BuildingsMenu;
import earthrp.menusystem.menu.MainMenu;
import earthrp.menusystem.menu.tech.EcoTechMenu;
import earthrp.menusystem.menu.tech.ReusTechMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class StandartBuildingsMenu extends Menu {
    private final Earth earthPlugin;
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = this.playerMenuUtility.getOwner().getUniqueId();
    double costMod;
    int pastureCost;
    int tPasture;
    int farmCost;
    int tFarm;
    int lumberCost;
    int tLumber;
    int careerCost;
    int tCareer;
    int mineV2Cost;
    int tMineV2;
    int mineV1Cost;
    int tMineV1;
    int factoryCost;
    int tFactory;
    int plantCost;
    int tPlant;
    int universityCost;
    int tUniversity;
    int schoolCost;
    int tSchool;
    int diplomacyCost;
    int tDiplomacy;
    int bankCost;
    int tBank;
    int marketCost;
    int tMarket;
    public StandartBuildingsMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        this.costMod = 1;
        this.pastureCost = (int) Math.ceil(48 * costMod);
        this.tPasture = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,14);
        this.farmCost = (int) Math.ceil(48 * costMod);
        this.tFarm = 1;
        this.lumberCost = (int) Math.ceil(64 * costMod);
        this.tLumber = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,15);
        this.careerCost = (int) Math.ceil(96 * costMod);
        this.tCareer = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,18);
        this.mineV2Cost = (int) Math.ceil(80 * costMod);
        this.tMineV2 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,17);
        this.mineV1Cost = (int) Math.ceil(64 * costMod);
        this.tMineV1 = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,16);
        this.factoryCost = (int) Math.ceil(320 * costMod);
        this.tFactory = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,22);
        this.plantCost = (int) Math.ceil(160 * costMod);
        this.tPlant = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,21);
        this.universityCost = (int) Math.ceil(240 * costMod);
        this.tUniversity = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,10);
        this.schoolCost = (int) Math.ceil(64 * costMod);
        this.tSchool = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,9);
        this.diplomacyCost = (int) Math.ceil(32 * costMod);
        this.tDiplomacy = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,6);
        this.bankCost = (int) Math.ceil(128 * costMod);
        this.tBank = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,1);
        this.marketCost = (int) Math.ceil(64 * costMod);
        this.tMarket = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,3);

    }


    @Override
    public String getMenuName() {
        return "Строения";
    }

    @Override
    public int getSlots() {
        return 36;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {


        int treasury = this.earthPlugin.getServerDatabase().getPlayer(uuid).getTreasury();
        switch (e.getCurrentItem().getType()){

            case LEATHER -> {
                if (tPasture!=0){
                    if (treasury>=pastureCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.BEEF, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Пастбище");
                        buildingMeta.setLore(List.of("building",buildingId,"pasture"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,pastureCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case WHEAT -> {
                if (tFarm!=0){
                    if (treasury>=farmCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.WHEAT, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Плантация");
                        buildingMeta.setLore(List.of("building",buildingId,"farm"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,farmCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case OAK_LOG -> {
                if (tLumber!=0){
                    if (treasury>=lumberCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.OAK_LOG, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Лесопилка");
                        buildingMeta.setLore(List.of("building",buildingId,"lumber"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,lumberCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case DIAMOND_PICKAXE -> {
                if (tCareer!=0){
                    if (treasury>=careerCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.DIAMOND_PICKAXE, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Карьер");
                        buildingMeta.setLore(List.of("building",buildingId,"career"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,careerCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case IRON_PICKAXE -> {
                if (tMineV2!=0){
                    if (treasury>=mineV2Cost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.IRON_PICKAXE, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Рудник");
                        buildingMeta.setLore(List.of("building",buildingId,"mineV2"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,mineV2Cost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case STONE_PICKAXE -> {
                if (tMineV1!=0){
                    if (treasury>=mineV1Cost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.STONE_PICKAXE, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Шахта");
                        buildingMeta.setLore(List.of("building",buildingId,"mineV1"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,mineV1Cost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case SMITHING_TABLE -> {
                if (tFactory!=0){
                    if (treasury>=factoryCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.SMITHING_TABLE, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Завод");
                        buildingMeta.setLore(List.of("building",buildingId,"factory"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,factoryCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case CRAFTING_TABLE -> {
                if (tPlant!=0){
                    if (treasury>=plantCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.CRAFTING_TABLE, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Мануфактура");
                        buildingMeta.setLore(List.of("building",buildingId,"plant"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,plantCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case ENCHANTED_BOOK -> {
                if (tUniversity!=0){
                    if (treasury>=universityCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.ENCHANTED_BOOK, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Университет");
                        buildingMeta.setLore(List.of("building",buildingId,"university"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,universityCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case BOOK -> {
                if (tSchool!=0){
                    if (treasury>=schoolCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.BOOK, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Школа");
                        buildingMeta.setLore(List.of("building",buildingId,"school"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,schoolCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case PAPER -> {
                if (tDiplomacy!=0){
                    if (treasury>=diplomacyCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.PAPER, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Посольство");
                        buildingMeta.setLore(List.of("building",buildingId,"diplomacy"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,diplomacyCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case ENDER_CHEST -> {
                if (tBank!=0){
                    if (treasury>=bankCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.ENDER_CHEST, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Банк");
                        buildingMeta.setLore(List.of("building",buildingId,"bank"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,bankCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case BELL -> {
                if (tMarket!=0){
                    if (treasury>=marketCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.BELL, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Рынок");
                        buildingMeta.setLore(List.of("market",buildingId,"None"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,marketCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case VILLAGER_SPAWN_EGG -> {
                e.getWhoClicked().closeInventory();
                new ReusTechMenu(Earth.getPlayerMenuUtility(p),this.earthPlugin).open();

            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();
                new BuildingsMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() {

        ItemStack pasture = new ItemStack(Material.LEATHER, 1);
        ItemMeta pastureMeta = pasture.getItemMeta();
        pastureMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fПастбище &6"+pastureCost+"&f$"));
        if (tPasture == 0){
            pastureMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет разводить скот.")
            ));
        }else{
            pastureMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(32*costMod)+"&dx&fБревно, &6"+(int) Math.ceil(12*costMod)+"&dx&fСноп сена"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет разводить скот.")
            ));
        }
        pastureMeta.addEnchant(Enchantment.INFINITY,1,true);
        pasture.setItemMeta(pastureMeta);

        ItemStack farm = new ItemStack(Material.WHEAT, 1);
        ItemMeta farmMeta = farm.getItemMeta();
        farmMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fПлантация &6"+farmCost+"&f$"));
        if (tFarm == 0){
            farmMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет выращивать культуры на грядках.")
            ));
        }else{
            farmMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(16*costMod)+"&dx&fБревно; &6"+(int) Math.ceil(32*costMod)+"&dx&fБлок земли; &6"+(int) Math.ceil(6*costMod)+"&dx&fВедро с водой"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет выращивать культуры на грядках.")
            ));
        }
        farmMeta.addEnchant(Enchantment.INFINITY,1,true);
        farm.setItemMeta(farmMeta);

        ItemStack lumber = new ItemStack(Material.OAK_LOG, 1);
        ItemMeta lumberMeta = lumber.getItemMeta();
        lumberMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fЛесопилка &6"+lumberCost+"&f$"));
        if (tLumber == 0){
            lumberMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a1&f древесину/кору.")
            ));
        }else{
            lumberMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fБревно; &6"+(int) Math.ceil(1*costMod)+"&dx&fЖелезный блок,Камнерез &6"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a1&f древесину/кору.")
            ));
        }
        lumberMeta.addEnchant(Enchantment.INFINITY,1,true);
        lumber.setItemMeta(lumberMeta);

        ItemStack career = new ItemStack(Material.DIAMOND_PICKAXE, 1);
        ItemMeta careerMeta = career.getItemMeta();
        careerMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fКарьер &6"+careerCost+"&f$"));
        if (tCareer == 0){
            careerMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать алмазы/кристаллы. "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a3")
            ));
        }else{
            careerMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fКаменный кирпич; &6"+(int) Math.ceil(64*costMod)+"&dx&fБревно,Фонарь; &6"+(int) Math.ceil(16*costMod)+"&dx&fПорох"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(2*costMod)+"&dx&fАлмазный блок; &6"+(int) Math.ceil(6*costMod)+"&dx&fЖелезный блок;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(5*costMod)+"&dx&fКамнерез,Точило; &6"+(int) Math.ceil(3*costMod)+"&dx&fНаковальня;"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать алмазы/кристаллы. "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a3")
            ));
        }
        careerMeta.addEnchant(Enchantment.INFINITY,1,true);
        career.setItemMeta(careerMeta);

        ItemStack mineV2 = new ItemStack(Material.IRON_PICKAXE, 1);
        ItemMeta mineV2Meta = mineV2.getItemMeta();
        mineV2Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fРудник &6"+mineV2Cost+"&f$"));
        if (tMineV2 == 0){
            mineV2Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать золото,"),
                    ChatColor.translateAlternateColorCodes('&',"&fобработанные каменные блоки,"),
                    ChatColor.translateAlternateColorCodes('&',"&fобработанное железо."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a2"),
                    ChatColor.translateAlternateColorCodes('&',"&fЕдиница золота = &610&f$")
            ));
        }else{
            mineV2Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fБулыжник; &6"+(int) Math.ceil(32*costMod)+"&dx&fБревно, Фонарь;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(4*costMod)+"&dx&fЖелезный блок; &6"+(int) Math.ceil(3*costMod)+"&dx&fКамнерез, Плавильня"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать: золото,"),
                    ChatColor.translateAlternateColorCodes('&',"&fобработанные каменные блоки,"),
                    ChatColor.translateAlternateColorCodes('&',"&fобработанное железо."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a2"),
                    ChatColor.translateAlternateColorCodes('&',"&fЕдиница золота = &610&f$")
            ));
        }
        mineV2Meta.addEnchant(Enchantment.INFINITY,1,true);
        mineV2.setItemMeta(mineV2Meta);

        ItemStack mineV1 = new ItemStack(Material.STONE_PICKAXE, 1);
        ItemMeta mineV1Meta = mineV1.getItemMeta();
        mineV1Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fШахта &6"+mineV1Cost+"&f$"));
        if (tMineV1 == 0){
            mineV1Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать: уголь,"),
                    ChatColor.translateAlternateColorCodes('&',"&fнеобработанные каменные блоки,"),
                    ChatColor.translateAlternateColorCodes('&',"&fнеобработанное железо."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a1")
            ));
        }else{
            mineV1Meta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fБулыжник, &6"+(int) Math.ceil(32*costMod)+"&dx&fБревно,Факел"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(2*costMod)+"&dx&fКамнерез,Железный блок;"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет добывать: уголь,"),
                    ChatColor.translateAlternateColorCodes('&',"&fнеобработанные каменные блоки,"),
                    ChatColor.translateAlternateColorCodes('&',"&fнеобработанное железо."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводительность &a1")
            ));
        }
        mineV1Meta.addEnchant(Enchantment.INFINITY,1,true);
        mineV1.setItemMeta(mineV1Meta);

        ItemStack factory = new ItemStack(Material.SMITHING_TABLE, 1);
        ItemMeta factoryMeta = factory.getItemMeta();
        factoryMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fЗавод &6"+factoryCost+"&f$"));
        if (tFactory == 0){
            factoryMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a3&f ресурса, которые"),
                    ChatColor.translateAlternateColorCodes('&',"&fуже производятся или &a2 &dпороха &f "),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет перерабатывать сырые"),
                    ChatColor.translateAlternateColorCodes('&',"&fресурсы в готовые изделия")

            ));
        }else{
            factoryMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fКирпичный блок,Бревно; &6"+(int) Math.ceil(64*costMod)+"&dx&fФонарь,Порох;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(3*costMod)+"&dx&fСтол кузнеца,Наковальня,Плавильня;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(5*costMod)+"&dx&fАлмазный блок,Железный блок,Угольный блок"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a3&f ресурса, которые"),
                    ChatColor.translateAlternateColorCodes('&',"&fуже производятся или &a2 &dпороха &f"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет перерабатывать сырые"),
                    ChatColor.translateAlternateColorCodes('&',"&fресурсы в готовые изделия")
            ));
        }
        factoryMeta.addEnchant(Enchantment.INFINITY,1,true);
        factory.setItemMeta(factoryMeta);

        ItemStack plant = new ItemStack(Material.CRAFTING_TABLE, 1);
        ItemMeta plantMeta = plant.getItemMeta();
        plantMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fМануфактура &6"+plantCost+"&f$"));
        if (tPlant == 0){
            plantMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a2&f ресурса, которые"),
                    ChatColor.translateAlternateColorCodes('&',"&fуже производятся или &a1 &dпорох"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет перерабатывать сырые"),
                    ChatColor.translateAlternateColorCodes('&',"&fресурсы в готовые изделия")
            ));
        }else{
            plantMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fКаменный кирпич; &6"+(int) Math.ceil(32*costMod)+"&dx&fБревно,Фонарь;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(6*costMod)+"&dx&fВерстак,Камнерез,Точило;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(3*costMod)+"&dx&fЖелезный блок,Угольный блок"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &a2&f ресурса, которые"),
                    ChatColor.translateAlternateColorCodes('&',"&fуже производятся или &a1 &dпорох"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожет перерабатывать сырые"),
                    ChatColor.translateAlternateColorCodes('&',"&fресурсы в готовые изделия")
            ));
        }
        plantMeta.addEnchant(Enchantment.INFINITY,1,true);
        plant.setItemMeta(plantMeta);

        ItemStack university = new ItemStack(Material.ENCHANTED_BOOK, 1);
        ItemMeta universityMeta = university.getItemMeta();
        universityMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fУниверситет &6"+universityCost+"&f$"));
        if (tUniversity == 0){
            universityMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает прирост ОИ на &a3."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит книги. "),
                    ChatColor.translateAlternateColorCodes('&',"&fПотребляет бумагу"),
                    ChatColor.translateAlternateColorCodes('&',"&eМожно построить только одну в городе")
            ));
        }else{
            universityMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(64*costMod)+"&dx&fКнижная полка,Стекло; &6"+(int) Math.ceil(32*costMod)+"&dx&fБревно,Фонарь"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(5*costMod)+"&dx&fКафедра,Большой сундук;"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает прирост ОИ на &a3."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит книги."),
                    ChatColor.translateAlternateColorCodes('&',"&fПотребляет бумагу"),
                    ChatColor.translateAlternateColorCodes('&',"&eМожно построить только одну в городе")
            ));
        }
        universityMeta.addEnchant(Enchantment.INFINITY,1,true);
        university.setItemMeta(universityMeta);

        ItemStack school = new ItemStack(Material.BOOK, 1);
        ItemMeta schoolMeta = school.getItemMeta();
        schoolMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fШкола &6"+schoolCost+"&f$"));
        if (tSchool == 0){
            schoolMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает прирост ОИ на &a1."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит бумагу"),
                    ChatColor.translateAlternateColorCodes('&',"&eМожно построить только одну в городе")
            ));
        }else{
            schoolMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(8*costMod)+"&dx&fКнижная полка,Сундук; &6"+(int) Math.ceil(1*costMod)+"&dx&fКафедра;"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(16*costMod)+"&dx&fБревно,Факел,Стекло"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает прирост ОИ на &a1."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит бумагу"),
                    ChatColor.translateAlternateColorCodes('&',"&eМожно построить только одну в городе")
            ));
        }
        schoolMeta.addEnchant(Enchantment.INFINITY,1,true);
        school.setItemMeta(schoolMeta);

        ItemStack diplomacy = new ItemStack(Material.PAPER, 1);
        ItemMeta diplomacyMeta = diplomacy.getItemMeta();
        diplomacyMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fПосольство &6"+diplomacyCost+"&f$"));
        if (tDiplomacy == 0){
            diplomacyMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&f+1 к торговым отношениям и мнению "),
                    ChatColor.translateAlternateColorCodes('&',"&fсо страной, где построено посольство."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fВ посольство можно телепортироваться"),
                    ChatColor.translateAlternateColorCodes('&',"&fиз своей столицы"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно строить только в столицах")
            ));
        }else{
            diplomacyMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&',"&f+1 к торговым отношениям и мнению "),
                    ChatColor.translateAlternateColorCodes('&',"&fсо страной, где построено посольство."),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fВ посольство можно телепортироваться"),
                    ChatColor.translateAlternateColorCodes('&',"&fиз своей столицы"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно строить только в столицах")
            ));
        }
        diplomacyMeta.addEnchant(Enchantment.INFINITY,1,true);
        diplomacy.setItemMeta(diplomacyMeta);

        ItemStack bank = new ItemStack(Material.ENDER_CHEST, 1);
        ItemMeta bankMeta = bank.getItemMeta();
        bankMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fБанк &6"+bankCost+"&f$"));
        if (tBank == 0){
            bankMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроцентная ставка - 10%"),
                    ChatColor.translateAlternateColorCodes('&',"&fЕдиничный долг - 10$.")
            ));
        }else{
            bankMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(8*costMod)+"&dx&fБольшой сундук; &6"+(int) Math.ceil(32*costMod)+"&dx&fБумага"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(16*costMod)+"&dx&fСтекло,Бревно"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПроцентная ставка - 10%"),
                    ChatColor.translateAlternateColorCodes('&',"&fЕдиничный долг - 10$.")
            ));
        }
        bankMeta.addEnchant(Enchantment.INFINITY,1,true);
        bank.setItemMeta(bankMeta);

        ItemStack market = new ItemStack(Material.BELL, 1);
        ItemMeta marketMeta = market.getItemMeta();
        marketMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fРынок &6"+marketCost+"&f$"));
        if (tMarket == 0){
            marketMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fДает возможность продавать товары")
            ));
        }else{
            marketMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(18*costMod)+"&dx&fЗолото,Сундук; &6"+(int) Math.ceil(16*costMod)+"&dx&fПеро,Бревно"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fДает возможность продавать товары")
            ));
        }
        marketMeta.addEnchant(Enchantment.INFINITY,1,true);
        market.setItemMeta(marketMeta);


        ItemStack back = new ItemStack(Material.BARRIER, 1);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName(ChatColor.RED + "BACK");
        back.setItemMeta(backMeta);

        inventory.setItem(0, lumber);
        inventory.setItem(9, pasture);
        inventory.setItem(18, farm);

        inventory.setItem(2, career);
        inventory.setItem(11, mineV2);
        inventory.setItem(20, mineV1);

        inventory.setItem(4, factory);
        inventory.setItem(13, plant);

        inventory.setItem(6, university);
        inventory.setItem(15, school);

        inventory.setItem(8, diplomacy);
        inventory.setItem(17, bank);
        inventory.setItem(26, market);

        inventory.setItem(35, back);

    }
}
