package earthrp.menusystem.menu.buildings;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.BuildingsMenu;
import earthrp.menusystem.menu.MainMenu;
import earthrp.menusystem.menu.tech.EcoTechMenu;
import earthrp.menusystem.menu.tech.ReusTechMenu;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class WarBuildingsMenu extends Menu {
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = p.getUniqueId();
    private final Earth earthPlugin;
    double costMod;
    int tBarack;
    int tStable;
    int tGunFactory;
    int tFort;
    int tForge;
    int tShipyard;
    int barrackCost;
    int stableCost;
    int gunFactoryCost;
    int fortCost;
    int forgeCost;
    int shipyardCost;


    public WarBuildingsMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        this.costMod = 1;
        this.barrackCost = (int) Math.ceil(128*costMod);
        this.tBarack = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,31);
        this.stableCost = (int) Math.ceil(160*costMod);
        this.tStable = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,34);
        this.gunFactoryCost = (int) Math.ceil(256*costMod);
        this.tGunFactory = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,38);
        this.fortCost = (int) Math.ceil(48*costMod);
        this.tFort = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,24);
        this.forgeCost = (int) Math.ceil(64*costMod);
        this.tForge = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,19);
        this.shipyardCost = (int) Math.ceil(32*costMod);
        this.tShipyard = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,20);

    }




    @Override
    public String getMenuName() {
        return "Военные";
    }

    @Override
    public int getSlots() {
        return 18;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        int treasury = this.earthPlugin.getServerDatabase().getPlayer(p.getUniqueId()).getTreasury();
        switch (e.getCurrentItem().getType()){

            case SKELETON_SPAWN_EGG -> {
                if (tBarack!=0){
                    if (treasury>=barrackCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.SKELETON_SPAWN_EGG, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Казарма");
                        buildingMeta.setLore(List.of("building",buildingId,"barrack"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,barrackCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case PIG_SPAWN_EGG -> {
                if (tStable!=0){
                    if (treasury>=stableCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.PIG_SPAWN_EGG, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Конюшня");
                        buildingMeta.setLore(List.of("building",buildingId,"stable"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,stableCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case GUARDIAN_SPAWN_EGG -> {
                if (tGunFactory!=0){
                    if (treasury>=gunFactoryCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.GUARDIAN_SPAWN_EGG, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Оружейная фабрика");
                        buildingMeta.setLore(List.of("building",buildingId,"gunFactory"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,gunFactoryCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case STONE_BRICKS -> {
                if (tFort!=0){
                    if (treasury>=fortCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.STONE_BRICKS, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Крепость");
                        buildingMeta.setLore(List.of("building",buildingId,"fort"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,fortCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case ANVIL -> {
                if (tForge!=0){
                    if (treasury>=forgeCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.ANVIL, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Кузница");
                        buildingMeta.setLore(List.of("building",buildingId,"forge"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,forgeCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case FOX_SPAWN_EGG -> {
                if (tShipyard!=0){
                    if (treasury>=shipyardCost){
                        e.getWhoClicked().closeInventory();
                        String buildingId = String.valueOf(UUID.randomUUID());
                        ItemStack building = new ItemStack(Material.FOX_SPAWN_EGG, 1);
                        ItemMeta buildingMeta = building.getItemMeta();
                        buildingMeta.setDisplayName("Верфь");
                        buildingMeta.setLore(List.of("building",buildingId,"shipyard"));
                        buildingMeta.addEnchant(Enchantment.INFINITY,1,true);
                        building.setItemMeta(buildingMeta);
                        this.earthPlugin.buyBuilding(uuid,shipyardCost);
                        p.getInventory().addItem(building);
                    }
                }
            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();
                new BuildingsMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() {


        ItemStack barrack = new ItemStack(Material.SKELETON_SPAWN_EGG, 1);
        ItemMeta barrackMeta = barrack.getItemMeta();
        barrackMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fКазарма &6"+barrackCost+"&f$"));
        if (tBarack == 0){
            barrackMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Пехоту 2+ уровня.")
            ));
        }else{
            barrackMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(64*costMod)+"&dx&fБревно,Стрел; &6"+(int) Math.ceil(16*costMod)+"&dx&fМишень,Перо"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&', "&a20 &fТрадиций для скидки"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Пехоту 2+ уровня.")
            ));
        }
        barrackMeta.addEnchant(Enchantment.INFINITY,1,true);
        barrack.setItemMeta(barrackMeta);

        ItemStack stable = new ItemStack(Material.PIG_SPAWN_EGG, 1);
        ItemMeta stableMeta = stable.getItemMeta();
        stableMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fКонюшня &6"+stableCost+"&f$"));
        if (tStable == 0){
            stableMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Кавалерию.")
            ));
        }else{
            stableMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(64*costMod)+"&dx&fБревно; &6"+(int) Math.ceil(32*costMod)+"&dx&fПеро,Кожа,Мишень"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&', "&a20 &fТрадиций для скидки"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Кавалерию.")
            ));
        }
        stableMeta.addEnchant(Enchantment.INFINITY,1,true);
        stable.setItemMeta(stableMeta);

        ItemStack gunFactory = new ItemStack(Material.GUARDIAN_SPAWN_EGG, 1);
        ItemMeta gunFactoryMeta = gunFactory.getItemMeta();
        gunFactoryMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fОружейная фабрика &6"+gunFactoryCost+"&f$"));
        if (tGunFactory == 0){
            gunFactoryMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Артиллерию.")
            ));
        }else{
            gunFactoryMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(256*costMod)+"&dx&fБревно; &6"+(int) Math.ceil(64*costMod)+"&dx&fПорох,Каменный Кирпич"),
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(6*costMod)+"&dx&fЖелезный блок,Алмазный блок"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&', "&a20 &fТрадиций для скидки"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fПозволяет создавать Артиллерию.")
            ));
        }
        gunFactoryMeta.addEnchant(Enchantment.INFINITY,1,true);
        gunFactory.setItemMeta(gunFactoryMeta);

        ItemStack forts = new ItemStack(Material.STONE_BRICKS, 1);
        ItemMeta fortsMeta = forts.getItemMeta();
        fortsMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fКрепость &6"+fortCost+"&f$"));
        if (tFort == 0){
            fortsMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fНе даёт противнику оккупировать город."),
                    ChatColor.translateAlternateColorCodes('&',"&fНужно будет провести &5осаду."),
                    ChatColor.translateAlternateColorCodes('&',"&fПредупреждает о врагах в области &5250."),
                    ChatColor.translateAlternateColorCodes('&',"&fНе занимает &6ячейку строительства&f")
            ));
        }else{
            fortsMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(128*costMod)+"&dx&fКаменный кирпич; &6"+(int) Math.ceil(64*costMod)+"&dx&fФакел"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fНе даёт противнику оккупировать город."),
                    ChatColor.translateAlternateColorCodes('&',"&fНужно будет провести &5осаду."),
                    ChatColor.translateAlternateColorCodes('&',"&fПредупреждает о врагах в области &5250."),
                    ChatColor.translateAlternateColorCodes('&',"&fНе занимает &6ячейку строительства&f")
            ));
        }
        fortsMeta.addEnchant(Enchantment.INFINITY,1,true);
        forts.setItemMeta(fortsMeta);

        ItemStack forge = new ItemStack(Material.ANVIL, 1);
        ItemMeta forgeMeta = forge.getItemMeta();
        forgeMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fКузница &6"+forgeCost+"&f$"));
        if (tForge == 0){
            forgeMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&a+5%&d к резисту&f в фазе&6 шока."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &dОружие&f,"),
                    ChatColor.translateAlternateColorCodes('&',"&fпотреблят &dОбработанное железо&f и&d уголь."),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно построить&6 только одну&f в городе.")
            ));
        }else{
            forgeMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(16*costMod)+"&dx&fБревно, &6"+(int) Math.ceil(6*costMod)+"&dx&fНаковальня,Ведро лавы"),
                    ChatColor.translateAlternateColorCodes('&',"&a+5%&d к резисту&f в фазе&6 шока."),
                    ChatColor.translateAlternateColorCodes('&',"&fПроизводит &dОружие&f,"),
                    ChatColor.translateAlternateColorCodes('&',"&fпотреблят &dОбработанное железо&f и&d уголь."),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно построить&6 только одну&f в городе.")
            ));
        }
        forgeMeta.addEnchant(Enchantment.INFINITY,1,true);
        forge.setItemMeta(forgeMeta);

        ItemStack shipyard = new ItemStack(Material.FOX_SPAWN_EGG, 1);
        ItemMeta shipyardMeta = shipyard.getItemMeta();
        shipyardMeta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&fВерфь &6"+shipyardCost+"&f$"));
        if (tShipyard == 0){
            shipyardMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&cНе изучено"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fОткрывает возможность строить корабли."),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает лимит флота на &a5"),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно построить&6 только одну&f в городе.")
            ));
        }else{
            shipyardMeta.setLore(List.of(
                    ChatColor.translateAlternateColorCodes('&', "&6"+(int) Math.ceil(32*costMod)+"&dx&fБревно, &6"+(int) Math.ceil(1*costMod)+"&dx&fЖелезный блок, &6"+(int) Math.ceil(12*costMod)+"&&dx&fБочка"),
                    (" "),
                    ChatColor.translateAlternateColorCodes('&',"&fОткрывает возможность строить корабли."),
                    ChatColor.translateAlternateColorCodes('&',"&fУвеличивает лимит флота на &a5"),
                    ChatColor.translateAlternateColorCodes('&',"&fМожно построить&6 только одну&f в городе.")
            ));
        }
        shipyardMeta.addEnchant(Enchantment.INFINITY,1,true);
        shipyard.setItemMeta(shipyardMeta);

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.RED + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(3, barrack);
        inventory.setItem(4, stable);
        inventory.setItem(5, gunFactory);

        inventory.setItem(12, forts);
        inventory.setItem(13, forge);
        inventory.setItem(14, shipyard);
//
//        inventory.setItem(6, tech7);
//
//        inventory.setItem(7, tech8);

        inventory.setItem(17, next);

    }
}
