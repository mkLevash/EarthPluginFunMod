package earthrp.menusystem.menu;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.ideas.*;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.Objects;

public class IdeasMenu extends Menu {
    private final Earth earthPlugin;
    public IdeasMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
    }
    Player p = this.playerMenuUtility.getOwner();

    @Override
    public String getMenuName() {
        return "Идеи";
    }

    @Override
    public int getSlots() {
        return 18;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {
        switch (Objects.requireNonNull(e.getCurrentItem()).getType()){

            case CYAN_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new DipIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case YELLOW_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new TradeIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case GREEN_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case ORANGE_SHULKER_BOX -> {

                e.getWhoClicked().closeInventory();
                new EcoIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BLACK_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new ImperialIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case WHITE_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new SeparateIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case LIGHT_BLUE_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new ScienceIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BROWN_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new RevanchismIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case LIME_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new ColonialIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case PINK_SHULKER_BOX -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new IsolationIdeaMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }
            case BARRIER -> {
                Player p = (Player) e.getWhoClicked();
                e.getWhoClicked().closeInventory();
                new MainMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() {

        ItemStack economy = new ItemStack(Material.ORANGE_SHULKER_BOX, 1);
        ItemMeta economyMeta = economy.getItemMeta();
        economyMeta.setDisplayName(ChatColor.GOLD + "Экономические");
        economy.setItemMeta(economyMeta);

        ItemStack admin = new ItemStack(Material.GREEN_SHULKER_BOX, 1);
        ItemMeta adminMeta = admin.getItemMeta();
        adminMeta.setDisplayName(ChatColor.DARK_GREEN + "Административные");
        admin.setItemMeta(adminMeta);

        ItemStack trade = new ItemStack(Material.YELLOW_SHULKER_BOX, 1);
        ItemMeta tradeMeta = trade.getItemMeta();
        tradeMeta.setDisplayName(ChatColor.YELLOW + "Торговые");
        trade.setItemMeta(tradeMeta);

        ItemStack dip = new ItemStack(Material.CYAN_SHULKER_BOX, 1);
        ItemMeta dipMeta = dip.getItemMeta();
        dipMeta.setDisplayName(ChatColor.DARK_AQUA + "Дипломатические");
        dip.setItemMeta(dipMeta);

        ItemStack war = new ItemStack(Material.BLACK_SHULKER_BOX, 1);
        ItemMeta warMeta = war.getItemMeta();
        warMeta.setDisplayName(ChatColor.DARK_GRAY + "Империалистические");
        war.setItemMeta(warMeta);

        ItemStack separate = new ItemStack(Material.WHITE_SHULKER_BOX, 1);
        ItemMeta separateMeta = separate.getItemMeta();
        separateMeta.setDisplayName(ChatColor.WHITE + "Освободительные");
        separate.setItemMeta(separateMeta);

        ItemStack science = new ItemStack(Material.LIGHT_BLUE_SHULKER_BOX, 1);
        ItemMeta scienceMeta = science.getItemMeta();
        scienceMeta.setDisplayName(ChatColor.AQUA + "Научные");
        science.setItemMeta(scienceMeta);

        ItemStack revanchism = new ItemStack(Material.BROWN_SHULKER_BOX, 1);
        ItemMeta revanchismMeta = revanchism.getItemMeta();
        revanchismMeta.setDisplayName(ChatColor.DARK_RED + "Реваншистсткие");
        revanchism.setItemMeta(revanchismMeta);

        ItemStack colonial = new ItemStack(Material.LIME_SHULKER_BOX, 1);
        ItemMeta colonialMeta = colonial.getItemMeta();
        colonialMeta.setDisplayName(ChatColor.GREEN + "Колонизационные");
        colonial.setItemMeta(colonialMeta);

        ItemStack isolation = new ItemStack(Material.PINK_SHULKER_BOX, 1);
        ItemMeta isolationMeta = isolation.getItemMeta();
        isolationMeta.setDisplayName(ChatColor.LIGHT_PURPLE + "Изоляционные");
        isolation.setItemMeta(isolationMeta);

        ItemStack next = new ItemStack(Material.BARRIER, 1);
        ItemMeta nextMeta = next.getItemMeta();
        nextMeta.setDisplayName(ChatColor.RED + "BACK");
        next.setItemMeta(nextMeta);


        inventory.setItem(2, economy);
        inventory.setItem(3, admin);
        inventory.setItem(4, trade);
        inventory.setItem(5, dip);
        inventory.setItem(6, war);

        inventory.setItem(11, separate);
        inventory.setItem(12, science);
        inventory.setItem(13, revanchism);
        inventory.setItem(14, colonial);
        inventory.setItem(15, isolation);
//
//        inventory.setItem(6, tech7);
//
//        inventory.setItem(7, tech8);

        inventory.setItem(17, next);

    }
}
