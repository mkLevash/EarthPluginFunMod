package earthrp.menusystem.menu.ideas;

import earthrp.Earth;
import earthrp.menusystem.Menu;
import earthrp.menusystem.PlayerMenuUtility;
import earthrp.menusystem.menu.IdeasMenu;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public class AdminIdeaMenu extends Menu {
    private final Earth earthPlugin;
    int ideas;
    double techMod;
    public AdminIdeaMenu(PlayerMenuUtility playerMenuUtility, Earth earthPlugin) throws SQLException {
        super(playerMenuUtility);
        this.earthPlugin = earthPlugin;
        ideas = this.earthPlugin.getServerDatabase().getPlayerTech(uuid,41);
        fullIdeas = (int) ( Math.floor((double) ideas / 5));
        techMod = 1;
        ideaCost = (int) ( Math.floor((fullIdeas*ideaIncMod + 10) * techMod));
    }
    Player p = this.playerMenuUtility.getOwner();
    UUID uuid = p.getUniqueId();
    int fullIdeas;
    int ideaIncMod = Earth.getInstance().getConfig().getInt("ideaIncMod");
    int ideaCost;

    String idea6Name = "Stable Government";
    String idea7Name = "Local Rule";
    String idea8Name = "Adaptability";
    String idea9Name = "Centralization";
    String idea10Name = "Cultural Regulations";



    @Override
    public String getMenuName() {return "Административные идеи";}

    @Override
    public int getSlots() {return 27;}

    @Override
    public void handleMenu(InventoryClickEvent e) throws SQLException {


        if(e.getCurrentItem().getItemMeta().getDisplayName().contains("ૹ")){
            int i6 = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,6);
            int i7 = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,7);
            int i8 = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,8);
            int i9 = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,9);
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea6Name)&& this.earthPlugin.investIdea(uuid,6,ideaCost)){
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if(e.getCurrentItem().getItemMeta().getDisplayName().contains(idea7Name)&& i6 != 0 && this.earthPlugin.investIdea(uuid,7,ideaCost)) {
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if(e.getCurrentItem().getItemMeta().getDisplayName().contains(idea8Name)&& i7 != 0 && this.earthPlugin.investIdea(uuid,8,ideaCost)) {
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if(e.getCurrentItem().getItemMeta().getDisplayName().contains(idea9Name)&& i8 != 0 && this.earthPlugin.investIdea(uuid,9,ideaCost)) {
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if(e.getCurrentItem().getItemMeta().getDisplayName().contains(idea10Name)&& i9 != 0 && this.earthPlugin.investIdea(uuid,10,ideaCost)) {
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }
        }else{
            if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea6Name)) {
                this.earthPlugin.backIdea(uuid, 6, ideaCost);
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            } else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea7Name)) {
                this.earthPlugin.backIdea(uuid, 7, ideaCost);
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea8Name)) {
                this.earthPlugin.backIdea(uuid, 8, ideaCost);
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea9Name)) {
                this.earthPlugin.backIdea(uuid, 9, ideaCost);
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }else if (e.getCurrentItem().getItemMeta().getDisplayName().contains(idea10Name)) {
                this.earthPlugin.backIdea(uuid, 10, ideaCost);
                e.getWhoClicked().closeInventory();
                new AdminIdeaMenu(playerMenuUtility, this.earthPlugin).open();
            }
        }

        switch (e.getCurrentItem().getType()){

            case GOLD_INGOT -> {
                e.getWhoClicked().closeInventory();
                e.getWhoClicked().sendMessage("Социальные");

            }
            case BARRIER -> {
                e.getWhoClicked().closeInventory();
                new IdeasMenu(playerMenuUtility, this.earthPlugin).open();

            }

        }

    }

    @Override
    public void setMenuItems() throws SQLException {

        ItemStack lantern = new ItemStack(Material.SOUL_LANTERN, 1);
        ItemMeta lanternMeta = lantern.getItemMeta();
        lanternMeta.setDisplayName("Идея");
        lanternMeta.addEnchant(Enchantment.INFINITY,1,true);
        lantern.setItemMeta(lanternMeta);
        
        
        
        int i = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,6);
        ItemStack idea6 = new ItemStack(Material.GREEN_CONCRETE_POWDER, 1);
        ItemMeta idea6Meta = idea6.getItemMeta();
        if (i==0){
            idea6Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea6Name +" &b"+ideaCost+"&fૹ"));

        }else {
            idea6Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea6Name));
            inventory.setItem(20, lantern);
        }
        idea6Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',"&fСтоимость стабильности &a-25%")));
        idea6.setItemMeta(idea6Meta);

        i = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,7);
        ItemStack idea7 = new ItemStack(Material.GREEN_CONCRETE_POWDER, 1);
        ItemMeta idea7Meta = idea7.getItemMeta();
        if (i==0){
            idea7Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea7Name +" &b"+ideaCost+"&fૹ"));

        }else {
            idea7Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea7Name));
            inventory.setItem(21, lantern);
        }
        idea7Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',"&fСтоимость жилого дома &a-1&f$")));
        idea7.setItemMeta(idea7Meta);

        i = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,8);
        ItemStack idea8 = new ItemStack(Material.GREEN_CONCRETE_POWDER, 1);
        ItemMeta idea8Meta = idea8.getItemMeta();
        if (i==0){
            idea8Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea8Name +" &b"+ideaCost+"&fૹ"));

        }else {
            idea8Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea8Name));
            inventory.setItem(22, lantern);
        }
        idea8Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',"&fСтоимость национализации &a-25%")));
        idea8.setItemMeta(idea8Meta);

        i = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,9);
        ItemStack idea9 = new ItemStack(Material.GREEN_CONCRETE_POWDER, 1);
        ItemMeta idea9Meta = idea9.getItemMeta();
        if (i==0){
            idea9Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea9Name +" &b"+ideaCost+"&fૹ"));

        }else {
            idea9Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea9Name));
            inventory.setItem(23, lantern);
        }
        idea9Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',"&fСтоимость повышения инфраструктуры &a-50%")));
        idea9.setItemMeta(idea9Meta);

        i = this.earthPlugin.getServerDatabase().getPlayerIdea(uuid,10);
        ItemStack idea10 = new ItemStack(Material.GREEN_CONCRETE_POWDER, 1);
        ItemMeta idea10Meta = idea10.getItemMeta();
        if (i==0){
            idea10Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea10Name +" &b"+ideaCost+"&fૹ"));

        }else {
            idea10Meta.setDisplayName(ChatColor.translateAlternateColorCodes('&',"&2"+ idea10Name));
            inventory.setItem(24, lantern);
        }
        idea10Meta.setLore(List.of(ChatColor.translateAlternateColorCodes('&',"&fКоличество зданий в городе &a+1")));
        idea10.setItemMeta(idea10Meta);

        ItemStack back = new ItemStack(Material.BARRIER, 1);
        ItemMeta backMeta = back.getItemMeta();
        backMeta.setDisplayName(ChatColor.RED + "BACK");
        back.setItemMeta(backMeta);

        
        


        inventory.setItem(11, idea6);
        inventory.setItem(12, idea7);
        inventory.setItem(13, idea8);
        inventory.setItem(14, idea9);
        inventory.setItem(15, idea10);

        inventory.setItem(26, back);

    }
}
