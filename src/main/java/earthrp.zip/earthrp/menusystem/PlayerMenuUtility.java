package earthrp.menusystem;

import earthrp.Building;
import earthrp.Market;
import earthrp.Pathfinding;
import earthrp.Town;
import org.bukkit.entity.Player;
import earthrp.Pathfinding.TownDistancePair;
import earthrp.Pathfinding.Direction;

import java.util.Map;

/*
Companion class to all menus. This is needed to pass information across the entire
 menu system no matter how many inventories are opened or closed.

 Each player has one of these objects, and only one.
 */

public class PlayerMenuUtility {

    private final Player owner;
    //store the player that will be killed so we can access him in the next menu
    private Town town;
    private Building building;
    private Market market;

    private Map<Direction, TownDistancePair> nearbyTowns;

    public Map<Direction, TownDistancePair> getNearbyTowns() {
        return nearbyTowns;
    }

    public void setNearbyTowns(Map<Direction, TownDistancePair> nearbyTowns) {
        this.nearbyTowns = nearbyTowns;
    }

    public PlayerMenuUtility(Player p) {
        this.owner = p;
    }

    public Player getOwner() {
        return owner;
    }

    public Building getBuilding(){return this.building;}
    public Town getTown(){return this.town;}
    public Market getMarket(){return this.market;}

    public void setBuilding(Building building){this.building = building;}
    public void setTown(Town town){this.town = town;}
    public void setMarket(Market market){this.market = market;}
}
