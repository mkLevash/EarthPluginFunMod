package earthrp.menusystem.commands;

import earthrp.Earth;
import earthrp.menusystem.menu.MainMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.sql.SQLException;

public class MainMenuCommand implements CommandExecutor {
    private final Earth earthPlugin;

    public MainMenuCommand(Earth earthPlugin) {
        this.earthPlugin = earthPlugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String s, @NotNull String[] args) {
        if (sender instanceof Player p){

            MainMenu menu = new MainMenu(Earth.getPlayerMenuUtility(p), this.earthPlugin);
            try {
                menu.open();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }

        }

        return false;
    }
}
