package earthrp;

import org.bukkit.Material;

import java.util.UUID;

public class Market {


    UUID uuid;
    UUID tuuid;
    String type;
    int status;
    int goods;
    double marketModifier;
    double tradeModifier;

    String world;
    int x;
    int z;


    public Market(UUID marketUniqueId, UUID townUniqueId, String marketType, int marketStatus, int marketGoods, int townPeople, int marketModifier, String worldName, int chunkX, int chunkZ){
        this.uuid = marketUniqueId;
        this.tuuid = townUniqueId;
        this.type = marketType;
        this.status = marketStatus;
        this.goods = marketGoods;
        this.marketModifier = marketModifier * 0.01;
        this.tradeModifier = ((2 * townPeople)+marketGoods) * 0.01 + 1;
        this.world = worldName;
        this.x = chunkX;
        this.z = chunkZ;



    }

    public UUID getUniqueId(){
        return this.uuid;
    }
    public UUID getTownId(){return this.tuuid;}
    public String getType(){return this.type;}
    public int getGoods(){return this.goods;}
    public int getMarketModifier(){
        return (int) (this.marketModifier * 100);
    }
    public double getTradeModifier(){return this.tradeModifier+this.marketModifier;}
    public int getStatus(){return this.status;}

    public String getWorld(){return this.world;}
    public int getX(){return this.x;}
    public int getZ(){return this.z;}
    public int[] getLocation(){
        int[] loc = new int[2];
        loc[0] = this.x;
        loc[1] = this.z;
        return loc;
    }

    public void setType(String type){
        this.type = type;
    }

    public void setStatus(int status){
        this.status = status;
    }

    public void setGoods(int goods){
        this.goods = goods;
    }

    public void setMarketModifier(int modifier){
        this.marketModifier = modifier*0.01;
    }

}
