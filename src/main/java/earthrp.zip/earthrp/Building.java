package earthrp;

import org.bukkit.Material;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class Building {




    UUID uuid;

    UUID muuid;

    String type;

    String tName;
    UUID tuuid;

    int status;

    String world;
    int x;
    int z;

    Material item;


    public Building( UUID buildingUniqueId, UUID townUniqueId, String townName, UUID marketUniqueId, String buildingType, int buildingStatus, String material, String worldName, int chunkX, int chunkZ){
        this.uuid = buildingUniqueId;
        this.tuuid = townUniqueId;
        this.tName = townName;
        this.muuid = marketUniqueId;
        this.type = buildingType;
        this.status = buildingStatus;
        this.item = material != null ? Material.matchMaterial(material) : null;
        this.world = worldName;
        this.x = chunkX;
        this.z = chunkZ;

    }

    public UUID getUniqueId(){
        return this.uuid;
    }
    public UUID getTownId(){return this.tuuid;}
    public UUID getMarketId(){return this.muuid;}
    public String getType(){return this.type;}
    public String getTownName(){return this.tName;}
    public String getWorld(){return this.world;}
    public Material getItem(){return this.item;}
    public int getStatus(){return this.status;}
    public int getX(){return this.x;}
    public int getZ(){return this.z;}
    public int[] getLocation(){
        int[] loc = new int[2];
        loc[0] = this.x;
        loc[1] = this.z;
        return loc;
    }



    public void setStatus(int status){
        this.status = status;
    }
    public void setTownId(UUID newTownId){this.tuuid = newTownId;}
    public void setTownName(String newTownName){this.tName = newTownName;}
    public void setItem(Material item){
        this.item = item;
    }
    public void setMarketId(UUID newMarketId){this.muuid = newMarketId;}

}
