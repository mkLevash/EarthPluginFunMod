package earthrp;

import java.util.UUID;

public class EarthPlayer {


    private final UUID uuid;
    private String displayName;
    private int oiBalance;
    private int oiIncome;
    private int oiSpent;
    private int politBalance;
    private int politIncome;
    private int politIncomeMod;
    private int politMax;
    private int politMaxMod;
    private int armyLimitMod;
    private int armyExpense;
    private int armyExpenseMod;
    private int manpower;
    private int manpowerMod;
    private int manpowerIncMod;
    private int income;
    private int tradeIncome;
    private int tradeMod;
    private int taxIncome;
    private int taxMod;
    private int expense;
    private int corruption;
    private int inflation;
    private int warSup;
    private int warStatus;
    private int treasury;

    public EarthPlayer(UUID playerUniqueId, String playerDisplayName){
        this.uuid = playerUniqueId;
        this.displayName = playerDisplayName;

    }

    public UUID getUniqueId(){return this.uuid;}
    public String getDisplayName(){return this.displayName;}
    public int getOiBalance(){return this.oiBalance;}
    public int getOiIncome(){return this.oiIncome;}
    public int getOiSpent(){return this.oiSpent;}
    public int getPolitBalance(){return this.politBalance;}
    public int getPolitIncome(){return this.politIncome;}
    public int getPolitIncomeMod(){return this.politIncomeMod;}
    public int getPolitMax(){return this.politMax;}
    public int getPolitMaxMod(){return this.politMaxMod;}
    public int getArmyLimitMod(){return this.armyLimitMod;}
    public int getArmyExpense(){return this.armyExpense;}
    public int getArmyExpenseMod(){return this.armyExpenseMod;}
    public int getManpower(){return this.manpower;}
    public int getManpowerMod(){return this.manpowerMod;}
    public int getManpowerIncMod(){return this.manpowerIncMod;}
    public int getIncome(){return this.income;}
    public int getTradeIncome(){return this.tradeIncome;}
    public int getTradeMod(){return this.tradeMod;}
    public int getTaxIncome(){return this.taxIncome;}
    public int getTaxMod(){return this.taxMod;}
    public int getExpense(){return this.expense;}
    public int getCorruption(){return this.corruption;}
    public int getInflation(){return this.inflation;}
    public int getWarSup(){return this.warSup;}
    public int getWarStatus(){return this.warStatus;}
    public int getTreasury(){return this.treasury;}

    public void setOiBalance(int newValue){this.oiBalance=newValue;}
    public void setOiIncome(int newValue){this.oiIncome=newValue;}
    public void setOiSpent(int newValue){this.oiSpent=newValue;}
    public void setPolitBalance(int newValue){this.politBalance=newValue;}
    public void setPolitIncome(int newValue){this.politIncome=newValue;}
    public void setPolitIncomeMod(int newValue){this.politIncomeMod=newValue;}
    public void setPolitMax(int newValue){this.politMax=newValue;}
    public void setPolitMaxMod(int newValue){this.politMaxMod=newValue;}
    public void setArmyLimitMod(int newValue){this.armyLimitMod=newValue;}
    public void setArmyExpense(int newValue){this.armyExpense=newValue;}
    public void setArmyExpenseMod(int newValue){this.armyExpenseMod=newValue;}
    public void setManpower(int newValue){this.manpower=newValue;}
    public void setManpowerMod(int newValue){this.manpowerMod=newValue;}
    public void setManpowerIncMod(int newValue){this.manpowerIncMod=newValue;}
    public void setIncome(int newValue){this.income=newValue;}
    public void setTradeIncome(int newValue){this.tradeIncome=newValue;}
    public void setTradeMod(int newValue){this.tradeMod=newValue;}
    public void setTaxIncome(int newValue){this.taxIncome=newValue;}
    public void setTaxMod(int newValue){this.taxMod=newValue;}
    public void setExpense(int newValue){this.expense=newValue;}
    public void setCorruption(int newValue){this.corruption=newValue;}
    public void setInflation(int newValue){this.inflation=newValue;}
    public void setWarSup(int newValue){this.warSup=newValue;}
    public void setWarStatus(int newValue){this.warStatus=newValue;}
    public void setTreasury(int newValue){this.treasury=newValue;}

    public void setDisplayName(String pLayerDisplayName){
        this.displayName = pLayerDisplayName;
    }
}
