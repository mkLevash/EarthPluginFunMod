package earthrp;

public class BuildingItem {
}
